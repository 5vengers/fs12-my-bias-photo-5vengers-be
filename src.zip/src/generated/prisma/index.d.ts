
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model UserPoint
 * 
 */
export type UserPoint = $Result.DefaultSelection<Prisma.$UserPointPayload>
/**
 * Model PhotoCard
 * 
 */
export type PhotoCard = $Result.DefaultSelection<Prisma.$PhotoCardPayload>
/**
 * Model MyCard
 * 
 */
export type MyCard = $Result.DefaultSelection<Prisma.$MyCardPayload>
/**
 * Model MarketItem
 * 
 */
export type MarketItem = $Result.DefaultSelection<Prisma.$MarketItemPayload>
/**
 * Model ExchangeProposal
 * 
 */
export type ExchangeProposal = $Result.DefaultSelection<Prisma.$ExchangeProposalPayload>
/**
 * Model Order
 * 
 */
export type Order = $Result.DefaultSelection<Prisma.$OrderPayload>
/**
 * Model PointLog
 * 
 */
export type PointLog = $Result.DefaultSelection<Prisma.$PointLogPayload>
/**
 * Model Notification
 * 
 */
export type Notification = $Result.DefaultSelection<Prisma.$NotificationPayload>
/**
 * Model CardCreationLog
 * 
 */
export type CardCreationLog = $Result.DefaultSelection<Prisma.$CardCreationLogPayload>
/**
 * Model RefreshToken
 * 
 */
export type RefreshToken = $Result.DefaultSelection<Prisma.$RefreshTokenPayload>
/**
 * Model History
 * 
 */
export type History = $Result.DefaultSelection<Prisma.$HistoryPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Provider: {
  LOCAL: 'LOCAL',
  GOOGLE: 'GOOGLE'
};

export type Provider = (typeof Provider)[keyof typeof Provider]


export const CardGrade: {
  COMMON: 'COMMON',
  RARE: 'RARE',
  SUPER_RARE: 'SUPER_RARE',
  LEGENDARY: 'LEGENDARY'
};

export type CardGrade = (typeof CardGrade)[keyof typeof CardGrade]


export const Genre: {
  ALBUM: 'ALBUM',
  BENEFIT: 'BENEFIT',
  FANSIGN: 'FANSIGN',
  SEASON_GREETING: 'SEASON_GREETING',
  FAN_MEETING: 'FAN_MEETING',
  CONCERT: 'CONCERT',
  MD: 'MD',
  COLLAB: 'COLLAB',
  FAN_CLUB: 'FAN_CLUB',
  ETC: 'ETC'
};

export type Genre = (typeof Genre)[keyof typeof Genre]


export const MarketStatus: {
  SELLING: 'SELLING',
  SOLD_OUT: 'SOLD_OUT'
};

export type MarketStatus = (typeof MarketStatus)[keyof typeof MarketStatus]


export const ExchangeStatus: {
  WAITING: 'WAITING',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED'
};

export type ExchangeStatus = (typeof ExchangeStatus)[keyof typeof ExchangeStatus]


export const PointLogType: {
  EARN: 'EARN',
  SPEND: 'SPEND',
  BOX: 'BOX'
};

export type PointLogType = (typeof PointLogType)[keyof typeof PointLogType]


export const NotificationType: {
  TRADE_REQUEST: 'TRADE_REQUEST',
  TRADE_ACCEPTED: 'TRADE_ACCEPTED',
  TRADE_REJECTED: 'TRADE_REJECTED',
  CARD_PURCHASED: 'CARD_PURCHASED',
  CARD_SOLD: 'CARD_SOLD',
  CARD_SOLD_OUT: 'CARD_SOLD_OUT'
};

export type NotificationType = (typeof NotificationType)[keyof typeof NotificationType]


export const RouteType: {
  MARKET_ITEM: 'MARKET_ITEM',
  EXCHANGE_PROPOSAL: 'EXCHANGE_PROPOSAL',
  MY_GALLERY: 'MY_GALLERY',
  MY_SELL_CARDS: 'MY_SELL_CARDS'
};

export type RouteType = (typeof RouteType)[keyof typeof RouteType]


export const OperationType: {
  INSERT: 'INSERT',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE'
};

export type OperationType = (typeof OperationType)[keyof typeof OperationType]

}

export type Provider = $Enums.Provider

export const Provider: typeof $Enums.Provider

export type CardGrade = $Enums.CardGrade

export const CardGrade: typeof $Enums.CardGrade

export type Genre = $Enums.Genre

export const Genre: typeof $Enums.Genre

export type MarketStatus = $Enums.MarketStatus

export const MarketStatus: typeof $Enums.MarketStatus

export type ExchangeStatus = $Enums.ExchangeStatus

export const ExchangeStatus: typeof $Enums.ExchangeStatus

export type PointLogType = $Enums.PointLogType

export const PointLogType: typeof $Enums.PointLogType

export type NotificationType = $Enums.NotificationType

export const NotificationType: typeof $Enums.NotificationType

export type RouteType = $Enums.RouteType

export const RouteType: typeof $Enums.RouteType

export type OperationType = $Enums.OperationType

export const OperationType: typeof $Enums.OperationType

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.userPoint`: Exposes CRUD operations for the **UserPoint** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserPoints
    * const userPoints = await prisma.userPoint.findMany()
    * ```
    */
  get userPoint(): Prisma.UserPointDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.photoCard`: Exposes CRUD operations for the **PhotoCard** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PhotoCards
    * const photoCards = await prisma.photoCard.findMany()
    * ```
    */
  get photoCard(): Prisma.PhotoCardDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.myCard`: Exposes CRUD operations for the **MyCard** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MyCards
    * const myCards = await prisma.myCard.findMany()
    * ```
    */
  get myCard(): Prisma.MyCardDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.marketItem`: Exposes CRUD operations for the **MarketItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MarketItems
    * const marketItems = await prisma.marketItem.findMany()
    * ```
    */
  get marketItem(): Prisma.MarketItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.exchangeProposal`: Exposes CRUD operations for the **ExchangeProposal** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ExchangeProposals
    * const exchangeProposals = await prisma.exchangeProposal.findMany()
    * ```
    */
  get exchangeProposal(): Prisma.ExchangeProposalDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.order`: Exposes CRUD operations for the **Order** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Orders
    * const orders = await prisma.order.findMany()
    * ```
    */
  get order(): Prisma.OrderDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.pointLog`: Exposes CRUD operations for the **PointLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PointLogs
    * const pointLogs = await prisma.pointLog.findMany()
    * ```
    */
  get pointLog(): Prisma.PointLogDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.notification`: Exposes CRUD operations for the **Notification** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Notifications
    * const notifications = await prisma.notification.findMany()
    * ```
    */
  get notification(): Prisma.NotificationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.cardCreationLog`: Exposes CRUD operations for the **CardCreationLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CardCreationLogs
    * const cardCreationLogs = await prisma.cardCreationLog.findMany()
    * ```
    */
  get cardCreationLog(): Prisma.CardCreationLogDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.refreshToken`: Exposes CRUD operations for the **RefreshToken** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more RefreshTokens
    * const refreshTokens = await prisma.refreshToken.findMany()
    * ```
    */
  get refreshToken(): Prisma.RefreshTokenDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.history`: Exposes CRUD operations for the **History** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Histories
    * const histories = await prisma.history.findMany()
    * ```
    */
  get history(): Prisma.HistoryDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    UserPoint: 'UserPoint',
    PhotoCard: 'PhotoCard',
    MyCard: 'MyCard',
    MarketItem: 'MarketItem',
    ExchangeProposal: 'ExchangeProposal',
    Order: 'Order',
    PointLog: 'PointLog',
    Notification: 'Notification',
    CardCreationLog: 'CardCreationLog',
    RefreshToken: 'RefreshToken',
    History: 'History'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "userPoint" | "photoCard" | "myCard" | "marketItem" | "exchangeProposal" | "order" | "pointLog" | "notification" | "cardCreationLog" | "refreshToken" | "history"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      UserPoint: {
        payload: Prisma.$UserPointPayload<ExtArgs>
        fields: Prisma.UserPointFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserPointFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserPointFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          findFirst: {
            args: Prisma.UserPointFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserPointFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          findMany: {
            args: Prisma.UserPointFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>[]
          }
          create: {
            args: Prisma.UserPointCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          createMany: {
            args: Prisma.UserPointCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserPointCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>[]
          }
          delete: {
            args: Prisma.UserPointDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          update: {
            args: Prisma.UserPointUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          deleteMany: {
            args: Prisma.UserPointDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserPointUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserPointUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>[]
          }
          upsert: {
            args: Prisma.UserPointUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPointPayload>
          }
          aggregate: {
            args: Prisma.UserPointAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUserPoint>
          }
          groupBy: {
            args: Prisma.UserPointGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserPointGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserPointCountArgs<ExtArgs>
            result: $Utils.Optional<UserPointCountAggregateOutputType> | number
          }
        }
      }
      PhotoCard: {
        payload: Prisma.$PhotoCardPayload<ExtArgs>
        fields: Prisma.PhotoCardFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PhotoCardFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PhotoCardFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          findFirst: {
            args: Prisma.PhotoCardFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PhotoCardFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          findMany: {
            args: Prisma.PhotoCardFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>[]
          }
          create: {
            args: Prisma.PhotoCardCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          createMany: {
            args: Prisma.PhotoCardCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PhotoCardCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>[]
          }
          delete: {
            args: Prisma.PhotoCardDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          update: {
            args: Prisma.PhotoCardUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          deleteMany: {
            args: Prisma.PhotoCardDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PhotoCardUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PhotoCardUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>[]
          }
          upsert: {
            args: Prisma.PhotoCardUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoCardPayload>
          }
          aggregate: {
            args: Prisma.PhotoCardAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePhotoCard>
          }
          groupBy: {
            args: Prisma.PhotoCardGroupByArgs<ExtArgs>
            result: $Utils.Optional<PhotoCardGroupByOutputType>[]
          }
          count: {
            args: Prisma.PhotoCardCountArgs<ExtArgs>
            result: $Utils.Optional<PhotoCardCountAggregateOutputType> | number
          }
        }
      }
      MyCard: {
        payload: Prisma.$MyCardPayload<ExtArgs>
        fields: Prisma.MyCardFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MyCardFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MyCardFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          findFirst: {
            args: Prisma.MyCardFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MyCardFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          findMany: {
            args: Prisma.MyCardFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>[]
          }
          create: {
            args: Prisma.MyCardCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          createMany: {
            args: Prisma.MyCardCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MyCardCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>[]
          }
          delete: {
            args: Prisma.MyCardDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          update: {
            args: Prisma.MyCardUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          deleteMany: {
            args: Prisma.MyCardDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MyCardUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MyCardUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>[]
          }
          upsert: {
            args: Prisma.MyCardUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MyCardPayload>
          }
          aggregate: {
            args: Prisma.MyCardAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMyCard>
          }
          groupBy: {
            args: Prisma.MyCardGroupByArgs<ExtArgs>
            result: $Utils.Optional<MyCardGroupByOutputType>[]
          }
          count: {
            args: Prisma.MyCardCountArgs<ExtArgs>
            result: $Utils.Optional<MyCardCountAggregateOutputType> | number
          }
        }
      }
      MarketItem: {
        payload: Prisma.$MarketItemPayload<ExtArgs>
        fields: Prisma.MarketItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MarketItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MarketItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          findFirst: {
            args: Prisma.MarketItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MarketItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          findMany: {
            args: Prisma.MarketItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>[]
          }
          create: {
            args: Prisma.MarketItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          createMany: {
            args: Prisma.MarketItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MarketItemCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>[]
          }
          delete: {
            args: Prisma.MarketItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          update: {
            args: Prisma.MarketItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          deleteMany: {
            args: Prisma.MarketItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MarketItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MarketItemUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>[]
          }
          upsert: {
            args: Prisma.MarketItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MarketItemPayload>
          }
          aggregate: {
            args: Prisma.MarketItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMarketItem>
          }
          groupBy: {
            args: Prisma.MarketItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<MarketItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.MarketItemCountArgs<ExtArgs>
            result: $Utils.Optional<MarketItemCountAggregateOutputType> | number
          }
        }
      }
      ExchangeProposal: {
        payload: Prisma.$ExchangeProposalPayload<ExtArgs>
        fields: Prisma.ExchangeProposalFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ExchangeProposalFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ExchangeProposalFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          findFirst: {
            args: Prisma.ExchangeProposalFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ExchangeProposalFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          findMany: {
            args: Prisma.ExchangeProposalFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>[]
          }
          create: {
            args: Prisma.ExchangeProposalCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          createMany: {
            args: Prisma.ExchangeProposalCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ExchangeProposalCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>[]
          }
          delete: {
            args: Prisma.ExchangeProposalDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          update: {
            args: Prisma.ExchangeProposalUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          deleteMany: {
            args: Prisma.ExchangeProposalDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ExchangeProposalUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ExchangeProposalUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>[]
          }
          upsert: {
            args: Prisma.ExchangeProposalUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExchangeProposalPayload>
          }
          aggregate: {
            args: Prisma.ExchangeProposalAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateExchangeProposal>
          }
          groupBy: {
            args: Prisma.ExchangeProposalGroupByArgs<ExtArgs>
            result: $Utils.Optional<ExchangeProposalGroupByOutputType>[]
          }
          count: {
            args: Prisma.ExchangeProposalCountArgs<ExtArgs>
            result: $Utils.Optional<ExchangeProposalCountAggregateOutputType> | number
          }
        }
      }
      Order: {
        payload: Prisma.$OrderPayload<ExtArgs>
        fields: Prisma.OrderFieldRefs
        operations: {
          findUnique: {
            args: Prisma.OrderFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.OrderFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          findFirst: {
            args: Prisma.OrderFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.OrderFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          findMany: {
            args: Prisma.OrderFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>[]
          }
          create: {
            args: Prisma.OrderCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          createMany: {
            args: Prisma.OrderCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.OrderCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>[]
          }
          delete: {
            args: Prisma.OrderDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          update: {
            args: Prisma.OrderUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          deleteMany: {
            args: Prisma.OrderDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.OrderUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.OrderUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>[]
          }
          upsert: {
            args: Prisma.OrderUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrderPayload>
          }
          aggregate: {
            args: Prisma.OrderAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrder>
          }
          groupBy: {
            args: Prisma.OrderGroupByArgs<ExtArgs>
            result: $Utils.Optional<OrderGroupByOutputType>[]
          }
          count: {
            args: Prisma.OrderCountArgs<ExtArgs>
            result: $Utils.Optional<OrderCountAggregateOutputType> | number
          }
        }
      }
      PointLog: {
        payload: Prisma.$PointLogPayload<ExtArgs>
        fields: Prisma.PointLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PointLogFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PointLogFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          findFirst: {
            args: Prisma.PointLogFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PointLogFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          findMany: {
            args: Prisma.PointLogFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>[]
          }
          create: {
            args: Prisma.PointLogCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          createMany: {
            args: Prisma.PointLogCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PointLogCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>[]
          }
          delete: {
            args: Prisma.PointLogDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          update: {
            args: Prisma.PointLogUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          deleteMany: {
            args: Prisma.PointLogDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PointLogUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PointLogUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>[]
          }
          upsert: {
            args: Prisma.PointLogUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PointLogPayload>
          }
          aggregate: {
            args: Prisma.PointLogAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePointLog>
          }
          groupBy: {
            args: Prisma.PointLogGroupByArgs<ExtArgs>
            result: $Utils.Optional<PointLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.PointLogCountArgs<ExtArgs>
            result: $Utils.Optional<PointLogCountAggregateOutputType> | number
          }
        }
      }
      Notification: {
        payload: Prisma.$NotificationPayload<ExtArgs>
        fields: Prisma.NotificationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.NotificationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.NotificationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          findFirst: {
            args: Prisma.NotificationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.NotificationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          findMany: {
            args: Prisma.NotificationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>[]
          }
          create: {
            args: Prisma.NotificationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          createMany: {
            args: Prisma.NotificationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.NotificationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>[]
          }
          delete: {
            args: Prisma.NotificationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          update: {
            args: Prisma.NotificationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          deleteMany: {
            args: Prisma.NotificationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.NotificationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.NotificationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>[]
          }
          upsert: {
            args: Prisma.NotificationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NotificationPayload>
          }
          aggregate: {
            args: Prisma.NotificationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateNotification>
          }
          groupBy: {
            args: Prisma.NotificationGroupByArgs<ExtArgs>
            result: $Utils.Optional<NotificationGroupByOutputType>[]
          }
          count: {
            args: Prisma.NotificationCountArgs<ExtArgs>
            result: $Utils.Optional<NotificationCountAggregateOutputType> | number
          }
        }
      }
      CardCreationLog: {
        payload: Prisma.$CardCreationLogPayload<ExtArgs>
        fields: Prisma.CardCreationLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CardCreationLogFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CardCreationLogFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          findFirst: {
            args: Prisma.CardCreationLogFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CardCreationLogFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          findMany: {
            args: Prisma.CardCreationLogFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>[]
          }
          create: {
            args: Prisma.CardCreationLogCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          createMany: {
            args: Prisma.CardCreationLogCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CardCreationLogCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>[]
          }
          delete: {
            args: Prisma.CardCreationLogDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          update: {
            args: Prisma.CardCreationLogUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          deleteMany: {
            args: Prisma.CardCreationLogDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CardCreationLogUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CardCreationLogUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>[]
          }
          upsert: {
            args: Prisma.CardCreationLogUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CardCreationLogPayload>
          }
          aggregate: {
            args: Prisma.CardCreationLogAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCardCreationLog>
          }
          groupBy: {
            args: Prisma.CardCreationLogGroupByArgs<ExtArgs>
            result: $Utils.Optional<CardCreationLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.CardCreationLogCountArgs<ExtArgs>
            result: $Utils.Optional<CardCreationLogCountAggregateOutputType> | number
          }
        }
      }
      RefreshToken: {
        payload: Prisma.$RefreshTokenPayload<ExtArgs>
        fields: Prisma.RefreshTokenFieldRefs
        operations: {
          findUnique: {
            args: Prisma.RefreshTokenFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.RefreshTokenFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          findFirst: {
            args: Prisma.RefreshTokenFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.RefreshTokenFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          findMany: {
            args: Prisma.RefreshTokenFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>[]
          }
          create: {
            args: Prisma.RefreshTokenCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          createMany: {
            args: Prisma.RefreshTokenCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.RefreshTokenCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>[]
          }
          delete: {
            args: Prisma.RefreshTokenDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          update: {
            args: Prisma.RefreshTokenUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          deleteMany: {
            args: Prisma.RefreshTokenDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.RefreshTokenUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.RefreshTokenUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>[]
          }
          upsert: {
            args: Prisma.RefreshTokenUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RefreshTokenPayload>
          }
          aggregate: {
            args: Prisma.RefreshTokenAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRefreshToken>
          }
          groupBy: {
            args: Prisma.RefreshTokenGroupByArgs<ExtArgs>
            result: $Utils.Optional<RefreshTokenGroupByOutputType>[]
          }
          count: {
            args: Prisma.RefreshTokenCountArgs<ExtArgs>
            result: $Utils.Optional<RefreshTokenCountAggregateOutputType> | number
          }
        }
      }
      History: {
        payload: Prisma.$HistoryPayload<ExtArgs>
        fields: Prisma.HistoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.HistoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.HistoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          findFirst: {
            args: Prisma.HistoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.HistoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          findMany: {
            args: Prisma.HistoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>[]
          }
          create: {
            args: Prisma.HistoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          createMany: {
            args: Prisma.HistoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.HistoryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>[]
          }
          delete: {
            args: Prisma.HistoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          update: {
            args: Prisma.HistoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          deleteMany: {
            args: Prisma.HistoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.HistoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.HistoryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>[]
          }
          upsert: {
            args: Prisma.HistoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryPayload>
          }
          aggregate: {
            args: Prisma.HistoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateHistory>
          }
          groupBy: {
            args: Prisma.HistoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<HistoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.HistoryCountArgs<ExtArgs>
            result: $Utils.Optional<HistoryCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    userPoint?: UserPointOmit
    photoCard?: PhotoCardOmit
    myCard?: MyCardOmit
    marketItem?: MarketItemOmit
    exchangeProposal?: ExchangeProposalOmit
    order?: OrderOmit
    pointLog?: PointLogOmit
    notification?: NotificationOmit
    cardCreationLog?: CardCreationLogOmit
    refreshToken?: RefreshTokenOmit
    history?: HistoryOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    photoCards: number
    myCards: number
    marketItems: number
    exchangeProposals: number
    orders: number
    pointLogs: number
    notifications: number
    creationLogs: number
    refreshTokens: number
    histories: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    photoCards?: boolean | UserCountOutputTypeCountPhotoCardsArgs
    myCards?: boolean | UserCountOutputTypeCountMyCardsArgs
    marketItems?: boolean | UserCountOutputTypeCountMarketItemsArgs
    exchangeProposals?: boolean | UserCountOutputTypeCountExchangeProposalsArgs
    orders?: boolean | UserCountOutputTypeCountOrdersArgs
    pointLogs?: boolean | UserCountOutputTypeCountPointLogsArgs
    notifications?: boolean | UserCountOutputTypeCountNotificationsArgs
    creationLogs?: boolean | UserCountOutputTypeCountCreationLogsArgs
    refreshTokens?: boolean | UserCountOutputTypeCountRefreshTokensArgs
    histories?: boolean | UserCountOutputTypeCountHistoriesArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountPhotoCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotoCardWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountMyCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MyCardWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountMarketItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MarketItemWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountExchangeProposalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExchangeProposalWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountOrdersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrderWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountPointLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PointLogWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountNotificationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: NotificationWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCreationLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CardCreationLogWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountRefreshTokensArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RefreshTokenWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HistoryWhereInput
  }


  /**
   * Count Type PhotoCardCountOutputType
   */

  export type PhotoCardCountOutputType = {
    myCards: number
  }

  export type PhotoCardCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    myCards?: boolean | PhotoCardCountOutputTypeCountMyCardsArgs
  }

  // Custom InputTypes
  /**
   * PhotoCardCountOutputType without action
   */
  export type PhotoCardCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCardCountOutputType
     */
    select?: PhotoCardCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PhotoCardCountOutputType without action
   */
  export type PhotoCardCountOutputTypeCountMyCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MyCardWhereInput
  }


  /**
   * Count Type MyCardCountOutputType
   */

  export type MyCardCountOutputType = {
    marketItems: number
    offeredExchanges: number
  }

  export type MyCardCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    marketItems?: boolean | MyCardCountOutputTypeCountMarketItemsArgs
    offeredExchanges?: boolean | MyCardCountOutputTypeCountOfferedExchangesArgs
  }

  // Custom InputTypes
  /**
   * MyCardCountOutputType without action
   */
  export type MyCardCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCardCountOutputType
     */
    select?: MyCardCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MyCardCountOutputType without action
   */
  export type MyCardCountOutputTypeCountMarketItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MarketItemWhereInput
  }

  /**
   * MyCardCountOutputType without action
   */
  export type MyCardCountOutputTypeCountOfferedExchangesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExchangeProposalWhereInput
  }


  /**
   * Count Type MarketItemCountOutputType
   */

  export type MarketItemCountOutputType = {
    exchangeProposals: number
    orders: number
  }

  export type MarketItemCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    exchangeProposals?: boolean | MarketItemCountOutputTypeCountExchangeProposalsArgs
    orders?: boolean | MarketItemCountOutputTypeCountOrdersArgs
  }

  // Custom InputTypes
  /**
   * MarketItemCountOutputType without action
   */
  export type MarketItemCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItemCountOutputType
     */
    select?: MarketItemCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MarketItemCountOutputType without action
   */
  export type MarketItemCountOutputTypeCountExchangeProposalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExchangeProposalWhereInput
  }

  /**
   * MarketItemCountOutputType without action
   */
  export type MarketItemCountOutputTypeCountOrdersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrderWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    password: string | null
    nickname: string | null
    provider: $Enums.Provider | null
    providerId: string | null
    createdAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    password: string | null
    nickname: string | null
    provider: $Enums.Provider | null
    providerId: string | null
    createdAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    password: number
    nickname: number
    provider: number
    providerId: number
    createdAt: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    password?: true
    nickname?: true
    provider?: true
    providerId?: true
    createdAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    password?: true
    nickname?: true
    provider?: true
    providerId?: true
    createdAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    password?: true
    nickname?: true
    provider?: true
    providerId?: true
    createdAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string
    password: string | null
    nickname: string
    provider: $Enums.Provider
    providerId: string | null
    createdAt: Date
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    password?: boolean
    nickname?: boolean
    provider?: boolean
    providerId?: boolean
    createdAt?: boolean
    userPoint?: boolean | User$userPointArgs<ExtArgs>
    photoCards?: boolean | User$photoCardsArgs<ExtArgs>
    myCards?: boolean | User$myCardsArgs<ExtArgs>
    marketItems?: boolean | User$marketItemsArgs<ExtArgs>
    exchangeProposals?: boolean | User$exchangeProposalsArgs<ExtArgs>
    orders?: boolean | User$ordersArgs<ExtArgs>
    pointLogs?: boolean | User$pointLogsArgs<ExtArgs>
    notifications?: boolean | User$notificationsArgs<ExtArgs>
    creationLogs?: boolean | User$creationLogsArgs<ExtArgs>
    refreshTokens?: boolean | User$refreshTokensArgs<ExtArgs>
    histories?: boolean | User$historiesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    password?: boolean
    nickname?: boolean
    provider?: boolean
    providerId?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    password?: boolean
    nickname?: boolean
    provider?: boolean
    providerId?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    password?: boolean
    nickname?: boolean
    provider?: boolean
    providerId?: boolean
    createdAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "password" | "nickname" | "provider" | "providerId" | "createdAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    userPoint?: boolean | User$userPointArgs<ExtArgs>
    photoCards?: boolean | User$photoCardsArgs<ExtArgs>
    myCards?: boolean | User$myCardsArgs<ExtArgs>
    marketItems?: boolean | User$marketItemsArgs<ExtArgs>
    exchangeProposals?: boolean | User$exchangeProposalsArgs<ExtArgs>
    orders?: boolean | User$ordersArgs<ExtArgs>
    pointLogs?: boolean | User$pointLogsArgs<ExtArgs>
    notifications?: boolean | User$notificationsArgs<ExtArgs>
    creationLogs?: boolean | User$creationLogsArgs<ExtArgs>
    refreshTokens?: boolean | User$refreshTokensArgs<ExtArgs>
    histories?: boolean | User$historiesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      userPoint: Prisma.$UserPointPayload<ExtArgs> | null
      photoCards: Prisma.$PhotoCardPayload<ExtArgs>[]
      myCards: Prisma.$MyCardPayload<ExtArgs>[]
      marketItems: Prisma.$MarketItemPayload<ExtArgs>[]
      exchangeProposals: Prisma.$ExchangeProposalPayload<ExtArgs>[]
      orders: Prisma.$OrderPayload<ExtArgs>[]
      pointLogs: Prisma.$PointLogPayload<ExtArgs>[]
      notifications: Prisma.$NotificationPayload<ExtArgs>[]
      creationLogs: Prisma.$CardCreationLogPayload<ExtArgs>[]
      refreshTokens: Prisma.$RefreshTokenPayload<ExtArgs>[]
      histories: Prisma.$HistoryPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string
      password: string | null
      nickname: string
      provider: $Enums.Provider
      providerId: string | null
      createdAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    userPoint<T extends User$userPointArgs<ExtArgs> = {}>(args?: Subset<T, User$userPointArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    photoCards<T extends User$photoCardsArgs<ExtArgs> = {}>(args?: Subset<T, User$photoCardsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    myCards<T extends User$myCardsArgs<ExtArgs> = {}>(args?: Subset<T, User$myCardsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    marketItems<T extends User$marketItemsArgs<ExtArgs> = {}>(args?: Subset<T, User$marketItemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    exchangeProposals<T extends User$exchangeProposalsArgs<ExtArgs> = {}>(args?: Subset<T, User$exchangeProposalsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    orders<T extends User$ordersArgs<ExtArgs> = {}>(args?: Subset<T, User$ordersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    pointLogs<T extends User$pointLogsArgs<ExtArgs> = {}>(args?: Subset<T, User$pointLogsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    notifications<T extends User$notificationsArgs<ExtArgs> = {}>(args?: Subset<T, User$notificationsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    creationLogs<T extends User$creationLogsArgs<ExtArgs> = {}>(args?: Subset<T, User$creationLogsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    refreshTokens<T extends User$refreshTokensArgs<ExtArgs> = {}>(args?: Subset<T, User$refreshTokensArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    histories<T extends User$historiesArgs<ExtArgs> = {}>(args?: Subset<T, User$historiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly nickname: FieldRef<"User", 'String'>
    readonly provider: FieldRef<"User", 'Provider'>
    readonly providerId: FieldRef<"User", 'String'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.userPoint
   */
  export type User$userPointArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    where?: UserPointWhereInput
  }

  /**
   * User.photoCards
   */
  export type User$photoCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    where?: PhotoCardWhereInput
    orderBy?: PhotoCardOrderByWithRelationInput | PhotoCardOrderByWithRelationInput[]
    cursor?: PhotoCardWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PhotoCardScalarFieldEnum | PhotoCardScalarFieldEnum[]
  }

  /**
   * User.myCards
   */
  export type User$myCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    where?: MyCardWhereInput
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    cursor?: MyCardWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MyCardScalarFieldEnum | MyCardScalarFieldEnum[]
  }

  /**
   * User.marketItems
   */
  export type User$marketItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    where?: MarketItemWhereInput
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    cursor?: MarketItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MarketItemScalarFieldEnum | MarketItemScalarFieldEnum[]
  }

  /**
   * User.exchangeProposals
   */
  export type User$exchangeProposalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    where?: ExchangeProposalWhereInput
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    cursor?: ExchangeProposalWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * User.orders
   */
  export type User$ordersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    where?: OrderWhereInput
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    cursor?: OrderWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * User.pointLogs
   */
  export type User$pointLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    where?: PointLogWhereInput
    orderBy?: PointLogOrderByWithRelationInput | PointLogOrderByWithRelationInput[]
    cursor?: PointLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PointLogScalarFieldEnum | PointLogScalarFieldEnum[]
  }

  /**
   * User.notifications
   */
  export type User$notificationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    where?: NotificationWhereInput
    orderBy?: NotificationOrderByWithRelationInput | NotificationOrderByWithRelationInput[]
    cursor?: NotificationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * User.creationLogs
   */
  export type User$creationLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    where?: CardCreationLogWhereInput
    orderBy?: CardCreationLogOrderByWithRelationInput | CardCreationLogOrderByWithRelationInput[]
    cursor?: CardCreationLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CardCreationLogScalarFieldEnum | CardCreationLogScalarFieldEnum[]
  }

  /**
   * User.refreshTokens
   */
  export type User$refreshTokensArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    where?: RefreshTokenWhereInput
    orderBy?: RefreshTokenOrderByWithRelationInput | RefreshTokenOrderByWithRelationInput[]
    cursor?: RefreshTokenWhereUniqueInput
    take?: number
    skip?: number
    distinct?: RefreshTokenScalarFieldEnum | RefreshTokenScalarFieldEnum[]
  }

  /**
   * User.histories
   */
  export type User$historiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    where?: HistoryWhereInput
    orderBy?: HistoryOrderByWithRelationInput | HistoryOrderByWithRelationInput[]
    cursor?: HistoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: HistoryScalarFieldEnum | HistoryScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model UserPoint
   */

  export type AggregateUserPoint = {
    _count: UserPointCountAggregateOutputType | null
    _avg: UserPointAvgAggregateOutputType | null
    _sum: UserPointSumAggregateOutputType | null
    _min: UserPointMinAggregateOutputType | null
    _max: UserPointMaxAggregateOutputType | null
  }

  export type UserPointAvgAggregateOutputType = {
    id: number | null
    point: number | null
  }

  export type UserPointSumAggregateOutputType = {
    id: number | null
    point: number | null
  }

  export type UserPointMinAggregateOutputType = {
    id: number | null
    userId: string | null
    point: number | null
    lastSpinAt: Date | null
    updatedAt: Date | null
  }

  export type UserPointMaxAggregateOutputType = {
    id: number | null
    userId: string | null
    point: number | null
    lastSpinAt: Date | null
    updatedAt: Date | null
  }

  export type UserPointCountAggregateOutputType = {
    id: number
    userId: number
    point: number
    lastSpinAt: number
    updatedAt: number
    _all: number
  }


  export type UserPointAvgAggregateInputType = {
    id?: true
    point?: true
  }

  export type UserPointSumAggregateInputType = {
    id?: true
    point?: true
  }

  export type UserPointMinAggregateInputType = {
    id?: true
    userId?: true
    point?: true
    lastSpinAt?: true
    updatedAt?: true
  }

  export type UserPointMaxAggregateInputType = {
    id?: true
    userId?: true
    point?: true
    lastSpinAt?: true
    updatedAt?: true
  }

  export type UserPointCountAggregateInputType = {
    id?: true
    userId?: true
    point?: true
    lastSpinAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserPointAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserPoint to aggregate.
     */
    where?: UserPointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserPoints to fetch.
     */
    orderBy?: UserPointOrderByWithRelationInput | UserPointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserPointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserPoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserPoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserPoints
    **/
    _count?: true | UserPointCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserPointAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserPointSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserPointMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserPointMaxAggregateInputType
  }

  export type GetUserPointAggregateType<T extends UserPointAggregateArgs> = {
        [P in keyof T & keyof AggregateUserPoint]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserPoint[P]>
      : GetScalarType<T[P], AggregateUserPoint[P]>
  }




  export type UserPointGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserPointWhereInput
    orderBy?: UserPointOrderByWithAggregationInput | UserPointOrderByWithAggregationInput[]
    by: UserPointScalarFieldEnum[] | UserPointScalarFieldEnum
    having?: UserPointScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserPointCountAggregateInputType | true
    _avg?: UserPointAvgAggregateInputType
    _sum?: UserPointSumAggregateInputType
    _min?: UserPointMinAggregateInputType
    _max?: UserPointMaxAggregateInputType
  }

  export type UserPointGroupByOutputType = {
    id: number
    userId: string
    point: number
    lastSpinAt: Date | null
    updatedAt: Date
    _count: UserPointCountAggregateOutputType | null
    _avg: UserPointAvgAggregateOutputType | null
    _sum: UserPointSumAggregateOutputType | null
    _min: UserPointMinAggregateOutputType | null
    _max: UserPointMaxAggregateOutputType | null
  }

  type GetUserPointGroupByPayload<T extends UserPointGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserPointGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserPointGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserPointGroupByOutputType[P]>
            : GetScalarType<T[P], UserPointGroupByOutputType[P]>
        }
      >
    >


  export type UserPointSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    point?: boolean
    lastSpinAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userPoint"]>

  export type UserPointSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    point?: boolean
    lastSpinAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userPoint"]>

  export type UserPointSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    point?: boolean
    lastSpinAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userPoint"]>

  export type UserPointSelectScalar = {
    id?: boolean
    userId?: boolean
    point?: boolean
    lastSpinAt?: boolean
    updatedAt?: boolean
  }

  export type UserPointOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "point" | "lastSpinAt" | "updatedAt", ExtArgs["result"]["userPoint"]>
  export type UserPointInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type UserPointIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type UserPointIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $UserPointPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserPoint"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: string
      point: number
      lastSpinAt: Date | null
      updatedAt: Date
    }, ExtArgs["result"]["userPoint"]>
    composites: {}
  }

  type UserPointGetPayload<S extends boolean | null | undefined | UserPointDefaultArgs> = $Result.GetResult<Prisma.$UserPointPayload, S>

  type UserPointCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserPointFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserPointCountAggregateInputType | true
    }

  export interface UserPointDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserPoint'], meta: { name: 'UserPoint' } }
    /**
     * Find zero or one UserPoint that matches the filter.
     * @param {UserPointFindUniqueArgs} args - Arguments to find a UserPoint
     * @example
     * // Get one UserPoint
     * const userPoint = await prisma.userPoint.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserPointFindUniqueArgs>(args: SelectSubset<T, UserPointFindUniqueArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one UserPoint that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserPointFindUniqueOrThrowArgs} args - Arguments to find a UserPoint
     * @example
     * // Get one UserPoint
     * const userPoint = await prisma.userPoint.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserPointFindUniqueOrThrowArgs>(args: SelectSubset<T, UserPointFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserPoint that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointFindFirstArgs} args - Arguments to find a UserPoint
     * @example
     * // Get one UserPoint
     * const userPoint = await prisma.userPoint.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserPointFindFirstArgs>(args?: SelectSubset<T, UserPointFindFirstArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserPoint that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointFindFirstOrThrowArgs} args - Arguments to find a UserPoint
     * @example
     * // Get one UserPoint
     * const userPoint = await prisma.userPoint.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserPointFindFirstOrThrowArgs>(args?: SelectSubset<T, UserPointFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserPoints that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserPoints
     * const userPoints = await prisma.userPoint.findMany()
     * 
     * // Get first 10 UserPoints
     * const userPoints = await prisma.userPoint.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userPointWithIdOnly = await prisma.userPoint.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserPointFindManyArgs>(args?: SelectSubset<T, UserPointFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a UserPoint.
     * @param {UserPointCreateArgs} args - Arguments to create a UserPoint.
     * @example
     * // Create one UserPoint
     * const UserPoint = await prisma.userPoint.create({
     *   data: {
     *     // ... data to create a UserPoint
     *   }
     * })
     * 
     */
    create<T extends UserPointCreateArgs>(args: SelectSubset<T, UserPointCreateArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many UserPoints.
     * @param {UserPointCreateManyArgs} args - Arguments to create many UserPoints.
     * @example
     * // Create many UserPoints
     * const userPoint = await prisma.userPoint.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserPointCreateManyArgs>(args?: SelectSubset<T, UserPointCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many UserPoints and returns the data saved in the database.
     * @param {UserPointCreateManyAndReturnArgs} args - Arguments to create many UserPoints.
     * @example
     * // Create many UserPoints
     * const userPoint = await prisma.userPoint.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many UserPoints and only return the `id`
     * const userPointWithIdOnly = await prisma.userPoint.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserPointCreateManyAndReturnArgs>(args?: SelectSubset<T, UserPointCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a UserPoint.
     * @param {UserPointDeleteArgs} args - Arguments to delete one UserPoint.
     * @example
     * // Delete one UserPoint
     * const UserPoint = await prisma.userPoint.delete({
     *   where: {
     *     // ... filter to delete one UserPoint
     *   }
     * })
     * 
     */
    delete<T extends UserPointDeleteArgs>(args: SelectSubset<T, UserPointDeleteArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one UserPoint.
     * @param {UserPointUpdateArgs} args - Arguments to update one UserPoint.
     * @example
     * // Update one UserPoint
     * const userPoint = await prisma.userPoint.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserPointUpdateArgs>(args: SelectSubset<T, UserPointUpdateArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more UserPoints.
     * @param {UserPointDeleteManyArgs} args - Arguments to filter UserPoints to delete.
     * @example
     * // Delete a few UserPoints
     * const { count } = await prisma.userPoint.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserPointDeleteManyArgs>(args?: SelectSubset<T, UserPointDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserPoints.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserPoints
     * const userPoint = await prisma.userPoint.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserPointUpdateManyArgs>(args: SelectSubset<T, UserPointUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserPoints and returns the data updated in the database.
     * @param {UserPointUpdateManyAndReturnArgs} args - Arguments to update many UserPoints.
     * @example
     * // Update many UserPoints
     * const userPoint = await prisma.userPoint.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more UserPoints and only return the `id`
     * const userPointWithIdOnly = await prisma.userPoint.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserPointUpdateManyAndReturnArgs>(args: SelectSubset<T, UserPointUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one UserPoint.
     * @param {UserPointUpsertArgs} args - Arguments to update or create a UserPoint.
     * @example
     * // Update or create a UserPoint
     * const userPoint = await prisma.userPoint.upsert({
     *   create: {
     *     // ... data to create a UserPoint
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserPoint we want to update
     *   }
     * })
     */
    upsert<T extends UserPointUpsertArgs>(args: SelectSubset<T, UserPointUpsertArgs<ExtArgs>>): Prisma__UserPointClient<$Result.GetResult<Prisma.$UserPointPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of UserPoints.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointCountArgs} args - Arguments to filter UserPoints to count.
     * @example
     * // Count the number of UserPoints
     * const count = await prisma.userPoint.count({
     *   where: {
     *     // ... the filter for the UserPoints we want to count
     *   }
     * })
    **/
    count<T extends UserPointCountArgs>(
      args?: Subset<T, UserPointCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserPointCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserPoint.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserPointAggregateArgs>(args: Subset<T, UserPointAggregateArgs>): Prisma.PrismaPromise<GetUserPointAggregateType<T>>

    /**
     * Group by UserPoint.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserPointGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserPointGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserPointGroupByArgs['orderBy'] }
        : { orderBy?: UserPointGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserPointGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserPointGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserPoint model
   */
  readonly fields: UserPointFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserPoint.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserPointClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the UserPoint model
   */
  interface UserPointFieldRefs {
    readonly id: FieldRef<"UserPoint", 'Int'>
    readonly userId: FieldRef<"UserPoint", 'String'>
    readonly point: FieldRef<"UserPoint", 'Int'>
    readonly lastSpinAt: FieldRef<"UserPoint", 'DateTime'>
    readonly updatedAt: FieldRef<"UserPoint", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * UserPoint findUnique
   */
  export type UserPointFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter, which UserPoint to fetch.
     */
    where: UserPointWhereUniqueInput
  }

  /**
   * UserPoint findUniqueOrThrow
   */
  export type UserPointFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter, which UserPoint to fetch.
     */
    where: UserPointWhereUniqueInput
  }

  /**
   * UserPoint findFirst
   */
  export type UserPointFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter, which UserPoint to fetch.
     */
    where?: UserPointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserPoints to fetch.
     */
    orderBy?: UserPointOrderByWithRelationInput | UserPointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserPoints.
     */
    cursor?: UserPointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserPoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserPoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserPoints.
     */
    distinct?: UserPointScalarFieldEnum | UserPointScalarFieldEnum[]
  }

  /**
   * UserPoint findFirstOrThrow
   */
  export type UserPointFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter, which UserPoint to fetch.
     */
    where?: UserPointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserPoints to fetch.
     */
    orderBy?: UserPointOrderByWithRelationInput | UserPointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserPoints.
     */
    cursor?: UserPointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserPoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserPoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserPoints.
     */
    distinct?: UserPointScalarFieldEnum | UserPointScalarFieldEnum[]
  }

  /**
   * UserPoint findMany
   */
  export type UserPointFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter, which UserPoints to fetch.
     */
    where?: UserPointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserPoints to fetch.
     */
    orderBy?: UserPointOrderByWithRelationInput | UserPointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserPoints.
     */
    cursor?: UserPointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserPoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserPoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserPoints.
     */
    distinct?: UserPointScalarFieldEnum | UserPointScalarFieldEnum[]
  }

  /**
   * UserPoint create
   */
  export type UserPointCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * The data needed to create a UserPoint.
     */
    data: XOR<UserPointCreateInput, UserPointUncheckedCreateInput>
  }

  /**
   * UserPoint createMany
   */
  export type UserPointCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserPoints.
     */
    data: UserPointCreateManyInput | UserPointCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * UserPoint createManyAndReturn
   */
  export type UserPointCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * The data used to create many UserPoints.
     */
    data: UserPointCreateManyInput | UserPointCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * UserPoint update
   */
  export type UserPointUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * The data needed to update a UserPoint.
     */
    data: XOR<UserPointUpdateInput, UserPointUncheckedUpdateInput>
    /**
     * Choose, which UserPoint to update.
     */
    where: UserPointWhereUniqueInput
  }

  /**
   * UserPoint updateMany
   */
  export type UserPointUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserPoints.
     */
    data: XOR<UserPointUpdateManyMutationInput, UserPointUncheckedUpdateManyInput>
    /**
     * Filter which UserPoints to update
     */
    where?: UserPointWhereInput
    /**
     * Limit how many UserPoints to update.
     */
    limit?: number
  }

  /**
   * UserPoint updateManyAndReturn
   */
  export type UserPointUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * The data used to update UserPoints.
     */
    data: XOR<UserPointUpdateManyMutationInput, UserPointUncheckedUpdateManyInput>
    /**
     * Filter which UserPoints to update
     */
    where?: UserPointWhereInput
    /**
     * Limit how many UserPoints to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * UserPoint upsert
   */
  export type UserPointUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * The filter to search for the UserPoint to update in case it exists.
     */
    where: UserPointWhereUniqueInput
    /**
     * In case the UserPoint found by the `where` argument doesn't exist, create a new UserPoint with this data.
     */
    create: XOR<UserPointCreateInput, UserPointUncheckedCreateInput>
    /**
     * In case the UserPoint was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserPointUpdateInput, UserPointUncheckedUpdateInput>
  }

  /**
   * UserPoint delete
   */
  export type UserPointDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
    /**
     * Filter which UserPoint to delete.
     */
    where: UserPointWhereUniqueInput
  }

  /**
   * UserPoint deleteMany
   */
  export type UserPointDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserPoints to delete
     */
    where?: UserPointWhereInput
    /**
     * Limit how many UserPoints to delete.
     */
    limit?: number
  }

  /**
   * UserPoint without action
   */
  export type UserPointDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserPoint
     */
    select?: UserPointSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserPoint
     */
    omit?: UserPointOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserPointInclude<ExtArgs> | null
  }


  /**
   * Model PhotoCard
   */

  export type AggregatePhotoCard = {
    _count: PhotoCardCountAggregateOutputType | null
    _avg: PhotoCardAvgAggregateOutputType | null
    _sum: PhotoCardSumAggregateOutputType | null
    _min: PhotoCardMinAggregateOutputType | null
    _max: PhotoCardMaxAggregateOutputType | null
  }

  export type PhotoCardAvgAggregateOutputType = {
    id: number | null
    price: number | null
    totalQuantity: number | null
  }

  export type PhotoCardSumAggregateOutputType = {
    id: number | null
    price: number | null
    totalQuantity: number | null
  }

  export type PhotoCardMinAggregateOutputType = {
    id: number | null
    creatorId: string | null
    name: string | null
    description: string | null
    genre: $Enums.Genre | null
    grade: $Enums.CardGrade | null
    price: number | null
    totalQuantity: number | null
    imageUrl: string | null
    createdAt: Date | null
  }

  export type PhotoCardMaxAggregateOutputType = {
    id: number | null
    creatorId: string | null
    name: string | null
    description: string | null
    genre: $Enums.Genre | null
    grade: $Enums.CardGrade | null
    price: number | null
    totalQuantity: number | null
    imageUrl: string | null
    createdAt: Date | null
  }

  export type PhotoCardCountAggregateOutputType = {
    id: number
    creatorId: number
    name: number
    description: number
    genre: number
    grade: number
    price: number
    totalQuantity: number
    imageUrl: number
    createdAt: number
    _all: number
  }


  export type PhotoCardAvgAggregateInputType = {
    id?: true
    price?: true
    totalQuantity?: true
  }

  export type PhotoCardSumAggregateInputType = {
    id?: true
    price?: true
    totalQuantity?: true
  }

  export type PhotoCardMinAggregateInputType = {
    id?: true
    creatorId?: true
    name?: true
    description?: true
    genre?: true
    grade?: true
    price?: true
    totalQuantity?: true
    imageUrl?: true
    createdAt?: true
  }

  export type PhotoCardMaxAggregateInputType = {
    id?: true
    creatorId?: true
    name?: true
    description?: true
    genre?: true
    grade?: true
    price?: true
    totalQuantity?: true
    imageUrl?: true
    createdAt?: true
  }

  export type PhotoCardCountAggregateInputType = {
    id?: true
    creatorId?: true
    name?: true
    description?: true
    genre?: true
    grade?: true
    price?: true
    totalQuantity?: true
    imageUrl?: true
    createdAt?: true
    _all?: true
  }

  export type PhotoCardAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PhotoCard to aggregate.
     */
    where?: PhotoCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PhotoCards to fetch.
     */
    orderBy?: PhotoCardOrderByWithRelationInput | PhotoCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PhotoCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PhotoCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PhotoCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PhotoCards
    **/
    _count?: true | PhotoCardCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PhotoCardAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PhotoCardSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PhotoCardMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PhotoCardMaxAggregateInputType
  }

  export type GetPhotoCardAggregateType<T extends PhotoCardAggregateArgs> = {
        [P in keyof T & keyof AggregatePhotoCard]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePhotoCard[P]>
      : GetScalarType<T[P], AggregatePhotoCard[P]>
  }




  export type PhotoCardGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotoCardWhereInput
    orderBy?: PhotoCardOrderByWithAggregationInput | PhotoCardOrderByWithAggregationInput[]
    by: PhotoCardScalarFieldEnum[] | PhotoCardScalarFieldEnum
    having?: PhotoCardScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PhotoCardCountAggregateInputType | true
    _avg?: PhotoCardAvgAggregateInputType
    _sum?: PhotoCardSumAggregateInputType
    _min?: PhotoCardMinAggregateInputType
    _max?: PhotoCardMaxAggregateInputType
  }

  export type PhotoCardGroupByOutputType = {
    id: number
    creatorId: string
    name: string
    description: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt: Date
    _count: PhotoCardCountAggregateOutputType | null
    _avg: PhotoCardAvgAggregateOutputType | null
    _sum: PhotoCardSumAggregateOutputType | null
    _min: PhotoCardMinAggregateOutputType | null
    _max: PhotoCardMaxAggregateOutputType | null
  }

  type GetPhotoCardGroupByPayload<T extends PhotoCardGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PhotoCardGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PhotoCardGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PhotoCardGroupByOutputType[P]>
            : GetScalarType<T[P], PhotoCardGroupByOutputType[P]>
        }
      >
    >


  export type PhotoCardSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    creatorId?: boolean
    name?: boolean
    description?: boolean
    genre?: boolean
    grade?: boolean
    price?: boolean
    totalQuantity?: boolean
    imageUrl?: boolean
    createdAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
    myCards?: boolean | PhotoCard$myCardsArgs<ExtArgs>
    _count?: boolean | PhotoCardCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["photoCard"]>

  export type PhotoCardSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    creatorId?: boolean
    name?: boolean
    description?: boolean
    genre?: boolean
    grade?: boolean
    price?: boolean
    totalQuantity?: boolean
    imageUrl?: boolean
    createdAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["photoCard"]>

  export type PhotoCardSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    creatorId?: boolean
    name?: boolean
    description?: boolean
    genre?: boolean
    grade?: boolean
    price?: boolean
    totalQuantity?: boolean
    imageUrl?: boolean
    createdAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["photoCard"]>

  export type PhotoCardSelectScalar = {
    id?: boolean
    creatorId?: boolean
    name?: boolean
    description?: boolean
    genre?: boolean
    grade?: boolean
    price?: boolean
    totalQuantity?: boolean
    imageUrl?: boolean
    createdAt?: boolean
  }

  export type PhotoCardOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "creatorId" | "name" | "description" | "genre" | "grade" | "price" | "totalQuantity" | "imageUrl" | "createdAt", ExtArgs["result"]["photoCard"]>
  export type PhotoCardInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
    myCards?: boolean | PhotoCard$myCardsArgs<ExtArgs>
    _count?: boolean | PhotoCardCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PhotoCardIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type PhotoCardIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $PhotoCardPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PhotoCard"
    objects: {
      creator: Prisma.$UserPayload<ExtArgs>
      myCards: Prisma.$MyCardPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      creatorId: string
      name: string
      description: string | null
      genre: $Enums.Genre
      grade: $Enums.CardGrade
      price: number
      totalQuantity: number
      imageUrl: string
      createdAt: Date
    }, ExtArgs["result"]["photoCard"]>
    composites: {}
  }

  type PhotoCardGetPayload<S extends boolean | null | undefined | PhotoCardDefaultArgs> = $Result.GetResult<Prisma.$PhotoCardPayload, S>

  type PhotoCardCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PhotoCardFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PhotoCardCountAggregateInputType | true
    }

  export interface PhotoCardDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PhotoCard'], meta: { name: 'PhotoCard' } }
    /**
     * Find zero or one PhotoCard that matches the filter.
     * @param {PhotoCardFindUniqueArgs} args - Arguments to find a PhotoCard
     * @example
     * // Get one PhotoCard
     * const photoCard = await prisma.photoCard.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PhotoCardFindUniqueArgs>(args: SelectSubset<T, PhotoCardFindUniqueArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PhotoCard that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PhotoCardFindUniqueOrThrowArgs} args - Arguments to find a PhotoCard
     * @example
     * // Get one PhotoCard
     * const photoCard = await prisma.photoCard.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PhotoCardFindUniqueOrThrowArgs>(args: SelectSubset<T, PhotoCardFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PhotoCard that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardFindFirstArgs} args - Arguments to find a PhotoCard
     * @example
     * // Get one PhotoCard
     * const photoCard = await prisma.photoCard.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PhotoCardFindFirstArgs>(args?: SelectSubset<T, PhotoCardFindFirstArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PhotoCard that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardFindFirstOrThrowArgs} args - Arguments to find a PhotoCard
     * @example
     * // Get one PhotoCard
     * const photoCard = await prisma.photoCard.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PhotoCardFindFirstOrThrowArgs>(args?: SelectSubset<T, PhotoCardFindFirstOrThrowArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PhotoCards that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PhotoCards
     * const photoCards = await prisma.photoCard.findMany()
     * 
     * // Get first 10 PhotoCards
     * const photoCards = await prisma.photoCard.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const photoCardWithIdOnly = await prisma.photoCard.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PhotoCardFindManyArgs>(args?: SelectSubset<T, PhotoCardFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PhotoCard.
     * @param {PhotoCardCreateArgs} args - Arguments to create a PhotoCard.
     * @example
     * // Create one PhotoCard
     * const PhotoCard = await prisma.photoCard.create({
     *   data: {
     *     // ... data to create a PhotoCard
     *   }
     * })
     * 
     */
    create<T extends PhotoCardCreateArgs>(args: SelectSubset<T, PhotoCardCreateArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PhotoCards.
     * @param {PhotoCardCreateManyArgs} args - Arguments to create many PhotoCards.
     * @example
     * // Create many PhotoCards
     * const photoCard = await prisma.photoCard.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PhotoCardCreateManyArgs>(args?: SelectSubset<T, PhotoCardCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PhotoCards and returns the data saved in the database.
     * @param {PhotoCardCreateManyAndReturnArgs} args - Arguments to create many PhotoCards.
     * @example
     * // Create many PhotoCards
     * const photoCard = await prisma.photoCard.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PhotoCards and only return the `id`
     * const photoCardWithIdOnly = await prisma.photoCard.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PhotoCardCreateManyAndReturnArgs>(args?: SelectSubset<T, PhotoCardCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PhotoCard.
     * @param {PhotoCardDeleteArgs} args - Arguments to delete one PhotoCard.
     * @example
     * // Delete one PhotoCard
     * const PhotoCard = await prisma.photoCard.delete({
     *   where: {
     *     // ... filter to delete one PhotoCard
     *   }
     * })
     * 
     */
    delete<T extends PhotoCardDeleteArgs>(args: SelectSubset<T, PhotoCardDeleteArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PhotoCard.
     * @param {PhotoCardUpdateArgs} args - Arguments to update one PhotoCard.
     * @example
     * // Update one PhotoCard
     * const photoCard = await prisma.photoCard.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PhotoCardUpdateArgs>(args: SelectSubset<T, PhotoCardUpdateArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PhotoCards.
     * @param {PhotoCardDeleteManyArgs} args - Arguments to filter PhotoCards to delete.
     * @example
     * // Delete a few PhotoCards
     * const { count } = await prisma.photoCard.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PhotoCardDeleteManyArgs>(args?: SelectSubset<T, PhotoCardDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PhotoCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PhotoCards
     * const photoCard = await prisma.photoCard.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PhotoCardUpdateManyArgs>(args: SelectSubset<T, PhotoCardUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PhotoCards and returns the data updated in the database.
     * @param {PhotoCardUpdateManyAndReturnArgs} args - Arguments to update many PhotoCards.
     * @example
     * // Update many PhotoCards
     * const photoCard = await prisma.photoCard.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PhotoCards and only return the `id`
     * const photoCardWithIdOnly = await prisma.photoCard.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PhotoCardUpdateManyAndReturnArgs>(args: SelectSubset<T, PhotoCardUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PhotoCard.
     * @param {PhotoCardUpsertArgs} args - Arguments to update or create a PhotoCard.
     * @example
     * // Update or create a PhotoCard
     * const photoCard = await prisma.photoCard.upsert({
     *   create: {
     *     // ... data to create a PhotoCard
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PhotoCard we want to update
     *   }
     * })
     */
    upsert<T extends PhotoCardUpsertArgs>(args: SelectSubset<T, PhotoCardUpsertArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PhotoCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardCountArgs} args - Arguments to filter PhotoCards to count.
     * @example
     * // Count the number of PhotoCards
     * const count = await prisma.photoCard.count({
     *   where: {
     *     // ... the filter for the PhotoCards we want to count
     *   }
     * })
    **/
    count<T extends PhotoCardCountArgs>(
      args?: Subset<T, PhotoCardCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PhotoCardCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PhotoCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PhotoCardAggregateArgs>(args: Subset<T, PhotoCardAggregateArgs>): Prisma.PrismaPromise<GetPhotoCardAggregateType<T>>

    /**
     * Group by PhotoCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCardGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PhotoCardGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PhotoCardGroupByArgs['orderBy'] }
        : { orderBy?: PhotoCardGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PhotoCardGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPhotoCardGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PhotoCard model
   */
  readonly fields: PhotoCardFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PhotoCard.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PhotoCardClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    creator<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    myCards<T extends PhotoCard$myCardsArgs<ExtArgs> = {}>(args?: Subset<T, PhotoCard$myCardsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PhotoCard model
   */
  interface PhotoCardFieldRefs {
    readonly id: FieldRef<"PhotoCard", 'Int'>
    readonly creatorId: FieldRef<"PhotoCard", 'String'>
    readonly name: FieldRef<"PhotoCard", 'String'>
    readonly description: FieldRef<"PhotoCard", 'String'>
    readonly genre: FieldRef<"PhotoCard", 'Genre'>
    readonly grade: FieldRef<"PhotoCard", 'CardGrade'>
    readonly price: FieldRef<"PhotoCard", 'Int'>
    readonly totalQuantity: FieldRef<"PhotoCard", 'Int'>
    readonly imageUrl: FieldRef<"PhotoCard", 'String'>
    readonly createdAt: FieldRef<"PhotoCard", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PhotoCard findUnique
   */
  export type PhotoCardFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter, which PhotoCard to fetch.
     */
    where: PhotoCardWhereUniqueInput
  }

  /**
   * PhotoCard findUniqueOrThrow
   */
  export type PhotoCardFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter, which PhotoCard to fetch.
     */
    where: PhotoCardWhereUniqueInput
  }

  /**
   * PhotoCard findFirst
   */
  export type PhotoCardFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter, which PhotoCard to fetch.
     */
    where?: PhotoCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PhotoCards to fetch.
     */
    orderBy?: PhotoCardOrderByWithRelationInput | PhotoCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PhotoCards.
     */
    cursor?: PhotoCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PhotoCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PhotoCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PhotoCards.
     */
    distinct?: PhotoCardScalarFieldEnum | PhotoCardScalarFieldEnum[]
  }

  /**
   * PhotoCard findFirstOrThrow
   */
  export type PhotoCardFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter, which PhotoCard to fetch.
     */
    where?: PhotoCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PhotoCards to fetch.
     */
    orderBy?: PhotoCardOrderByWithRelationInput | PhotoCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PhotoCards.
     */
    cursor?: PhotoCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PhotoCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PhotoCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PhotoCards.
     */
    distinct?: PhotoCardScalarFieldEnum | PhotoCardScalarFieldEnum[]
  }

  /**
   * PhotoCard findMany
   */
  export type PhotoCardFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter, which PhotoCards to fetch.
     */
    where?: PhotoCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PhotoCards to fetch.
     */
    orderBy?: PhotoCardOrderByWithRelationInput | PhotoCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PhotoCards.
     */
    cursor?: PhotoCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PhotoCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PhotoCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PhotoCards.
     */
    distinct?: PhotoCardScalarFieldEnum | PhotoCardScalarFieldEnum[]
  }

  /**
   * PhotoCard create
   */
  export type PhotoCardCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * The data needed to create a PhotoCard.
     */
    data: XOR<PhotoCardCreateInput, PhotoCardUncheckedCreateInput>
  }

  /**
   * PhotoCard createMany
   */
  export type PhotoCardCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PhotoCards.
     */
    data: PhotoCardCreateManyInput | PhotoCardCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PhotoCard createManyAndReturn
   */
  export type PhotoCardCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * The data used to create many PhotoCards.
     */
    data: PhotoCardCreateManyInput | PhotoCardCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PhotoCard update
   */
  export type PhotoCardUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * The data needed to update a PhotoCard.
     */
    data: XOR<PhotoCardUpdateInput, PhotoCardUncheckedUpdateInput>
    /**
     * Choose, which PhotoCard to update.
     */
    where: PhotoCardWhereUniqueInput
  }

  /**
   * PhotoCard updateMany
   */
  export type PhotoCardUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PhotoCards.
     */
    data: XOR<PhotoCardUpdateManyMutationInput, PhotoCardUncheckedUpdateManyInput>
    /**
     * Filter which PhotoCards to update
     */
    where?: PhotoCardWhereInput
    /**
     * Limit how many PhotoCards to update.
     */
    limit?: number
  }

  /**
   * PhotoCard updateManyAndReturn
   */
  export type PhotoCardUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * The data used to update PhotoCards.
     */
    data: XOR<PhotoCardUpdateManyMutationInput, PhotoCardUncheckedUpdateManyInput>
    /**
     * Filter which PhotoCards to update
     */
    where?: PhotoCardWhereInput
    /**
     * Limit how many PhotoCards to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PhotoCard upsert
   */
  export type PhotoCardUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * The filter to search for the PhotoCard to update in case it exists.
     */
    where: PhotoCardWhereUniqueInput
    /**
     * In case the PhotoCard found by the `where` argument doesn't exist, create a new PhotoCard with this data.
     */
    create: XOR<PhotoCardCreateInput, PhotoCardUncheckedCreateInput>
    /**
     * In case the PhotoCard was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PhotoCardUpdateInput, PhotoCardUncheckedUpdateInput>
  }

  /**
   * PhotoCard delete
   */
  export type PhotoCardDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
    /**
     * Filter which PhotoCard to delete.
     */
    where: PhotoCardWhereUniqueInput
  }

  /**
   * PhotoCard deleteMany
   */
  export type PhotoCardDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PhotoCards to delete
     */
    where?: PhotoCardWhereInput
    /**
     * Limit how many PhotoCards to delete.
     */
    limit?: number
  }

  /**
   * PhotoCard.myCards
   */
  export type PhotoCard$myCardsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    where?: MyCardWhereInput
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    cursor?: MyCardWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MyCardScalarFieldEnum | MyCardScalarFieldEnum[]
  }

  /**
   * PhotoCard without action
   */
  export type PhotoCardDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PhotoCard
     */
    select?: PhotoCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PhotoCard
     */
    omit?: PhotoCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoCardInclude<ExtArgs> | null
  }


  /**
   * Model MyCard
   */

  export type AggregateMyCard = {
    _count: MyCardCountAggregateOutputType | null
    _avg: MyCardAvgAggregateOutputType | null
    _sum: MyCardSumAggregateOutputType | null
    _min: MyCardMinAggregateOutputType | null
    _max: MyCardMaxAggregateOutputType | null
  }

  export type MyCardAvgAggregateOutputType = {
    id: number | null
    photoCardId: number | null
    quantity: number | null
  }

  export type MyCardSumAggregateOutputType = {
    id: number | null
    photoCardId: number | null
    quantity: number | null
  }

  export type MyCardMinAggregateOutputType = {
    id: number | null
    ownerId: string | null
    photoCardId: number | null
    quantity: number | null
    acquiredAt: Date | null
  }

  export type MyCardMaxAggregateOutputType = {
    id: number | null
    ownerId: string | null
    photoCardId: number | null
    quantity: number | null
    acquiredAt: Date | null
  }

  export type MyCardCountAggregateOutputType = {
    id: number
    ownerId: number
    photoCardId: number
    quantity: number
    acquiredAt: number
    _all: number
  }


  export type MyCardAvgAggregateInputType = {
    id?: true
    photoCardId?: true
    quantity?: true
  }

  export type MyCardSumAggregateInputType = {
    id?: true
    photoCardId?: true
    quantity?: true
  }

  export type MyCardMinAggregateInputType = {
    id?: true
    ownerId?: true
    photoCardId?: true
    quantity?: true
    acquiredAt?: true
  }

  export type MyCardMaxAggregateInputType = {
    id?: true
    ownerId?: true
    photoCardId?: true
    quantity?: true
    acquiredAt?: true
  }

  export type MyCardCountAggregateInputType = {
    id?: true
    ownerId?: true
    photoCardId?: true
    quantity?: true
    acquiredAt?: true
    _all?: true
  }

  export type MyCardAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MyCard to aggregate.
     */
    where?: MyCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MyCards to fetch.
     */
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MyCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MyCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MyCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MyCards
    **/
    _count?: true | MyCardCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MyCardAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MyCardSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MyCardMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MyCardMaxAggregateInputType
  }

  export type GetMyCardAggregateType<T extends MyCardAggregateArgs> = {
        [P in keyof T & keyof AggregateMyCard]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMyCard[P]>
      : GetScalarType<T[P], AggregateMyCard[P]>
  }




  export type MyCardGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MyCardWhereInput
    orderBy?: MyCardOrderByWithAggregationInput | MyCardOrderByWithAggregationInput[]
    by: MyCardScalarFieldEnum[] | MyCardScalarFieldEnum
    having?: MyCardScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MyCardCountAggregateInputType | true
    _avg?: MyCardAvgAggregateInputType
    _sum?: MyCardSumAggregateInputType
    _min?: MyCardMinAggregateInputType
    _max?: MyCardMaxAggregateInputType
  }

  export type MyCardGroupByOutputType = {
    id: number
    ownerId: string
    photoCardId: number
    quantity: number
    acquiredAt: Date
    _count: MyCardCountAggregateOutputType | null
    _avg: MyCardAvgAggregateOutputType | null
    _sum: MyCardSumAggregateOutputType | null
    _min: MyCardMinAggregateOutputType | null
    _max: MyCardMaxAggregateOutputType | null
  }

  type GetMyCardGroupByPayload<T extends MyCardGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MyCardGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MyCardGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MyCardGroupByOutputType[P]>
            : GetScalarType<T[P], MyCardGroupByOutputType[P]>
        }
      >
    >


  export type MyCardSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ownerId?: boolean
    photoCardId?: boolean
    quantity?: boolean
    acquiredAt?: boolean
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
    marketItems?: boolean | MyCard$marketItemsArgs<ExtArgs>
    offeredExchanges?: boolean | MyCard$offeredExchangesArgs<ExtArgs>
    _count?: boolean | MyCardCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["myCard"]>

  export type MyCardSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ownerId?: boolean
    photoCardId?: boolean
    quantity?: boolean
    acquiredAt?: boolean
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["myCard"]>

  export type MyCardSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ownerId?: boolean
    photoCardId?: boolean
    quantity?: boolean
    acquiredAt?: boolean
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["myCard"]>

  export type MyCardSelectScalar = {
    id?: boolean
    ownerId?: boolean
    photoCardId?: boolean
    quantity?: boolean
    acquiredAt?: boolean
  }

  export type MyCardOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "ownerId" | "photoCardId" | "quantity" | "acquiredAt", ExtArgs["result"]["myCard"]>
  export type MyCardInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
    marketItems?: boolean | MyCard$marketItemsArgs<ExtArgs>
    offeredExchanges?: boolean | MyCard$offeredExchangesArgs<ExtArgs>
    _count?: boolean | MyCardCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type MyCardIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
  }
  export type MyCardIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    owner?: boolean | UserDefaultArgs<ExtArgs>
    photoCard?: boolean | PhotoCardDefaultArgs<ExtArgs>
  }

  export type $MyCardPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MyCard"
    objects: {
      owner: Prisma.$UserPayload<ExtArgs>
      photoCard: Prisma.$PhotoCardPayload<ExtArgs>
      marketItems: Prisma.$MarketItemPayload<ExtArgs>[]
      offeredExchanges: Prisma.$ExchangeProposalPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      ownerId: string
      photoCardId: number
      quantity: number
      acquiredAt: Date
    }, ExtArgs["result"]["myCard"]>
    composites: {}
  }

  type MyCardGetPayload<S extends boolean | null | undefined | MyCardDefaultArgs> = $Result.GetResult<Prisma.$MyCardPayload, S>

  type MyCardCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MyCardFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MyCardCountAggregateInputType | true
    }

  export interface MyCardDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MyCard'], meta: { name: 'MyCard' } }
    /**
     * Find zero or one MyCard that matches the filter.
     * @param {MyCardFindUniqueArgs} args - Arguments to find a MyCard
     * @example
     * // Get one MyCard
     * const myCard = await prisma.myCard.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MyCardFindUniqueArgs>(args: SelectSubset<T, MyCardFindUniqueArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MyCard that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MyCardFindUniqueOrThrowArgs} args - Arguments to find a MyCard
     * @example
     * // Get one MyCard
     * const myCard = await prisma.myCard.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MyCardFindUniqueOrThrowArgs>(args: SelectSubset<T, MyCardFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MyCard that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardFindFirstArgs} args - Arguments to find a MyCard
     * @example
     * // Get one MyCard
     * const myCard = await prisma.myCard.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MyCardFindFirstArgs>(args?: SelectSubset<T, MyCardFindFirstArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MyCard that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardFindFirstOrThrowArgs} args - Arguments to find a MyCard
     * @example
     * // Get one MyCard
     * const myCard = await prisma.myCard.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MyCardFindFirstOrThrowArgs>(args?: SelectSubset<T, MyCardFindFirstOrThrowArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MyCards that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MyCards
     * const myCards = await prisma.myCard.findMany()
     * 
     * // Get first 10 MyCards
     * const myCards = await prisma.myCard.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const myCardWithIdOnly = await prisma.myCard.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MyCardFindManyArgs>(args?: SelectSubset<T, MyCardFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MyCard.
     * @param {MyCardCreateArgs} args - Arguments to create a MyCard.
     * @example
     * // Create one MyCard
     * const MyCard = await prisma.myCard.create({
     *   data: {
     *     // ... data to create a MyCard
     *   }
     * })
     * 
     */
    create<T extends MyCardCreateArgs>(args: SelectSubset<T, MyCardCreateArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MyCards.
     * @param {MyCardCreateManyArgs} args - Arguments to create many MyCards.
     * @example
     * // Create many MyCards
     * const myCard = await prisma.myCard.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MyCardCreateManyArgs>(args?: SelectSubset<T, MyCardCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many MyCards and returns the data saved in the database.
     * @param {MyCardCreateManyAndReturnArgs} args - Arguments to create many MyCards.
     * @example
     * // Create many MyCards
     * const myCard = await prisma.myCard.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many MyCards and only return the `id`
     * const myCardWithIdOnly = await prisma.myCard.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MyCardCreateManyAndReturnArgs>(args?: SelectSubset<T, MyCardCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a MyCard.
     * @param {MyCardDeleteArgs} args - Arguments to delete one MyCard.
     * @example
     * // Delete one MyCard
     * const MyCard = await prisma.myCard.delete({
     *   where: {
     *     // ... filter to delete one MyCard
     *   }
     * })
     * 
     */
    delete<T extends MyCardDeleteArgs>(args: SelectSubset<T, MyCardDeleteArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MyCard.
     * @param {MyCardUpdateArgs} args - Arguments to update one MyCard.
     * @example
     * // Update one MyCard
     * const myCard = await prisma.myCard.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MyCardUpdateArgs>(args: SelectSubset<T, MyCardUpdateArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MyCards.
     * @param {MyCardDeleteManyArgs} args - Arguments to filter MyCards to delete.
     * @example
     * // Delete a few MyCards
     * const { count } = await prisma.myCard.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MyCardDeleteManyArgs>(args?: SelectSubset<T, MyCardDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MyCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MyCards
     * const myCard = await prisma.myCard.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MyCardUpdateManyArgs>(args: SelectSubset<T, MyCardUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MyCards and returns the data updated in the database.
     * @param {MyCardUpdateManyAndReturnArgs} args - Arguments to update many MyCards.
     * @example
     * // Update many MyCards
     * const myCard = await prisma.myCard.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more MyCards and only return the `id`
     * const myCardWithIdOnly = await prisma.myCard.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MyCardUpdateManyAndReturnArgs>(args: SelectSubset<T, MyCardUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one MyCard.
     * @param {MyCardUpsertArgs} args - Arguments to update or create a MyCard.
     * @example
     * // Update or create a MyCard
     * const myCard = await prisma.myCard.upsert({
     *   create: {
     *     // ... data to create a MyCard
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MyCard we want to update
     *   }
     * })
     */
    upsert<T extends MyCardUpsertArgs>(args: SelectSubset<T, MyCardUpsertArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MyCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardCountArgs} args - Arguments to filter MyCards to count.
     * @example
     * // Count the number of MyCards
     * const count = await prisma.myCard.count({
     *   where: {
     *     // ... the filter for the MyCards we want to count
     *   }
     * })
    **/
    count<T extends MyCardCountArgs>(
      args?: Subset<T, MyCardCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MyCardCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MyCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MyCardAggregateArgs>(args: Subset<T, MyCardAggregateArgs>): Prisma.PrismaPromise<GetMyCardAggregateType<T>>

    /**
     * Group by MyCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MyCardGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MyCardGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MyCardGroupByArgs['orderBy'] }
        : { orderBy?: MyCardGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MyCardGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMyCardGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MyCard model
   */
  readonly fields: MyCardFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MyCard.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MyCardClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    owner<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    photoCard<T extends PhotoCardDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PhotoCardDefaultArgs<ExtArgs>>): Prisma__PhotoCardClient<$Result.GetResult<Prisma.$PhotoCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    marketItems<T extends MyCard$marketItemsArgs<ExtArgs> = {}>(args?: Subset<T, MyCard$marketItemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    offeredExchanges<T extends MyCard$offeredExchangesArgs<ExtArgs> = {}>(args?: Subset<T, MyCard$offeredExchangesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MyCard model
   */
  interface MyCardFieldRefs {
    readonly id: FieldRef<"MyCard", 'Int'>
    readonly ownerId: FieldRef<"MyCard", 'String'>
    readonly photoCardId: FieldRef<"MyCard", 'Int'>
    readonly quantity: FieldRef<"MyCard", 'Int'>
    readonly acquiredAt: FieldRef<"MyCard", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MyCard findUnique
   */
  export type MyCardFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter, which MyCard to fetch.
     */
    where: MyCardWhereUniqueInput
  }

  /**
   * MyCard findUniqueOrThrow
   */
  export type MyCardFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter, which MyCard to fetch.
     */
    where: MyCardWhereUniqueInput
  }

  /**
   * MyCard findFirst
   */
  export type MyCardFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter, which MyCard to fetch.
     */
    where?: MyCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MyCards to fetch.
     */
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MyCards.
     */
    cursor?: MyCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MyCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MyCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MyCards.
     */
    distinct?: MyCardScalarFieldEnum | MyCardScalarFieldEnum[]
  }

  /**
   * MyCard findFirstOrThrow
   */
  export type MyCardFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter, which MyCard to fetch.
     */
    where?: MyCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MyCards to fetch.
     */
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MyCards.
     */
    cursor?: MyCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MyCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MyCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MyCards.
     */
    distinct?: MyCardScalarFieldEnum | MyCardScalarFieldEnum[]
  }

  /**
   * MyCard findMany
   */
  export type MyCardFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter, which MyCards to fetch.
     */
    where?: MyCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MyCards to fetch.
     */
    orderBy?: MyCardOrderByWithRelationInput | MyCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MyCards.
     */
    cursor?: MyCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MyCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MyCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MyCards.
     */
    distinct?: MyCardScalarFieldEnum | MyCardScalarFieldEnum[]
  }

  /**
   * MyCard create
   */
  export type MyCardCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * The data needed to create a MyCard.
     */
    data: XOR<MyCardCreateInput, MyCardUncheckedCreateInput>
  }

  /**
   * MyCard createMany
   */
  export type MyCardCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MyCards.
     */
    data: MyCardCreateManyInput | MyCardCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MyCard createManyAndReturn
   */
  export type MyCardCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * The data used to create many MyCards.
     */
    data: MyCardCreateManyInput | MyCardCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * MyCard update
   */
  export type MyCardUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * The data needed to update a MyCard.
     */
    data: XOR<MyCardUpdateInput, MyCardUncheckedUpdateInput>
    /**
     * Choose, which MyCard to update.
     */
    where: MyCardWhereUniqueInput
  }

  /**
   * MyCard updateMany
   */
  export type MyCardUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MyCards.
     */
    data: XOR<MyCardUpdateManyMutationInput, MyCardUncheckedUpdateManyInput>
    /**
     * Filter which MyCards to update
     */
    where?: MyCardWhereInput
    /**
     * Limit how many MyCards to update.
     */
    limit?: number
  }

  /**
   * MyCard updateManyAndReturn
   */
  export type MyCardUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * The data used to update MyCards.
     */
    data: XOR<MyCardUpdateManyMutationInput, MyCardUncheckedUpdateManyInput>
    /**
     * Filter which MyCards to update
     */
    where?: MyCardWhereInput
    /**
     * Limit how many MyCards to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * MyCard upsert
   */
  export type MyCardUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * The filter to search for the MyCard to update in case it exists.
     */
    where: MyCardWhereUniqueInput
    /**
     * In case the MyCard found by the `where` argument doesn't exist, create a new MyCard with this data.
     */
    create: XOR<MyCardCreateInput, MyCardUncheckedCreateInput>
    /**
     * In case the MyCard was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MyCardUpdateInput, MyCardUncheckedUpdateInput>
  }

  /**
   * MyCard delete
   */
  export type MyCardDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
    /**
     * Filter which MyCard to delete.
     */
    where: MyCardWhereUniqueInput
  }

  /**
   * MyCard deleteMany
   */
  export type MyCardDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MyCards to delete
     */
    where?: MyCardWhereInput
    /**
     * Limit how many MyCards to delete.
     */
    limit?: number
  }

  /**
   * MyCard.marketItems
   */
  export type MyCard$marketItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    where?: MarketItemWhereInput
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    cursor?: MarketItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MarketItemScalarFieldEnum | MarketItemScalarFieldEnum[]
  }

  /**
   * MyCard.offeredExchanges
   */
  export type MyCard$offeredExchangesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    where?: ExchangeProposalWhereInput
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    cursor?: ExchangeProposalWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * MyCard without action
   */
  export type MyCardDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MyCard
     */
    select?: MyCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MyCard
     */
    omit?: MyCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MyCardInclude<ExtArgs> | null
  }


  /**
   * Model MarketItem
   */

  export type AggregateMarketItem = {
    _count: MarketItemCountAggregateOutputType | null
    _avg: MarketItemAvgAggregateOutputType | null
    _sum: MarketItemSumAggregateOutputType | null
    _min: MarketItemMinAggregateOutputType | null
    _max: MarketItemMaxAggregateOutputType | null
  }

  export type MarketItemAvgAggregateOutputType = {
    id: number | null
    myCardId: number | null
    quantity: number | null
    soldQuantity: number | null
    pricePerCard: number | null
  }

  export type MarketItemSumAggregateOutputType = {
    id: number | null
    myCardId: number | null
    quantity: number | null
    soldQuantity: number | null
    pricePerCard: number | null
  }

  export type MarketItemMinAggregateOutputType = {
    id: number | null
    sellerId: string | null
    myCardId: number | null
    grade: $Enums.CardGrade | null
    genre: $Enums.Genre | null
    quantity: number | null
    soldQuantity: number | null
    pricePerCard: number | null
    wantedGrade: $Enums.CardGrade | null
    wantedGenre: $Enums.Genre | null
    wantedDescription: string | null
    status: $Enums.MarketStatus | null
    createdAt: Date | null
  }

  export type MarketItemMaxAggregateOutputType = {
    id: number | null
    sellerId: string | null
    myCardId: number | null
    grade: $Enums.CardGrade | null
    genre: $Enums.Genre | null
    quantity: number | null
    soldQuantity: number | null
    pricePerCard: number | null
    wantedGrade: $Enums.CardGrade | null
    wantedGenre: $Enums.Genre | null
    wantedDescription: string | null
    status: $Enums.MarketStatus | null
    createdAt: Date | null
  }

  export type MarketItemCountAggregateOutputType = {
    id: number
    sellerId: number
    myCardId: number
    grade: number
    genre: number
    quantity: number
    soldQuantity: number
    pricePerCard: number
    wantedGrade: number
    wantedGenre: number
    wantedDescription: number
    status: number
    createdAt: number
    _all: number
  }


  export type MarketItemAvgAggregateInputType = {
    id?: true
    myCardId?: true
    quantity?: true
    soldQuantity?: true
    pricePerCard?: true
  }

  export type MarketItemSumAggregateInputType = {
    id?: true
    myCardId?: true
    quantity?: true
    soldQuantity?: true
    pricePerCard?: true
  }

  export type MarketItemMinAggregateInputType = {
    id?: true
    sellerId?: true
    myCardId?: true
    grade?: true
    genre?: true
    quantity?: true
    soldQuantity?: true
    pricePerCard?: true
    wantedGrade?: true
    wantedGenre?: true
    wantedDescription?: true
    status?: true
    createdAt?: true
  }

  export type MarketItemMaxAggregateInputType = {
    id?: true
    sellerId?: true
    myCardId?: true
    grade?: true
    genre?: true
    quantity?: true
    soldQuantity?: true
    pricePerCard?: true
    wantedGrade?: true
    wantedGenre?: true
    wantedDescription?: true
    status?: true
    createdAt?: true
  }

  export type MarketItemCountAggregateInputType = {
    id?: true
    sellerId?: true
    myCardId?: true
    grade?: true
    genre?: true
    quantity?: true
    soldQuantity?: true
    pricePerCard?: true
    wantedGrade?: true
    wantedGenre?: true
    wantedDescription?: true
    status?: true
    createdAt?: true
    _all?: true
  }

  export type MarketItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MarketItem to aggregate.
     */
    where?: MarketItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MarketItems to fetch.
     */
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MarketItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MarketItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MarketItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MarketItems
    **/
    _count?: true | MarketItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MarketItemAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MarketItemSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MarketItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MarketItemMaxAggregateInputType
  }

  export type GetMarketItemAggregateType<T extends MarketItemAggregateArgs> = {
        [P in keyof T & keyof AggregateMarketItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMarketItem[P]>
      : GetScalarType<T[P], AggregateMarketItem[P]>
  }




  export type MarketItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MarketItemWhereInput
    orderBy?: MarketItemOrderByWithAggregationInput | MarketItemOrderByWithAggregationInput[]
    by: MarketItemScalarFieldEnum[] | MarketItemScalarFieldEnum
    having?: MarketItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MarketItemCountAggregateInputType | true
    _avg?: MarketItemAvgAggregateInputType
    _sum?: MarketItemSumAggregateInputType
    _min?: MarketItemMinAggregateInputType
    _max?: MarketItemMaxAggregateInputType
  }

  export type MarketItemGroupByOutputType = {
    id: number
    sellerId: string
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity: number
    pricePerCard: number
    wantedGrade: $Enums.CardGrade | null
    wantedGenre: $Enums.Genre | null
    wantedDescription: string | null
    status: $Enums.MarketStatus
    createdAt: Date
    _count: MarketItemCountAggregateOutputType | null
    _avg: MarketItemAvgAggregateOutputType | null
    _sum: MarketItemSumAggregateOutputType | null
    _min: MarketItemMinAggregateOutputType | null
    _max: MarketItemMaxAggregateOutputType | null
  }

  type GetMarketItemGroupByPayload<T extends MarketItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MarketItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MarketItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MarketItemGroupByOutputType[P]>
            : GetScalarType<T[P], MarketItemGroupByOutputType[P]>
        }
      >
    >


  export type MarketItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sellerId?: boolean
    myCardId?: boolean
    grade?: boolean
    genre?: boolean
    quantity?: boolean
    soldQuantity?: boolean
    pricePerCard?: boolean
    wantedGrade?: boolean
    wantedGenre?: boolean
    wantedDescription?: boolean
    status?: boolean
    createdAt?: boolean
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
    exchangeProposals?: boolean | MarketItem$exchangeProposalsArgs<ExtArgs>
    orders?: boolean | MarketItem$ordersArgs<ExtArgs>
    _count?: boolean | MarketItemCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["marketItem"]>

  export type MarketItemSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sellerId?: boolean
    myCardId?: boolean
    grade?: boolean
    genre?: boolean
    quantity?: boolean
    soldQuantity?: boolean
    pricePerCard?: boolean
    wantedGrade?: boolean
    wantedGenre?: boolean
    wantedDescription?: boolean
    status?: boolean
    createdAt?: boolean
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["marketItem"]>

  export type MarketItemSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sellerId?: boolean
    myCardId?: boolean
    grade?: boolean
    genre?: boolean
    quantity?: boolean
    soldQuantity?: boolean
    pricePerCard?: boolean
    wantedGrade?: boolean
    wantedGenre?: boolean
    wantedDescription?: boolean
    status?: boolean
    createdAt?: boolean
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["marketItem"]>

  export type MarketItemSelectScalar = {
    id?: boolean
    sellerId?: boolean
    myCardId?: boolean
    grade?: boolean
    genre?: boolean
    quantity?: boolean
    soldQuantity?: boolean
    pricePerCard?: boolean
    wantedGrade?: boolean
    wantedGenre?: boolean
    wantedDescription?: boolean
    status?: boolean
    createdAt?: boolean
  }

  export type MarketItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sellerId" | "myCardId" | "grade" | "genre" | "quantity" | "soldQuantity" | "pricePerCard" | "wantedGrade" | "wantedGenre" | "wantedDescription" | "status" | "createdAt", ExtArgs["result"]["marketItem"]>
  export type MarketItemInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
    exchangeProposals?: boolean | MarketItem$exchangeProposalsArgs<ExtArgs>
    orders?: boolean | MarketItem$ordersArgs<ExtArgs>
    _count?: boolean | MarketItemCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type MarketItemIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }
  export type MarketItemIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    seller?: boolean | UserDefaultArgs<ExtArgs>
    myCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }

  export type $MarketItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MarketItem"
    objects: {
      seller: Prisma.$UserPayload<ExtArgs>
      myCard: Prisma.$MyCardPayload<ExtArgs>
      exchangeProposals: Prisma.$ExchangeProposalPayload<ExtArgs>[]
      orders: Prisma.$OrderPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      sellerId: string
      myCardId: number
      grade: $Enums.CardGrade
      genre: $Enums.Genre
      quantity: number
      soldQuantity: number
      pricePerCard: number
      wantedGrade: $Enums.CardGrade | null
      wantedGenre: $Enums.Genre | null
      wantedDescription: string | null
      status: $Enums.MarketStatus
      createdAt: Date
    }, ExtArgs["result"]["marketItem"]>
    composites: {}
  }

  type MarketItemGetPayload<S extends boolean | null | undefined | MarketItemDefaultArgs> = $Result.GetResult<Prisma.$MarketItemPayload, S>

  type MarketItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MarketItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MarketItemCountAggregateInputType | true
    }

  export interface MarketItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MarketItem'], meta: { name: 'MarketItem' } }
    /**
     * Find zero or one MarketItem that matches the filter.
     * @param {MarketItemFindUniqueArgs} args - Arguments to find a MarketItem
     * @example
     * // Get one MarketItem
     * const marketItem = await prisma.marketItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MarketItemFindUniqueArgs>(args: SelectSubset<T, MarketItemFindUniqueArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MarketItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MarketItemFindUniqueOrThrowArgs} args - Arguments to find a MarketItem
     * @example
     * // Get one MarketItem
     * const marketItem = await prisma.marketItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MarketItemFindUniqueOrThrowArgs>(args: SelectSubset<T, MarketItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MarketItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemFindFirstArgs} args - Arguments to find a MarketItem
     * @example
     * // Get one MarketItem
     * const marketItem = await prisma.marketItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MarketItemFindFirstArgs>(args?: SelectSubset<T, MarketItemFindFirstArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MarketItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemFindFirstOrThrowArgs} args - Arguments to find a MarketItem
     * @example
     * // Get one MarketItem
     * const marketItem = await prisma.marketItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MarketItemFindFirstOrThrowArgs>(args?: SelectSubset<T, MarketItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MarketItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MarketItems
     * const marketItems = await prisma.marketItem.findMany()
     * 
     * // Get first 10 MarketItems
     * const marketItems = await prisma.marketItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const marketItemWithIdOnly = await prisma.marketItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MarketItemFindManyArgs>(args?: SelectSubset<T, MarketItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MarketItem.
     * @param {MarketItemCreateArgs} args - Arguments to create a MarketItem.
     * @example
     * // Create one MarketItem
     * const MarketItem = await prisma.marketItem.create({
     *   data: {
     *     // ... data to create a MarketItem
     *   }
     * })
     * 
     */
    create<T extends MarketItemCreateArgs>(args: SelectSubset<T, MarketItemCreateArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MarketItems.
     * @param {MarketItemCreateManyArgs} args - Arguments to create many MarketItems.
     * @example
     * // Create many MarketItems
     * const marketItem = await prisma.marketItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MarketItemCreateManyArgs>(args?: SelectSubset<T, MarketItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many MarketItems and returns the data saved in the database.
     * @param {MarketItemCreateManyAndReturnArgs} args - Arguments to create many MarketItems.
     * @example
     * // Create many MarketItems
     * const marketItem = await prisma.marketItem.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many MarketItems and only return the `id`
     * const marketItemWithIdOnly = await prisma.marketItem.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MarketItemCreateManyAndReturnArgs>(args?: SelectSubset<T, MarketItemCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a MarketItem.
     * @param {MarketItemDeleteArgs} args - Arguments to delete one MarketItem.
     * @example
     * // Delete one MarketItem
     * const MarketItem = await prisma.marketItem.delete({
     *   where: {
     *     // ... filter to delete one MarketItem
     *   }
     * })
     * 
     */
    delete<T extends MarketItemDeleteArgs>(args: SelectSubset<T, MarketItemDeleteArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MarketItem.
     * @param {MarketItemUpdateArgs} args - Arguments to update one MarketItem.
     * @example
     * // Update one MarketItem
     * const marketItem = await prisma.marketItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MarketItemUpdateArgs>(args: SelectSubset<T, MarketItemUpdateArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MarketItems.
     * @param {MarketItemDeleteManyArgs} args - Arguments to filter MarketItems to delete.
     * @example
     * // Delete a few MarketItems
     * const { count } = await prisma.marketItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MarketItemDeleteManyArgs>(args?: SelectSubset<T, MarketItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MarketItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MarketItems
     * const marketItem = await prisma.marketItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MarketItemUpdateManyArgs>(args: SelectSubset<T, MarketItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MarketItems and returns the data updated in the database.
     * @param {MarketItemUpdateManyAndReturnArgs} args - Arguments to update many MarketItems.
     * @example
     * // Update many MarketItems
     * const marketItem = await prisma.marketItem.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more MarketItems and only return the `id`
     * const marketItemWithIdOnly = await prisma.marketItem.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MarketItemUpdateManyAndReturnArgs>(args: SelectSubset<T, MarketItemUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one MarketItem.
     * @param {MarketItemUpsertArgs} args - Arguments to update or create a MarketItem.
     * @example
     * // Update or create a MarketItem
     * const marketItem = await prisma.marketItem.upsert({
     *   create: {
     *     // ... data to create a MarketItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MarketItem we want to update
     *   }
     * })
     */
    upsert<T extends MarketItemUpsertArgs>(args: SelectSubset<T, MarketItemUpsertArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MarketItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemCountArgs} args - Arguments to filter MarketItems to count.
     * @example
     * // Count the number of MarketItems
     * const count = await prisma.marketItem.count({
     *   where: {
     *     // ... the filter for the MarketItems we want to count
     *   }
     * })
    **/
    count<T extends MarketItemCountArgs>(
      args?: Subset<T, MarketItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MarketItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MarketItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MarketItemAggregateArgs>(args: Subset<T, MarketItemAggregateArgs>): Prisma.PrismaPromise<GetMarketItemAggregateType<T>>

    /**
     * Group by MarketItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MarketItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MarketItemGroupByArgs['orderBy'] }
        : { orderBy?: MarketItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MarketItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMarketItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MarketItem model
   */
  readonly fields: MarketItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MarketItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MarketItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    seller<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    myCard<T extends MyCardDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MyCardDefaultArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    exchangeProposals<T extends MarketItem$exchangeProposalsArgs<ExtArgs> = {}>(args?: Subset<T, MarketItem$exchangeProposalsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    orders<T extends MarketItem$ordersArgs<ExtArgs> = {}>(args?: Subset<T, MarketItem$ordersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MarketItem model
   */
  interface MarketItemFieldRefs {
    readonly id: FieldRef<"MarketItem", 'Int'>
    readonly sellerId: FieldRef<"MarketItem", 'String'>
    readonly myCardId: FieldRef<"MarketItem", 'Int'>
    readonly grade: FieldRef<"MarketItem", 'CardGrade'>
    readonly genre: FieldRef<"MarketItem", 'Genre'>
    readonly quantity: FieldRef<"MarketItem", 'Int'>
    readonly soldQuantity: FieldRef<"MarketItem", 'Int'>
    readonly pricePerCard: FieldRef<"MarketItem", 'Int'>
    readonly wantedGrade: FieldRef<"MarketItem", 'CardGrade'>
    readonly wantedGenre: FieldRef<"MarketItem", 'Genre'>
    readonly wantedDescription: FieldRef<"MarketItem", 'String'>
    readonly status: FieldRef<"MarketItem", 'MarketStatus'>
    readonly createdAt: FieldRef<"MarketItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MarketItem findUnique
   */
  export type MarketItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter, which MarketItem to fetch.
     */
    where: MarketItemWhereUniqueInput
  }

  /**
   * MarketItem findUniqueOrThrow
   */
  export type MarketItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter, which MarketItem to fetch.
     */
    where: MarketItemWhereUniqueInput
  }

  /**
   * MarketItem findFirst
   */
  export type MarketItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter, which MarketItem to fetch.
     */
    where?: MarketItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MarketItems to fetch.
     */
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MarketItems.
     */
    cursor?: MarketItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MarketItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MarketItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MarketItems.
     */
    distinct?: MarketItemScalarFieldEnum | MarketItemScalarFieldEnum[]
  }

  /**
   * MarketItem findFirstOrThrow
   */
  export type MarketItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter, which MarketItem to fetch.
     */
    where?: MarketItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MarketItems to fetch.
     */
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MarketItems.
     */
    cursor?: MarketItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MarketItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MarketItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MarketItems.
     */
    distinct?: MarketItemScalarFieldEnum | MarketItemScalarFieldEnum[]
  }

  /**
   * MarketItem findMany
   */
  export type MarketItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter, which MarketItems to fetch.
     */
    where?: MarketItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MarketItems to fetch.
     */
    orderBy?: MarketItemOrderByWithRelationInput | MarketItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MarketItems.
     */
    cursor?: MarketItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MarketItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MarketItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MarketItems.
     */
    distinct?: MarketItemScalarFieldEnum | MarketItemScalarFieldEnum[]
  }

  /**
   * MarketItem create
   */
  export type MarketItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * The data needed to create a MarketItem.
     */
    data: XOR<MarketItemCreateInput, MarketItemUncheckedCreateInput>
  }

  /**
   * MarketItem createMany
   */
  export type MarketItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MarketItems.
     */
    data: MarketItemCreateManyInput | MarketItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MarketItem createManyAndReturn
   */
  export type MarketItemCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * The data used to create many MarketItems.
     */
    data: MarketItemCreateManyInput | MarketItemCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * MarketItem update
   */
  export type MarketItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * The data needed to update a MarketItem.
     */
    data: XOR<MarketItemUpdateInput, MarketItemUncheckedUpdateInput>
    /**
     * Choose, which MarketItem to update.
     */
    where: MarketItemWhereUniqueInput
  }

  /**
   * MarketItem updateMany
   */
  export type MarketItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MarketItems.
     */
    data: XOR<MarketItemUpdateManyMutationInput, MarketItemUncheckedUpdateManyInput>
    /**
     * Filter which MarketItems to update
     */
    where?: MarketItemWhereInput
    /**
     * Limit how many MarketItems to update.
     */
    limit?: number
  }

  /**
   * MarketItem updateManyAndReturn
   */
  export type MarketItemUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * The data used to update MarketItems.
     */
    data: XOR<MarketItemUpdateManyMutationInput, MarketItemUncheckedUpdateManyInput>
    /**
     * Filter which MarketItems to update
     */
    where?: MarketItemWhereInput
    /**
     * Limit how many MarketItems to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * MarketItem upsert
   */
  export type MarketItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * The filter to search for the MarketItem to update in case it exists.
     */
    where: MarketItemWhereUniqueInput
    /**
     * In case the MarketItem found by the `where` argument doesn't exist, create a new MarketItem with this data.
     */
    create: XOR<MarketItemCreateInput, MarketItemUncheckedCreateInput>
    /**
     * In case the MarketItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MarketItemUpdateInput, MarketItemUncheckedUpdateInput>
  }

  /**
   * MarketItem delete
   */
  export type MarketItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
    /**
     * Filter which MarketItem to delete.
     */
    where: MarketItemWhereUniqueInput
  }

  /**
   * MarketItem deleteMany
   */
  export type MarketItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MarketItems to delete
     */
    where?: MarketItemWhereInput
    /**
     * Limit how many MarketItems to delete.
     */
    limit?: number
  }

  /**
   * MarketItem.exchangeProposals
   */
  export type MarketItem$exchangeProposalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    where?: ExchangeProposalWhereInput
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    cursor?: ExchangeProposalWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * MarketItem.orders
   */
  export type MarketItem$ordersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    where?: OrderWhereInput
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    cursor?: OrderWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * MarketItem without action
   */
  export type MarketItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MarketItem
     */
    select?: MarketItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MarketItem
     */
    omit?: MarketItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MarketItemInclude<ExtArgs> | null
  }


  /**
   * Model ExchangeProposal
   */

  export type AggregateExchangeProposal = {
    _count: ExchangeProposalCountAggregateOutputType | null
    _avg: ExchangeProposalAvgAggregateOutputType | null
    _sum: ExchangeProposalSumAggregateOutputType | null
    _min: ExchangeProposalMinAggregateOutputType | null
    _max: ExchangeProposalMaxAggregateOutputType | null
  }

  export type ExchangeProposalAvgAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    offeredCardId: number | null
  }

  export type ExchangeProposalSumAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    offeredCardId: number | null
  }

  export type ExchangeProposalMinAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    proposerId: string | null
    offeredCardId: number | null
    status: $Enums.ExchangeStatus | null
    createdAt: Date | null
  }

  export type ExchangeProposalMaxAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    proposerId: string | null
    offeredCardId: number | null
    status: $Enums.ExchangeStatus | null
    createdAt: Date | null
  }

  export type ExchangeProposalCountAggregateOutputType = {
    id: number
    marketItemId: number
    proposerId: number
    offeredCardId: number
    status: number
    createdAt: number
    _all: number
  }


  export type ExchangeProposalAvgAggregateInputType = {
    id?: true
    marketItemId?: true
    offeredCardId?: true
  }

  export type ExchangeProposalSumAggregateInputType = {
    id?: true
    marketItemId?: true
    offeredCardId?: true
  }

  export type ExchangeProposalMinAggregateInputType = {
    id?: true
    marketItemId?: true
    proposerId?: true
    offeredCardId?: true
    status?: true
    createdAt?: true
  }

  export type ExchangeProposalMaxAggregateInputType = {
    id?: true
    marketItemId?: true
    proposerId?: true
    offeredCardId?: true
    status?: true
    createdAt?: true
  }

  export type ExchangeProposalCountAggregateInputType = {
    id?: true
    marketItemId?: true
    proposerId?: true
    offeredCardId?: true
    status?: true
    createdAt?: true
    _all?: true
  }

  export type ExchangeProposalAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExchangeProposal to aggregate.
     */
    where?: ExchangeProposalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExchangeProposals to fetch.
     */
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ExchangeProposalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExchangeProposals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExchangeProposals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ExchangeProposals
    **/
    _count?: true | ExchangeProposalCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ExchangeProposalAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ExchangeProposalSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ExchangeProposalMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ExchangeProposalMaxAggregateInputType
  }

  export type GetExchangeProposalAggregateType<T extends ExchangeProposalAggregateArgs> = {
        [P in keyof T & keyof AggregateExchangeProposal]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateExchangeProposal[P]>
      : GetScalarType<T[P], AggregateExchangeProposal[P]>
  }




  export type ExchangeProposalGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExchangeProposalWhereInput
    orderBy?: ExchangeProposalOrderByWithAggregationInput | ExchangeProposalOrderByWithAggregationInput[]
    by: ExchangeProposalScalarFieldEnum[] | ExchangeProposalScalarFieldEnum
    having?: ExchangeProposalScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ExchangeProposalCountAggregateInputType | true
    _avg?: ExchangeProposalAvgAggregateInputType
    _sum?: ExchangeProposalSumAggregateInputType
    _min?: ExchangeProposalMinAggregateInputType
    _max?: ExchangeProposalMaxAggregateInputType
  }

  export type ExchangeProposalGroupByOutputType = {
    id: number
    marketItemId: number
    proposerId: string
    offeredCardId: number
    status: $Enums.ExchangeStatus
    createdAt: Date
    _count: ExchangeProposalCountAggregateOutputType | null
    _avg: ExchangeProposalAvgAggregateOutputType | null
    _sum: ExchangeProposalSumAggregateOutputType | null
    _min: ExchangeProposalMinAggregateOutputType | null
    _max: ExchangeProposalMaxAggregateOutputType | null
  }

  type GetExchangeProposalGroupByPayload<T extends ExchangeProposalGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ExchangeProposalGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ExchangeProposalGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ExchangeProposalGroupByOutputType[P]>
            : GetScalarType<T[P], ExchangeProposalGroupByOutputType[P]>
        }
      >
    >


  export type ExchangeProposalSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    marketItemId?: boolean
    proposerId?: boolean
    offeredCardId?: boolean
    status?: boolean
    createdAt?: boolean
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["exchangeProposal"]>

  export type ExchangeProposalSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    marketItemId?: boolean
    proposerId?: boolean
    offeredCardId?: boolean
    status?: boolean
    createdAt?: boolean
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["exchangeProposal"]>

  export type ExchangeProposalSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    marketItemId?: boolean
    proposerId?: boolean
    offeredCardId?: boolean
    status?: boolean
    createdAt?: boolean
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["exchangeProposal"]>

  export type ExchangeProposalSelectScalar = {
    id?: boolean
    marketItemId?: boolean
    proposerId?: boolean
    offeredCardId?: boolean
    status?: boolean
    createdAt?: boolean
  }

  export type ExchangeProposalOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "marketItemId" | "proposerId" | "offeredCardId" | "status" | "createdAt", ExtArgs["result"]["exchangeProposal"]>
  export type ExchangeProposalInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }
  export type ExchangeProposalIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }
  export type ExchangeProposalIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
    proposer?: boolean | UserDefaultArgs<ExtArgs>
    offeredCard?: boolean | MyCardDefaultArgs<ExtArgs>
  }

  export type $ExchangeProposalPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ExchangeProposal"
    objects: {
      marketItem: Prisma.$MarketItemPayload<ExtArgs>
      proposer: Prisma.$UserPayload<ExtArgs>
      offeredCard: Prisma.$MyCardPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      marketItemId: number
      proposerId: string
      offeredCardId: number
      status: $Enums.ExchangeStatus
      createdAt: Date
    }, ExtArgs["result"]["exchangeProposal"]>
    composites: {}
  }

  type ExchangeProposalGetPayload<S extends boolean | null | undefined | ExchangeProposalDefaultArgs> = $Result.GetResult<Prisma.$ExchangeProposalPayload, S>

  type ExchangeProposalCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ExchangeProposalFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ExchangeProposalCountAggregateInputType | true
    }

  export interface ExchangeProposalDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ExchangeProposal'], meta: { name: 'ExchangeProposal' } }
    /**
     * Find zero or one ExchangeProposal that matches the filter.
     * @param {ExchangeProposalFindUniqueArgs} args - Arguments to find a ExchangeProposal
     * @example
     * // Get one ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExchangeProposalFindUniqueArgs>(args: SelectSubset<T, ExchangeProposalFindUniqueArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ExchangeProposal that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExchangeProposalFindUniqueOrThrowArgs} args - Arguments to find a ExchangeProposal
     * @example
     * // Get one ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExchangeProposalFindUniqueOrThrowArgs>(args: SelectSubset<T, ExchangeProposalFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExchangeProposal that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalFindFirstArgs} args - Arguments to find a ExchangeProposal
     * @example
     * // Get one ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExchangeProposalFindFirstArgs>(args?: SelectSubset<T, ExchangeProposalFindFirstArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExchangeProposal that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalFindFirstOrThrowArgs} args - Arguments to find a ExchangeProposal
     * @example
     * // Get one ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExchangeProposalFindFirstOrThrowArgs>(args?: SelectSubset<T, ExchangeProposalFindFirstOrThrowArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ExchangeProposals that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ExchangeProposals
     * const exchangeProposals = await prisma.exchangeProposal.findMany()
     * 
     * // Get first 10 ExchangeProposals
     * const exchangeProposals = await prisma.exchangeProposal.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const exchangeProposalWithIdOnly = await prisma.exchangeProposal.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ExchangeProposalFindManyArgs>(args?: SelectSubset<T, ExchangeProposalFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ExchangeProposal.
     * @param {ExchangeProposalCreateArgs} args - Arguments to create a ExchangeProposal.
     * @example
     * // Create one ExchangeProposal
     * const ExchangeProposal = await prisma.exchangeProposal.create({
     *   data: {
     *     // ... data to create a ExchangeProposal
     *   }
     * })
     * 
     */
    create<T extends ExchangeProposalCreateArgs>(args: SelectSubset<T, ExchangeProposalCreateArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ExchangeProposals.
     * @param {ExchangeProposalCreateManyArgs} args - Arguments to create many ExchangeProposals.
     * @example
     * // Create many ExchangeProposals
     * const exchangeProposal = await prisma.exchangeProposal.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ExchangeProposalCreateManyArgs>(args?: SelectSubset<T, ExchangeProposalCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ExchangeProposals and returns the data saved in the database.
     * @param {ExchangeProposalCreateManyAndReturnArgs} args - Arguments to create many ExchangeProposals.
     * @example
     * // Create many ExchangeProposals
     * const exchangeProposal = await prisma.exchangeProposal.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ExchangeProposals and only return the `id`
     * const exchangeProposalWithIdOnly = await prisma.exchangeProposal.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ExchangeProposalCreateManyAndReturnArgs>(args?: SelectSubset<T, ExchangeProposalCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ExchangeProposal.
     * @param {ExchangeProposalDeleteArgs} args - Arguments to delete one ExchangeProposal.
     * @example
     * // Delete one ExchangeProposal
     * const ExchangeProposal = await prisma.exchangeProposal.delete({
     *   where: {
     *     // ... filter to delete one ExchangeProposal
     *   }
     * })
     * 
     */
    delete<T extends ExchangeProposalDeleteArgs>(args: SelectSubset<T, ExchangeProposalDeleteArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ExchangeProposal.
     * @param {ExchangeProposalUpdateArgs} args - Arguments to update one ExchangeProposal.
     * @example
     * // Update one ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ExchangeProposalUpdateArgs>(args: SelectSubset<T, ExchangeProposalUpdateArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ExchangeProposals.
     * @param {ExchangeProposalDeleteManyArgs} args - Arguments to filter ExchangeProposals to delete.
     * @example
     * // Delete a few ExchangeProposals
     * const { count } = await prisma.exchangeProposal.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ExchangeProposalDeleteManyArgs>(args?: SelectSubset<T, ExchangeProposalDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExchangeProposals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ExchangeProposals
     * const exchangeProposal = await prisma.exchangeProposal.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ExchangeProposalUpdateManyArgs>(args: SelectSubset<T, ExchangeProposalUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExchangeProposals and returns the data updated in the database.
     * @param {ExchangeProposalUpdateManyAndReturnArgs} args - Arguments to update many ExchangeProposals.
     * @example
     * // Update many ExchangeProposals
     * const exchangeProposal = await prisma.exchangeProposal.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ExchangeProposals and only return the `id`
     * const exchangeProposalWithIdOnly = await prisma.exchangeProposal.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ExchangeProposalUpdateManyAndReturnArgs>(args: SelectSubset<T, ExchangeProposalUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ExchangeProposal.
     * @param {ExchangeProposalUpsertArgs} args - Arguments to update or create a ExchangeProposal.
     * @example
     * // Update or create a ExchangeProposal
     * const exchangeProposal = await prisma.exchangeProposal.upsert({
     *   create: {
     *     // ... data to create a ExchangeProposal
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ExchangeProposal we want to update
     *   }
     * })
     */
    upsert<T extends ExchangeProposalUpsertArgs>(args: SelectSubset<T, ExchangeProposalUpsertArgs<ExtArgs>>): Prisma__ExchangeProposalClient<$Result.GetResult<Prisma.$ExchangeProposalPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ExchangeProposals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalCountArgs} args - Arguments to filter ExchangeProposals to count.
     * @example
     * // Count the number of ExchangeProposals
     * const count = await prisma.exchangeProposal.count({
     *   where: {
     *     // ... the filter for the ExchangeProposals we want to count
     *   }
     * })
    **/
    count<T extends ExchangeProposalCountArgs>(
      args?: Subset<T, ExchangeProposalCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ExchangeProposalCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ExchangeProposal.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExchangeProposalAggregateArgs>(args: Subset<T, ExchangeProposalAggregateArgs>): Prisma.PrismaPromise<GetExchangeProposalAggregateType<T>>

    /**
     * Group by ExchangeProposal.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExchangeProposalGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ExchangeProposalGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ExchangeProposalGroupByArgs['orderBy'] }
        : { orderBy?: ExchangeProposalGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ExchangeProposalGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExchangeProposalGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ExchangeProposal model
   */
  readonly fields: ExchangeProposalFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ExchangeProposal.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ExchangeProposalClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    marketItem<T extends MarketItemDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MarketItemDefaultArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    proposer<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    offeredCard<T extends MyCardDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MyCardDefaultArgs<ExtArgs>>): Prisma__MyCardClient<$Result.GetResult<Prisma.$MyCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ExchangeProposal model
   */
  interface ExchangeProposalFieldRefs {
    readonly id: FieldRef<"ExchangeProposal", 'Int'>
    readonly marketItemId: FieldRef<"ExchangeProposal", 'Int'>
    readonly proposerId: FieldRef<"ExchangeProposal", 'String'>
    readonly offeredCardId: FieldRef<"ExchangeProposal", 'Int'>
    readonly status: FieldRef<"ExchangeProposal", 'ExchangeStatus'>
    readonly createdAt: FieldRef<"ExchangeProposal", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * ExchangeProposal findUnique
   */
  export type ExchangeProposalFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter, which ExchangeProposal to fetch.
     */
    where: ExchangeProposalWhereUniqueInput
  }

  /**
   * ExchangeProposal findUniqueOrThrow
   */
  export type ExchangeProposalFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter, which ExchangeProposal to fetch.
     */
    where: ExchangeProposalWhereUniqueInput
  }

  /**
   * ExchangeProposal findFirst
   */
  export type ExchangeProposalFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter, which ExchangeProposal to fetch.
     */
    where?: ExchangeProposalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExchangeProposals to fetch.
     */
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExchangeProposals.
     */
    cursor?: ExchangeProposalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExchangeProposals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExchangeProposals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExchangeProposals.
     */
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * ExchangeProposal findFirstOrThrow
   */
  export type ExchangeProposalFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter, which ExchangeProposal to fetch.
     */
    where?: ExchangeProposalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExchangeProposals to fetch.
     */
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExchangeProposals.
     */
    cursor?: ExchangeProposalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExchangeProposals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExchangeProposals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExchangeProposals.
     */
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * ExchangeProposal findMany
   */
  export type ExchangeProposalFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter, which ExchangeProposals to fetch.
     */
    where?: ExchangeProposalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExchangeProposals to fetch.
     */
    orderBy?: ExchangeProposalOrderByWithRelationInput | ExchangeProposalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ExchangeProposals.
     */
    cursor?: ExchangeProposalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExchangeProposals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExchangeProposals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExchangeProposals.
     */
    distinct?: ExchangeProposalScalarFieldEnum | ExchangeProposalScalarFieldEnum[]
  }

  /**
   * ExchangeProposal create
   */
  export type ExchangeProposalCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * The data needed to create a ExchangeProposal.
     */
    data: XOR<ExchangeProposalCreateInput, ExchangeProposalUncheckedCreateInput>
  }

  /**
   * ExchangeProposal createMany
   */
  export type ExchangeProposalCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ExchangeProposals.
     */
    data: ExchangeProposalCreateManyInput | ExchangeProposalCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ExchangeProposal createManyAndReturn
   */
  export type ExchangeProposalCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * The data used to create many ExchangeProposals.
     */
    data: ExchangeProposalCreateManyInput | ExchangeProposalCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExchangeProposal update
   */
  export type ExchangeProposalUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * The data needed to update a ExchangeProposal.
     */
    data: XOR<ExchangeProposalUpdateInput, ExchangeProposalUncheckedUpdateInput>
    /**
     * Choose, which ExchangeProposal to update.
     */
    where: ExchangeProposalWhereUniqueInput
  }

  /**
   * ExchangeProposal updateMany
   */
  export type ExchangeProposalUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ExchangeProposals.
     */
    data: XOR<ExchangeProposalUpdateManyMutationInput, ExchangeProposalUncheckedUpdateManyInput>
    /**
     * Filter which ExchangeProposals to update
     */
    where?: ExchangeProposalWhereInput
    /**
     * Limit how many ExchangeProposals to update.
     */
    limit?: number
  }

  /**
   * ExchangeProposal updateManyAndReturn
   */
  export type ExchangeProposalUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * The data used to update ExchangeProposals.
     */
    data: XOR<ExchangeProposalUpdateManyMutationInput, ExchangeProposalUncheckedUpdateManyInput>
    /**
     * Filter which ExchangeProposals to update
     */
    where?: ExchangeProposalWhereInput
    /**
     * Limit how many ExchangeProposals to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExchangeProposal upsert
   */
  export type ExchangeProposalUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * The filter to search for the ExchangeProposal to update in case it exists.
     */
    where: ExchangeProposalWhereUniqueInput
    /**
     * In case the ExchangeProposal found by the `where` argument doesn't exist, create a new ExchangeProposal with this data.
     */
    create: XOR<ExchangeProposalCreateInput, ExchangeProposalUncheckedCreateInput>
    /**
     * In case the ExchangeProposal was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ExchangeProposalUpdateInput, ExchangeProposalUncheckedUpdateInput>
  }

  /**
   * ExchangeProposal delete
   */
  export type ExchangeProposalDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
    /**
     * Filter which ExchangeProposal to delete.
     */
    where: ExchangeProposalWhereUniqueInput
  }

  /**
   * ExchangeProposal deleteMany
   */
  export type ExchangeProposalDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExchangeProposals to delete
     */
    where?: ExchangeProposalWhereInput
    /**
     * Limit how many ExchangeProposals to delete.
     */
    limit?: number
  }

  /**
   * ExchangeProposal without action
   */
  export type ExchangeProposalDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExchangeProposal
     */
    select?: ExchangeProposalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExchangeProposal
     */
    omit?: ExchangeProposalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExchangeProposalInclude<ExtArgs> | null
  }


  /**
   * Model Order
   */

  export type AggregateOrder = {
    _count: OrderCountAggregateOutputType | null
    _avg: OrderAvgAggregateOutputType | null
    _sum: OrderSumAggregateOutputType | null
    _min: OrderMinAggregateOutputType | null
    _max: OrderMaxAggregateOutputType | null
  }

  export type OrderAvgAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    quantity: number | null
    totalPrice: number | null
  }

  export type OrderSumAggregateOutputType = {
    id: number | null
    marketItemId: number | null
    quantity: number | null
    totalPrice: number | null
  }

  export type OrderMinAggregateOutputType = {
    id: number | null
    buyerId: string | null
    marketItemId: number | null
    quantity: number | null
    totalPrice: number | null
    createdAt: Date | null
  }

  export type OrderMaxAggregateOutputType = {
    id: number | null
    buyerId: string | null
    marketItemId: number | null
    quantity: number | null
    totalPrice: number | null
    createdAt: Date | null
  }

  export type OrderCountAggregateOutputType = {
    id: number
    buyerId: number
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt: number
    _all: number
  }


  export type OrderAvgAggregateInputType = {
    id?: true
    marketItemId?: true
    quantity?: true
    totalPrice?: true
  }

  export type OrderSumAggregateInputType = {
    id?: true
    marketItemId?: true
    quantity?: true
    totalPrice?: true
  }

  export type OrderMinAggregateInputType = {
    id?: true
    buyerId?: true
    marketItemId?: true
    quantity?: true
    totalPrice?: true
    createdAt?: true
  }

  export type OrderMaxAggregateInputType = {
    id?: true
    buyerId?: true
    marketItemId?: true
    quantity?: true
    totalPrice?: true
    createdAt?: true
  }

  export type OrderCountAggregateInputType = {
    id?: true
    buyerId?: true
    marketItemId?: true
    quantity?: true
    totalPrice?: true
    createdAt?: true
    _all?: true
  }

  export type OrderAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Order to aggregate.
     */
    where?: OrderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Orders to fetch.
     */
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: OrderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Orders
    **/
    _count?: true | OrderCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OrderAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OrderSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OrderMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OrderMaxAggregateInputType
  }

  export type GetOrderAggregateType<T extends OrderAggregateArgs> = {
        [P in keyof T & keyof AggregateOrder]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrder[P]>
      : GetScalarType<T[P], AggregateOrder[P]>
  }




  export type OrderGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrderWhereInput
    orderBy?: OrderOrderByWithAggregationInput | OrderOrderByWithAggregationInput[]
    by: OrderScalarFieldEnum[] | OrderScalarFieldEnum
    having?: OrderScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OrderCountAggregateInputType | true
    _avg?: OrderAvgAggregateInputType
    _sum?: OrderSumAggregateInputType
    _min?: OrderMinAggregateInputType
    _max?: OrderMaxAggregateInputType
  }

  export type OrderGroupByOutputType = {
    id: number
    buyerId: string
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt: Date
    _count: OrderCountAggregateOutputType | null
    _avg: OrderAvgAggregateOutputType | null
    _sum: OrderSumAggregateOutputType | null
    _min: OrderMinAggregateOutputType | null
    _max: OrderMaxAggregateOutputType | null
  }

  type GetOrderGroupByPayload<T extends OrderGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OrderGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OrderGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OrderGroupByOutputType[P]>
            : GetScalarType<T[P], OrderGroupByOutputType[P]>
        }
      >
    >


  export type OrderSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    buyerId?: boolean
    marketItemId?: boolean
    quantity?: boolean
    totalPrice?: boolean
    createdAt?: boolean
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type OrderSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    buyerId?: boolean
    marketItemId?: boolean
    quantity?: boolean
    totalPrice?: boolean
    createdAt?: boolean
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type OrderSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    buyerId?: boolean
    marketItemId?: boolean
    quantity?: boolean
    totalPrice?: boolean
    createdAt?: boolean
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type OrderSelectScalar = {
    id?: boolean
    buyerId?: boolean
    marketItemId?: boolean
    quantity?: boolean
    totalPrice?: boolean
    createdAt?: boolean
  }

  export type OrderOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "buyerId" | "marketItemId" | "quantity" | "totalPrice" | "createdAt", ExtArgs["result"]["order"]>
  export type OrderInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }
  export type OrderIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }
  export type OrderIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    buyer?: boolean | UserDefaultArgs<ExtArgs>
    marketItem?: boolean | MarketItemDefaultArgs<ExtArgs>
  }

  export type $OrderPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Order"
    objects: {
      buyer: Prisma.$UserPayload<ExtArgs>
      marketItem: Prisma.$MarketItemPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      buyerId: string
      marketItemId: number
      quantity: number
      totalPrice: number
      createdAt: Date
    }, ExtArgs["result"]["order"]>
    composites: {}
  }

  type OrderGetPayload<S extends boolean | null | undefined | OrderDefaultArgs> = $Result.GetResult<Prisma.$OrderPayload, S>

  type OrderCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<OrderFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OrderCountAggregateInputType | true
    }

  export interface OrderDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Order'], meta: { name: 'Order' } }
    /**
     * Find zero or one Order that matches the filter.
     * @param {OrderFindUniqueArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends OrderFindUniqueArgs>(args: SelectSubset<T, OrderFindUniqueArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Order that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {OrderFindUniqueOrThrowArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends OrderFindUniqueOrThrowArgs>(args: SelectSubset<T, OrderFindUniqueOrThrowArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderFindFirstArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends OrderFindFirstArgs>(args?: SelectSubset<T, OrderFindFirstArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderFindFirstOrThrowArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends OrderFindFirstOrThrowArgs>(args?: SelectSubset<T, OrderFindFirstOrThrowArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Orders that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Orders
     * const orders = await prisma.order.findMany()
     * 
     * // Get first 10 Orders
     * const orders = await prisma.order.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const orderWithIdOnly = await prisma.order.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends OrderFindManyArgs>(args?: SelectSubset<T, OrderFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Order.
     * @param {OrderCreateArgs} args - Arguments to create a Order.
     * @example
     * // Create one Order
     * const Order = await prisma.order.create({
     *   data: {
     *     // ... data to create a Order
     *   }
     * })
     * 
     */
    create<T extends OrderCreateArgs>(args: SelectSubset<T, OrderCreateArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Orders.
     * @param {OrderCreateManyArgs} args - Arguments to create many Orders.
     * @example
     * // Create many Orders
     * const order = await prisma.order.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends OrderCreateManyArgs>(args?: SelectSubset<T, OrderCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Orders and returns the data saved in the database.
     * @param {OrderCreateManyAndReturnArgs} args - Arguments to create many Orders.
     * @example
     * // Create many Orders
     * const order = await prisma.order.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Orders and only return the `id`
     * const orderWithIdOnly = await prisma.order.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends OrderCreateManyAndReturnArgs>(args?: SelectSubset<T, OrderCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Order.
     * @param {OrderDeleteArgs} args - Arguments to delete one Order.
     * @example
     * // Delete one Order
     * const Order = await prisma.order.delete({
     *   where: {
     *     // ... filter to delete one Order
     *   }
     * })
     * 
     */
    delete<T extends OrderDeleteArgs>(args: SelectSubset<T, OrderDeleteArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Order.
     * @param {OrderUpdateArgs} args - Arguments to update one Order.
     * @example
     * // Update one Order
     * const order = await prisma.order.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends OrderUpdateArgs>(args: SelectSubset<T, OrderUpdateArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Orders.
     * @param {OrderDeleteManyArgs} args - Arguments to filter Orders to delete.
     * @example
     * // Delete a few Orders
     * const { count } = await prisma.order.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends OrderDeleteManyArgs>(args?: SelectSubset<T, OrderDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Orders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Orders
     * const order = await prisma.order.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends OrderUpdateManyArgs>(args: SelectSubset<T, OrderUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Orders and returns the data updated in the database.
     * @param {OrderUpdateManyAndReturnArgs} args - Arguments to update many Orders.
     * @example
     * // Update many Orders
     * const order = await prisma.order.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Orders and only return the `id`
     * const orderWithIdOnly = await prisma.order.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends OrderUpdateManyAndReturnArgs>(args: SelectSubset<T, OrderUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Order.
     * @param {OrderUpsertArgs} args - Arguments to update or create a Order.
     * @example
     * // Update or create a Order
     * const order = await prisma.order.upsert({
     *   create: {
     *     // ... data to create a Order
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Order we want to update
     *   }
     * })
     */
    upsert<T extends OrderUpsertArgs>(args: SelectSubset<T, OrderUpsertArgs<ExtArgs>>): Prisma__OrderClient<$Result.GetResult<Prisma.$OrderPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Orders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderCountArgs} args - Arguments to filter Orders to count.
     * @example
     * // Count the number of Orders
     * const count = await prisma.order.count({
     *   where: {
     *     // ... the filter for the Orders we want to count
     *   }
     * })
    **/
    count<T extends OrderCountArgs>(
      args?: Subset<T, OrderCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OrderCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Order.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OrderAggregateArgs>(args: Subset<T, OrderAggregateArgs>): Prisma.PrismaPromise<GetOrderAggregateType<T>>

    /**
     * Group by Order.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends OrderGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: OrderGroupByArgs['orderBy'] }
        : { orderBy?: OrderGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, OrderGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrderGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Order model
   */
  readonly fields: OrderFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Order.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__OrderClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    buyer<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    marketItem<T extends MarketItemDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MarketItemDefaultArgs<ExtArgs>>): Prisma__MarketItemClient<$Result.GetResult<Prisma.$MarketItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Order model
   */
  interface OrderFieldRefs {
    readonly id: FieldRef<"Order", 'Int'>
    readonly buyerId: FieldRef<"Order", 'String'>
    readonly marketItemId: FieldRef<"Order", 'Int'>
    readonly quantity: FieldRef<"Order", 'Int'>
    readonly totalPrice: FieldRef<"Order", 'Int'>
    readonly createdAt: FieldRef<"Order", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Order findUnique
   */
  export type OrderFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter, which Order to fetch.
     */
    where: OrderWhereUniqueInput
  }

  /**
   * Order findUniqueOrThrow
   */
  export type OrderFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter, which Order to fetch.
     */
    where: OrderWhereUniqueInput
  }

  /**
   * Order findFirst
   */
  export type OrderFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter, which Order to fetch.
     */
    where?: OrderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Orders to fetch.
     */
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Orders.
     */
    cursor?: OrderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Orders.
     */
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * Order findFirstOrThrow
   */
  export type OrderFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter, which Order to fetch.
     */
    where?: OrderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Orders to fetch.
     */
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Orders.
     */
    cursor?: OrderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Orders.
     */
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * Order findMany
   */
  export type OrderFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter, which Orders to fetch.
     */
    where?: OrderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Orders to fetch.
     */
    orderBy?: OrderOrderByWithRelationInput | OrderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Orders.
     */
    cursor?: OrderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Orders.
     */
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * Order create
   */
  export type OrderCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * The data needed to create a Order.
     */
    data: XOR<OrderCreateInput, OrderUncheckedCreateInput>
  }

  /**
   * Order createMany
   */
  export type OrderCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Orders.
     */
    data: OrderCreateManyInput | OrderCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Order createManyAndReturn
   */
  export type OrderCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * The data used to create many Orders.
     */
    data: OrderCreateManyInput | OrderCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Order update
   */
  export type OrderUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * The data needed to update a Order.
     */
    data: XOR<OrderUpdateInput, OrderUncheckedUpdateInput>
    /**
     * Choose, which Order to update.
     */
    where: OrderWhereUniqueInput
  }

  /**
   * Order updateMany
   */
  export type OrderUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Orders.
     */
    data: XOR<OrderUpdateManyMutationInput, OrderUncheckedUpdateManyInput>
    /**
     * Filter which Orders to update
     */
    where?: OrderWhereInput
    /**
     * Limit how many Orders to update.
     */
    limit?: number
  }

  /**
   * Order updateManyAndReturn
   */
  export type OrderUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * The data used to update Orders.
     */
    data: XOR<OrderUpdateManyMutationInput, OrderUncheckedUpdateManyInput>
    /**
     * Filter which Orders to update
     */
    where?: OrderWhereInput
    /**
     * Limit how many Orders to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Order upsert
   */
  export type OrderUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * The filter to search for the Order to update in case it exists.
     */
    where: OrderWhereUniqueInput
    /**
     * In case the Order found by the `where` argument doesn't exist, create a new Order with this data.
     */
    create: XOR<OrderCreateInput, OrderUncheckedCreateInput>
    /**
     * In case the Order was found with the provided `where` argument, update it with this data.
     */
    update: XOR<OrderUpdateInput, OrderUncheckedUpdateInput>
  }

  /**
   * Order delete
   */
  export type OrderDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
    /**
     * Filter which Order to delete.
     */
    where: OrderWhereUniqueInput
  }

  /**
   * Order deleteMany
   */
  export type OrderDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Orders to delete
     */
    where?: OrderWhereInput
    /**
     * Limit how many Orders to delete.
     */
    limit?: number
  }

  /**
   * Order without action
   */
  export type OrderDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Order
     */
    select?: OrderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Order
     */
    omit?: OrderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrderInclude<ExtArgs> | null
  }


  /**
   * Model PointLog
   */

  export type AggregatePointLog = {
    _count: PointLogCountAggregateOutputType | null
    _avg: PointLogAvgAggregateOutputType | null
    _sum: PointLogSumAggregateOutputType | null
    _min: PointLogMinAggregateOutputType | null
    _max: PointLogMaxAggregateOutputType | null
  }

  export type PointLogAvgAggregateOutputType = {
    id: number | null
    amount: number | null
  }

  export type PointLogSumAggregateOutputType = {
    id: number | null
    amount: number | null
  }

  export type PointLogMinAggregateOutputType = {
    id: number | null
    userId: string | null
    type: $Enums.PointLogType | null
    amount: number | null
    createdAt: Date | null
  }

  export type PointLogMaxAggregateOutputType = {
    id: number | null
    userId: string | null
    type: $Enums.PointLogType | null
    amount: number | null
    createdAt: Date | null
  }

  export type PointLogCountAggregateOutputType = {
    id: number
    userId: number
    type: number
    amount: number
    createdAt: number
    _all: number
  }


  export type PointLogAvgAggregateInputType = {
    id?: true
    amount?: true
  }

  export type PointLogSumAggregateInputType = {
    id?: true
    amount?: true
  }

  export type PointLogMinAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    amount?: true
    createdAt?: true
  }

  export type PointLogMaxAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    amount?: true
    createdAt?: true
  }

  export type PointLogCountAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    amount?: true
    createdAt?: true
    _all?: true
  }

  export type PointLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PointLog to aggregate.
     */
    where?: PointLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PointLogs to fetch.
     */
    orderBy?: PointLogOrderByWithRelationInput | PointLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PointLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PointLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PointLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PointLogs
    **/
    _count?: true | PointLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PointLogAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PointLogSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PointLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PointLogMaxAggregateInputType
  }

  export type GetPointLogAggregateType<T extends PointLogAggregateArgs> = {
        [P in keyof T & keyof AggregatePointLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePointLog[P]>
      : GetScalarType<T[P], AggregatePointLog[P]>
  }




  export type PointLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PointLogWhereInput
    orderBy?: PointLogOrderByWithAggregationInput | PointLogOrderByWithAggregationInput[]
    by: PointLogScalarFieldEnum[] | PointLogScalarFieldEnum
    having?: PointLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PointLogCountAggregateInputType | true
    _avg?: PointLogAvgAggregateInputType
    _sum?: PointLogSumAggregateInputType
    _min?: PointLogMinAggregateInputType
    _max?: PointLogMaxAggregateInputType
  }

  export type PointLogGroupByOutputType = {
    id: number
    userId: string
    type: $Enums.PointLogType
    amount: number
    createdAt: Date
    _count: PointLogCountAggregateOutputType | null
    _avg: PointLogAvgAggregateOutputType | null
    _sum: PointLogSumAggregateOutputType | null
    _min: PointLogMinAggregateOutputType | null
    _max: PointLogMaxAggregateOutputType | null
  }

  type GetPointLogGroupByPayload<T extends PointLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PointLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PointLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PointLogGroupByOutputType[P]>
            : GetScalarType<T[P], PointLogGroupByOutputType[P]>
        }
      >
    >


  export type PointLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    amount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pointLog"]>

  export type PointLogSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    amount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pointLog"]>

  export type PointLogSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    amount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pointLog"]>

  export type PointLogSelectScalar = {
    id?: boolean
    userId?: boolean
    type?: boolean
    amount?: boolean
    createdAt?: boolean
  }

  export type PointLogOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "type" | "amount" | "createdAt", ExtArgs["result"]["pointLog"]>
  export type PointLogInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type PointLogIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type PointLogIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $PointLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PointLog"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: string
      type: $Enums.PointLogType
      amount: number
      createdAt: Date
    }, ExtArgs["result"]["pointLog"]>
    composites: {}
  }

  type PointLogGetPayload<S extends boolean | null | undefined | PointLogDefaultArgs> = $Result.GetResult<Prisma.$PointLogPayload, S>

  type PointLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PointLogFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PointLogCountAggregateInputType | true
    }

  export interface PointLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PointLog'], meta: { name: 'PointLog' } }
    /**
     * Find zero or one PointLog that matches the filter.
     * @param {PointLogFindUniqueArgs} args - Arguments to find a PointLog
     * @example
     * // Get one PointLog
     * const pointLog = await prisma.pointLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PointLogFindUniqueArgs>(args: SelectSubset<T, PointLogFindUniqueArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PointLog that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PointLogFindUniqueOrThrowArgs} args - Arguments to find a PointLog
     * @example
     * // Get one PointLog
     * const pointLog = await prisma.pointLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PointLogFindUniqueOrThrowArgs>(args: SelectSubset<T, PointLogFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PointLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogFindFirstArgs} args - Arguments to find a PointLog
     * @example
     * // Get one PointLog
     * const pointLog = await prisma.pointLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PointLogFindFirstArgs>(args?: SelectSubset<T, PointLogFindFirstArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PointLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogFindFirstOrThrowArgs} args - Arguments to find a PointLog
     * @example
     * // Get one PointLog
     * const pointLog = await prisma.pointLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PointLogFindFirstOrThrowArgs>(args?: SelectSubset<T, PointLogFindFirstOrThrowArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PointLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PointLogs
     * const pointLogs = await prisma.pointLog.findMany()
     * 
     * // Get first 10 PointLogs
     * const pointLogs = await prisma.pointLog.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const pointLogWithIdOnly = await prisma.pointLog.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PointLogFindManyArgs>(args?: SelectSubset<T, PointLogFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PointLog.
     * @param {PointLogCreateArgs} args - Arguments to create a PointLog.
     * @example
     * // Create one PointLog
     * const PointLog = await prisma.pointLog.create({
     *   data: {
     *     // ... data to create a PointLog
     *   }
     * })
     * 
     */
    create<T extends PointLogCreateArgs>(args: SelectSubset<T, PointLogCreateArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PointLogs.
     * @param {PointLogCreateManyArgs} args - Arguments to create many PointLogs.
     * @example
     * // Create many PointLogs
     * const pointLog = await prisma.pointLog.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PointLogCreateManyArgs>(args?: SelectSubset<T, PointLogCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PointLogs and returns the data saved in the database.
     * @param {PointLogCreateManyAndReturnArgs} args - Arguments to create many PointLogs.
     * @example
     * // Create many PointLogs
     * const pointLog = await prisma.pointLog.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PointLogs and only return the `id`
     * const pointLogWithIdOnly = await prisma.pointLog.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PointLogCreateManyAndReturnArgs>(args?: SelectSubset<T, PointLogCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PointLog.
     * @param {PointLogDeleteArgs} args - Arguments to delete one PointLog.
     * @example
     * // Delete one PointLog
     * const PointLog = await prisma.pointLog.delete({
     *   where: {
     *     // ... filter to delete one PointLog
     *   }
     * })
     * 
     */
    delete<T extends PointLogDeleteArgs>(args: SelectSubset<T, PointLogDeleteArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PointLog.
     * @param {PointLogUpdateArgs} args - Arguments to update one PointLog.
     * @example
     * // Update one PointLog
     * const pointLog = await prisma.pointLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PointLogUpdateArgs>(args: SelectSubset<T, PointLogUpdateArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PointLogs.
     * @param {PointLogDeleteManyArgs} args - Arguments to filter PointLogs to delete.
     * @example
     * // Delete a few PointLogs
     * const { count } = await prisma.pointLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PointLogDeleteManyArgs>(args?: SelectSubset<T, PointLogDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PointLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PointLogs
     * const pointLog = await prisma.pointLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PointLogUpdateManyArgs>(args: SelectSubset<T, PointLogUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PointLogs and returns the data updated in the database.
     * @param {PointLogUpdateManyAndReturnArgs} args - Arguments to update many PointLogs.
     * @example
     * // Update many PointLogs
     * const pointLog = await prisma.pointLog.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PointLogs and only return the `id`
     * const pointLogWithIdOnly = await prisma.pointLog.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PointLogUpdateManyAndReturnArgs>(args: SelectSubset<T, PointLogUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PointLog.
     * @param {PointLogUpsertArgs} args - Arguments to update or create a PointLog.
     * @example
     * // Update or create a PointLog
     * const pointLog = await prisma.pointLog.upsert({
     *   create: {
     *     // ... data to create a PointLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PointLog we want to update
     *   }
     * })
     */
    upsert<T extends PointLogUpsertArgs>(args: SelectSubset<T, PointLogUpsertArgs<ExtArgs>>): Prisma__PointLogClient<$Result.GetResult<Prisma.$PointLogPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PointLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogCountArgs} args - Arguments to filter PointLogs to count.
     * @example
     * // Count the number of PointLogs
     * const count = await prisma.pointLog.count({
     *   where: {
     *     // ... the filter for the PointLogs we want to count
     *   }
     * })
    **/
    count<T extends PointLogCountArgs>(
      args?: Subset<T, PointLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PointLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PointLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PointLogAggregateArgs>(args: Subset<T, PointLogAggregateArgs>): Prisma.PrismaPromise<GetPointLogAggregateType<T>>

    /**
     * Group by PointLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PointLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PointLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PointLogGroupByArgs['orderBy'] }
        : { orderBy?: PointLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PointLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPointLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PointLog model
   */
  readonly fields: PointLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PointLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PointLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PointLog model
   */
  interface PointLogFieldRefs {
    readonly id: FieldRef<"PointLog", 'Int'>
    readonly userId: FieldRef<"PointLog", 'String'>
    readonly type: FieldRef<"PointLog", 'PointLogType'>
    readonly amount: FieldRef<"PointLog", 'Int'>
    readonly createdAt: FieldRef<"PointLog", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PointLog findUnique
   */
  export type PointLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter, which PointLog to fetch.
     */
    where: PointLogWhereUniqueInput
  }

  /**
   * PointLog findUniqueOrThrow
   */
  export type PointLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter, which PointLog to fetch.
     */
    where: PointLogWhereUniqueInput
  }

  /**
   * PointLog findFirst
   */
  export type PointLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter, which PointLog to fetch.
     */
    where?: PointLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PointLogs to fetch.
     */
    orderBy?: PointLogOrderByWithRelationInput | PointLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PointLogs.
     */
    cursor?: PointLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PointLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PointLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PointLogs.
     */
    distinct?: PointLogScalarFieldEnum | PointLogScalarFieldEnum[]
  }

  /**
   * PointLog findFirstOrThrow
   */
  export type PointLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter, which PointLog to fetch.
     */
    where?: PointLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PointLogs to fetch.
     */
    orderBy?: PointLogOrderByWithRelationInput | PointLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PointLogs.
     */
    cursor?: PointLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PointLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PointLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PointLogs.
     */
    distinct?: PointLogScalarFieldEnum | PointLogScalarFieldEnum[]
  }

  /**
   * PointLog findMany
   */
  export type PointLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter, which PointLogs to fetch.
     */
    where?: PointLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PointLogs to fetch.
     */
    orderBy?: PointLogOrderByWithRelationInput | PointLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PointLogs.
     */
    cursor?: PointLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PointLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PointLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PointLogs.
     */
    distinct?: PointLogScalarFieldEnum | PointLogScalarFieldEnum[]
  }

  /**
   * PointLog create
   */
  export type PointLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * The data needed to create a PointLog.
     */
    data: XOR<PointLogCreateInput, PointLogUncheckedCreateInput>
  }

  /**
   * PointLog createMany
   */
  export type PointLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PointLogs.
     */
    data: PointLogCreateManyInput | PointLogCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PointLog createManyAndReturn
   */
  export type PointLogCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * The data used to create many PointLogs.
     */
    data: PointLogCreateManyInput | PointLogCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PointLog update
   */
  export type PointLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * The data needed to update a PointLog.
     */
    data: XOR<PointLogUpdateInput, PointLogUncheckedUpdateInput>
    /**
     * Choose, which PointLog to update.
     */
    where: PointLogWhereUniqueInput
  }

  /**
   * PointLog updateMany
   */
  export type PointLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PointLogs.
     */
    data: XOR<PointLogUpdateManyMutationInput, PointLogUncheckedUpdateManyInput>
    /**
     * Filter which PointLogs to update
     */
    where?: PointLogWhereInput
    /**
     * Limit how many PointLogs to update.
     */
    limit?: number
  }

  /**
   * PointLog updateManyAndReturn
   */
  export type PointLogUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * The data used to update PointLogs.
     */
    data: XOR<PointLogUpdateManyMutationInput, PointLogUncheckedUpdateManyInput>
    /**
     * Filter which PointLogs to update
     */
    where?: PointLogWhereInput
    /**
     * Limit how many PointLogs to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PointLog upsert
   */
  export type PointLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * The filter to search for the PointLog to update in case it exists.
     */
    where: PointLogWhereUniqueInput
    /**
     * In case the PointLog found by the `where` argument doesn't exist, create a new PointLog with this data.
     */
    create: XOR<PointLogCreateInput, PointLogUncheckedCreateInput>
    /**
     * In case the PointLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PointLogUpdateInput, PointLogUncheckedUpdateInput>
  }

  /**
   * PointLog delete
   */
  export type PointLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
    /**
     * Filter which PointLog to delete.
     */
    where: PointLogWhereUniqueInput
  }

  /**
   * PointLog deleteMany
   */
  export type PointLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PointLogs to delete
     */
    where?: PointLogWhereInput
    /**
     * Limit how many PointLogs to delete.
     */
    limit?: number
  }

  /**
   * PointLog without action
   */
  export type PointLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PointLog
     */
    select?: PointLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PointLog
     */
    omit?: PointLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PointLogInclude<ExtArgs> | null
  }


  /**
   * Model Notification
   */

  export type AggregateNotification = {
    _count: NotificationCountAggregateOutputType | null
    _avg: NotificationAvgAggregateOutputType | null
    _sum: NotificationSumAggregateOutputType | null
    _min: NotificationMinAggregateOutputType | null
    _max: NotificationMaxAggregateOutputType | null
  }

  export type NotificationAvgAggregateOutputType = {
    id: number | null
    targetId: number | null
  }

  export type NotificationSumAggregateOutputType = {
    id: number | null
    targetId: number | null
  }

  export type NotificationMinAggregateOutputType = {
    id: number | null
    userId: string | null
    type: $Enums.NotificationType | null
    routeType: $Enums.RouteType | null
    targetId: number | null
    message: string | null
    isRead: boolean | null
    createdAt: Date | null
  }

  export type NotificationMaxAggregateOutputType = {
    id: number | null
    userId: string | null
    type: $Enums.NotificationType | null
    routeType: $Enums.RouteType | null
    targetId: number | null
    message: string | null
    isRead: boolean | null
    createdAt: Date | null
  }

  export type NotificationCountAggregateOutputType = {
    id: number
    userId: number
    type: number
    routeType: number
    targetId: number
    message: number
    isRead: number
    createdAt: number
    _all: number
  }


  export type NotificationAvgAggregateInputType = {
    id?: true
    targetId?: true
  }

  export type NotificationSumAggregateInputType = {
    id?: true
    targetId?: true
  }

  export type NotificationMinAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    routeType?: true
    targetId?: true
    message?: true
    isRead?: true
    createdAt?: true
  }

  export type NotificationMaxAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    routeType?: true
    targetId?: true
    message?: true
    isRead?: true
    createdAt?: true
  }

  export type NotificationCountAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    routeType?: true
    targetId?: true
    message?: true
    isRead?: true
    createdAt?: true
    _all?: true
  }

  export type NotificationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Notification to aggregate.
     */
    where?: NotificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Notifications to fetch.
     */
    orderBy?: NotificationOrderByWithRelationInput | NotificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: NotificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Notifications
    **/
    _count?: true | NotificationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: NotificationAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: NotificationSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: NotificationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: NotificationMaxAggregateInputType
  }

  export type GetNotificationAggregateType<T extends NotificationAggregateArgs> = {
        [P in keyof T & keyof AggregateNotification]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateNotification[P]>
      : GetScalarType<T[P], AggregateNotification[P]>
  }




  export type NotificationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: NotificationWhereInput
    orderBy?: NotificationOrderByWithAggregationInput | NotificationOrderByWithAggregationInput[]
    by: NotificationScalarFieldEnum[] | NotificationScalarFieldEnum
    having?: NotificationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: NotificationCountAggregateInputType | true
    _avg?: NotificationAvgAggregateInputType
    _sum?: NotificationSumAggregateInputType
    _min?: NotificationMinAggregateInputType
    _max?: NotificationMaxAggregateInputType
  }

  export type NotificationGroupByOutputType = {
    id: number
    userId: string
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId: number | null
    message: string
    isRead: boolean
    createdAt: Date
    _count: NotificationCountAggregateOutputType | null
    _avg: NotificationAvgAggregateOutputType | null
    _sum: NotificationSumAggregateOutputType | null
    _min: NotificationMinAggregateOutputType | null
    _max: NotificationMaxAggregateOutputType | null
  }

  type GetNotificationGroupByPayload<T extends NotificationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<NotificationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof NotificationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], NotificationGroupByOutputType[P]>
            : GetScalarType<T[P], NotificationGroupByOutputType[P]>
        }
      >
    >


  export type NotificationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    routeType?: boolean
    targetId?: boolean
    message?: boolean
    isRead?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type NotificationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    routeType?: boolean
    targetId?: boolean
    message?: boolean
    isRead?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type NotificationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    routeType?: boolean
    targetId?: boolean
    message?: boolean
    isRead?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type NotificationSelectScalar = {
    id?: boolean
    userId?: boolean
    type?: boolean
    routeType?: boolean
    targetId?: boolean
    message?: boolean
    isRead?: boolean
    createdAt?: boolean
  }

  export type NotificationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "type" | "routeType" | "targetId" | "message" | "isRead" | "createdAt", ExtArgs["result"]["notification"]>
  export type NotificationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type NotificationIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type NotificationIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $NotificationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Notification"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: string
      type: $Enums.NotificationType
      routeType: $Enums.RouteType
      targetId: number | null
      message: string
      isRead: boolean
      createdAt: Date
    }, ExtArgs["result"]["notification"]>
    composites: {}
  }

  type NotificationGetPayload<S extends boolean | null | undefined | NotificationDefaultArgs> = $Result.GetResult<Prisma.$NotificationPayload, S>

  type NotificationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<NotificationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: NotificationCountAggregateInputType | true
    }

  export interface NotificationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Notification'], meta: { name: 'Notification' } }
    /**
     * Find zero or one Notification that matches the filter.
     * @param {NotificationFindUniqueArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends NotificationFindUniqueArgs>(args: SelectSubset<T, NotificationFindUniqueArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Notification that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {NotificationFindUniqueOrThrowArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends NotificationFindUniqueOrThrowArgs>(args: SelectSubset<T, NotificationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Notification that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationFindFirstArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends NotificationFindFirstArgs>(args?: SelectSubset<T, NotificationFindFirstArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Notification that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationFindFirstOrThrowArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends NotificationFindFirstOrThrowArgs>(args?: SelectSubset<T, NotificationFindFirstOrThrowArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Notifications that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Notifications
     * const notifications = await prisma.notification.findMany()
     * 
     * // Get first 10 Notifications
     * const notifications = await prisma.notification.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const notificationWithIdOnly = await prisma.notification.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends NotificationFindManyArgs>(args?: SelectSubset<T, NotificationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Notification.
     * @param {NotificationCreateArgs} args - Arguments to create a Notification.
     * @example
     * // Create one Notification
     * const Notification = await prisma.notification.create({
     *   data: {
     *     // ... data to create a Notification
     *   }
     * })
     * 
     */
    create<T extends NotificationCreateArgs>(args: SelectSubset<T, NotificationCreateArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Notifications.
     * @param {NotificationCreateManyArgs} args - Arguments to create many Notifications.
     * @example
     * // Create many Notifications
     * const notification = await prisma.notification.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends NotificationCreateManyArgs>(args?: SelectSubset<T, NotificationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Notifications and returns the data saved in the database.
     * @param {NotificationCreateManyAndReturnArgs} args - Arguments to create many Notifications.
     * @example
     * // Create many Notifications
     * const notification = await prisma.notification.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Notifications and only return the `id`
     * const notificationWithIdOnly = await prisma.notification.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends NotificationCreateManyAndReturnArgs>(args?: SelectSubset<T, NotificationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Notification.
     * @param {NotificationDeleteArgs} args - Arguments to delete one Notification.
     * @example
     * // Delete one Notification
     * const Notification = await prisma.notification.delete({
     *   where: {
     *     // ... filter to delete one Notification
     *   }
     * })
     * 
     */
    delete<T extends NotificationDeleteArgs>(args: SelectSubset<T, NotificationDeleteArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Notification.
     * @param {NotificationUpdateArgs} args - Arguments to update one Notification.
     * @example
     * // Update one Notification
     * const notification = await prisma.notification.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends NotificationUpdateArgs>(args: SelectSubset<T, NotificationUpdateArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Notifications.
     * @param {NotificationDeleteManyArgs} args - Arguments to filter Notifications to delete.
     * @example
     * // Delete a few Notifications
     * const { count } = await prisma.notification.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends NotificationDeleteManyArgs>(args?: SelectSubset<T, NotificationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Notifications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Notifications
     * const notification = await prisma.notification.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends NotificationUpdateManyArgs>(args: SelectSubset<T, NotificationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Notifications and returns the data updated in the database.
     * @param {NotificationUpdateManyAndReturnArgs} args - Arguments to update many Notifications.
     * @example
     * // Update many Notifications
     * const notification = await prisma.notification.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Notifications and only return the `id`
     * const notificationWithIdOnly = await prisma.notification.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends NotificationUpdateManyAndReturnArgs>(args: SelectSubset<T, NotificationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Notification.
     * @param {NotificationUpsertArgs} args - Arguments to update or create a Notification.
     * @example
     * // Update or create a Notification
     * const notification = await prisma.notification.upsert({
     *   create: {
     *     // ... data to create a Notification
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Notification we want to update
     *   }
     * })
     */
    upsert<T extends NotificationUpsertArgs>(args: SelectSubset<T, NotificationUpsertArgs<ExtArgs>>): Prisma__NotificationClient<$Result.GetResult<Prisma.$NotificationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Notifications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationCountArgs} args - Arguments to filter Notifications to count.
     * @example
     * // Count the number of Notifications
     * const count = await prisma.notification.count({
     *   where: {
     *     // ... the filter for the Notifications we want to count
     *   }
     * })
    **/
    count<T extends NotificationCountArgs>(
      args?: Subset<T, NotificationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], NotificationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Notification.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends NotificationAggregateArgs>(args: Subset<T, NotificationAggregateArgs>): Prisma.PrismaPromise<GetNotificationAggregateType<T>>

    /**
     * Group by Notification.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends NotificationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: NotificationGroupByArgs['orderBy'] }
        : { orderBy?: NotificationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, NotificationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNotificationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Notification model
   */
  readonly fields: NotificationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Notification.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__NotificationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Notification model
   */
  interface NotificationFieldRefs {
    readonly id: FieldRef<"Notification", 'Int'>
    readonly userId: FieldRef<"Notification", 'String'>
    readonly type: FieldRef<"Notification", 'NotificationType'>
    readonly routeType: FieldRef<"Notification", 'RouteType'>
    readonly targetId: FieldRef<"Notification", 'Int'>
    readonly message: FieldRef<"Notification", 'String'>
    readonly isRead: FieldRef<"Notification", 'Boolean'>
    readonly createdAt: FieldRef<"Notification", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Notification findUnique
   */
  export type NotificationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter, which Notification to fetch.
     */
    where: NotificationWhereUniqueInput
  }

  /**
   * Notification findUniqueOrThrow
   */
  export type NotificationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter, which Notification to fetch.
     */
    where: NotificationWhereUniqueInput
  }

  /**
   * Notification findFirst
   */
  export type NotificationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter, which Notification to fetch.
     */
    where?: NotificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Notifications to fetch.
     */
    orderBy?: NotificationOrderByWithRelationInput | NotificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Notifications.
     */
    cursor?: NotificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Notifications.
     */
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * Notification findFirstOrThrow
   */
  export type NotificationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter, which Notification to fetch.
     */
    where?: NotificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Notifications to fetch.
     */
    orderBy?: NotificationOrderByWithRelationInput | NotificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Notifications.
     */
    cursor?: NotificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Notifications.
     */
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * Notification findMany
   */
  export type NotificationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter, which Notifications to fetch.
     */
    where?: NotificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Notifications to fetch.
     */
    orderBy?: NotificationOrderByWithRelationInput | NotificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Notifications.
     */
    cursor?: NotificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Notifications.
     */
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * Notification create
   */
  export type NotificationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * The data needed to create a Notification.
     */
    data: XOR<NotificationCreateInput, NotificationUncheckedCreateInput>
  }

  /**
   * Notification createMany
   */
  export type NotificationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Notifications.
     */
    data: NotificationCreateManyInput | NotificationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Notification createManyAndReturn
   */
  export type NotificationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * The data used to create many Notifications.
     */
    data: NotificationCreateManyInput | NotificationCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Notification update
   */
  export type NotificationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * The data needed to update a Notification.
     */
    data: XOR<NotificationUpdateInput, NotificationUncheckedUpdateInput>
    /**
     * Choose, which Notification to update.
     */
    where: NotificationWhereUniqueInput
  }

  /**
   * Notification updateMany
   */
  export type NotificationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Notifications.
     */
    data: XOR<NotificationUpdateManyMutationInput, NotificationUncheckedUpdateManyInput>
    /**
     * Filter which Notifications to update
     */
    where?: NotificationWhereInput
    /**
     * Limit how many Notifications to update.
     */
    limit?: number
  }

  /**
   * Notification updateManyAndReturn
   */
  export type NotificationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * The data used to update Notifications.
     */
    data: XOR<NotificationUpdateManyMutationInput, NotificationUncheckedUpdateManyInput>
    /**
     * Filter which Notifications to update
     */
    where?: NotificationWhereInput
    /**
     * Limit how many Notifications to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Notification upsert
   */
  export type NotificationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * The filter to search for the Notification to update in case it exists.
     */
    where: NotificationWhereUniqueInput
    /**
     * In case the Notification found by the `where` argument doesn't exist, create a new Notification with this data.
     */
    create: XOR<NotificationCreateInput, NotificationUncheckedCreateInput>
    /**
     * In case the Notification was found with the provided `where` argument, update it with this data.
     */
    update: XOR<NotificationUpdateInput, NotificationUncheckedUpdateInput>
  }

  /**
   * Notification delete
   */
  export type NotificationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
    /**
     * Filter which Notification to delete.
     */
    where: NotificationWhereUniqueInput
  }

  /**
   * Notification deleteMany
   */
  export type NotificationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Notifications to delete
     */
    where?: NotificationWhereInput
    /**
     * Limit how many Notifications to delete.
     */
    limit?: number
  }

  /**
   * Notification without action
   */
  export type NotificationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Notification
     */
    select?: NotificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Notification
     */
    omit?: NotificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NotificationInclude<ExtArgs> | null
  }


  /**
   * Model CardCreationLog
   */

  export type AggregateCardCreationLog = {
    _count: CardCreationLogCountAggregateOutputType | null
    _avg: CardCreationLogAvgAggregateOutputType | null
    _sum: CardCreationLogSumAggregateOutputType | null
    _min: CardCreationLogMinAggregateOutputType | null
    _max: CardCreationLogMaxAggregateOutputType | null
  }

  export type CardCreationLogAvgAggregateOutputType = {
    id: number | null
    year: number | null
    month: number | null
    count: number | null
  }

  export type CardCreationLogSumAggregateOutputType = {
    id: number | null
    year: number | null
    month: number | null
    count: number | null
  }

  export type CardCreationLogMinAggregateOutputType = {
    id: number | null
    userId: string | null
    year: number | null
    month: number | null
    count: number | null
  }

  export type CardCreationLogMaxAggregateOutputType = {
    id: number | null
    userId: string | null
    year: number | null
    month: number | null
    count: number | null
  }

  export type CardCreationLogCountAggregateOutputType = {
    id: number
    userId: number
    year: number
    month: number
    count: number
    _all: number
  }


  export type CardCreationLogAvgAggregateInputType = {
    id?: true
    year?: true
    month?: true
    count?: true
  }

  export type CardCreationLogSumAggregateInputType = {
    id?: true
    year?: true
    month?: true
    count?: true
  }

  export type CardCreationLogMinAggregateInputType = {
    id?: true
    userId?: true
    year?: true
    month?: true
    count?: true
  }

  export type CardCreationLogMaxAggregateInputType = {
    id?: true
    userId?: true
    year?: true
    month?: true
    count?: true
  }

  export type CardCreationLogCountAggregateInputType = {
    id?: true
    userId?: true
    year?: true
    month?: true
    count?: true
    _all?: true
  }

  export type CardCreationLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CardCreationLog to aggregate.
     */
    where?: CardCreationLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CardCreationLogs to fetch.
     */
    orderBy?: CardCreationLogOrderByWithRelationInput | CardCreationLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CardCreationLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CardCreationLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CardCreationLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CardCreationLogs
    **/
    _count?: true | CardCreationLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CardCreationLogAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CardCreationLogSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CardCreationLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CardCreationLogMaxAggregateInputType
  }

  export type GetCardCreationLogAggregateType<T extends CardCreationLogAggregateArgs> = {
        [P in keyof T & keyof AggregateCardCreationLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCardCreationLog[P]>
      : GetScalarType<T[P], AggregateCardCreationLog[P]>
  }




  export type CardCreationLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CardCreationLogWhereInput
    orderBy?: CardCreationLogOrderByWithAggregationInput | CardCreationLogOrderByWithAggregationInput[]
    by: CardCreationLogScalarFieldEnum[] | CardCreationLogScalarFieldEnum
    having?: CardCreationLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CardCreationLogCountAggregateInputType | true
    _avg?: CardCreationLogAvgAggregateInputType
    _sum?: CardCreationLogSumAggregateInputType
    _min?: CardCreationLogMinAggregateInputType
    _max?: CardCreationLogMaxAggregateInputType
  }

  export type CardCreationLogGroupByOutputType = {
    id: number
    userId: string
    year: number
    month: number
    count: number
    _count: CardCreationLogCountAggregateOutputType | null
    _avg: CardCreationLogAvgAggregateOutputType | null
    _sum: CardCreationLogSumAggregateOutputType | null
    _min: CardCreationLogMinAggregateOutputType | null
    _max: CardCreationLogMaxAggregateOutputType | null
  }

  type GetCardCreationLogGroupByPayload<T extends CardCreationLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CardCreationLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CardCreationLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CardCreationLogGroupByOutputType[P]>
            : GetScalarType<T[P], CardCreationLogGroupByOutputType[P]>
        }
      >
    >


  export type CardCreationLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    year?: boolean
    month?: boolean
    count?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["cardCreationLog"]>

  export type CardCreationLogSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    year?: boolean
    month?: boolean
    count?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["cardCreationLog"]>

  export type CardCreationLogSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    year?: boolean
    month?: boolean
    count?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["cardCreationLog"]>

  export type CardCreationLogSelectScalar = {
    id?: boolean
    userId?: boolean
    year?: boolean
    month?: boolean
    count?: boolean
  }

  export type CardCreationLogOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "year" | "month" | "count", ExtArgs["result"]["cardCreationLog"]>
  export type CardCreationLogInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type CardCreationLogIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type CardCreationLogIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $CardCreationLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CardCreationLog"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: string
      year: number
      month: number
      count: number
    }, ExtArgs["result"]["cardCreationLog"]>
    composites: {}
  }

  type CardCreationLogGetPayload<S extends boolean | null | undefined | CardCreationLogDefaultArgs> = $Result.GetResult<Prisma.$CardCreationLogPayload, S>

  type CardCreationLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CardCreationLogFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CardCreationLogCountAggregateInputType | true
    }

  export interface CardCreationLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CardCreationLog'], meta: { name: 'CardCreationLog' } }
    /**
     * Find zero or one CardCreationLog that matches the filter.
     * @param {CardCreationLogFindUniqueArgs} args - Arguments to find a CardCreationLog
     * @example
     * // Get one CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CardCreationLogFindUniqueArgs>(args: SelectSubset<T, CardCreationLogFindUniqueArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CardCreationLog that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CardCreationLogFindUniqueOrThrowArgs} args - Arguments to find a CardCreationLog
     * @example
     * // Get one CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CardCreationLogFindUniqueOrThrowArgs>(args: SelectSubset<T, CardCreationLogFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CardCreationLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogFindFirstArgs} args - Arguments to find a CardCreationLog
     * @example
     * // Get one CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CardCreationLogFindFirstArgs>(args?: SelectSubset<T, CardCreationLogFindFirstArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CardCreationLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogFindFirstOrThrowArgs} args - Arguments to find a CardCreationLog
     * @example
     * // Get one CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CardCreationLogFindFirstOrThrowArgs>(args?: SelectSubset<T, CardCreationLogFindFirstOrThrowArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CardCreationLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CardCreationLogs
     * const cardCreationLogs = await prisma.cardCreationLog.findMany()
     * 
     * // Get first 10 CardCreationLogs
     * const cardCreationLogs = await prisma.cardCreationLog.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const cardCreationLogWithIdOnly = await prisma.cardCreationLog.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CardCreationLogFindManyArgs>(args?: SelectSubset<T, CardCreationLogFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CardCreationLog.
     * @param {CardCreationLogCreateArgs} args - Arguments to create a CardCreationLog.
     * @example
     * // Create one CardCreationLog
     * const CardCreationLog = await prisma.cardCreationLog.create({
     *   data: {
     *     // ... data to create a CardCreationLog
     *   }
     * })
     * 
     */
    create<T extends CardCreationLogCreateArgs>(args: SelectSubset<T, CardCreationLogCreateArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CardCreationLogs.
     * @param {CardCreationLogCreateManyArgs} args - Arguments to create many CardCreationLogs.
     * @example
     * // Create many CardCreationLogs
     * const cardCreationLog = await prisma.cardCreationLog.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CardCreationLogCreateManyArgs>(args?: SelectSubset<T, CardCreationLogCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CardCreationLogs and returns the data saved in the database.
     * @param {CardCreationLogCreateManyAndReturnArgs} args - Arguments to create many CardCreationLogs.
     * @example
     * // Create many CardCreationLogs
     * const cardCreationLog = await prisma.cardCreationLog.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CardCreationLogs and only return the `id`
     * const cardCreationLogWithIdOnly = await prisma.cardCreationLog.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CardCreationLogCreateManyAndReturnArgs>(args?: SelectSubset<T, CardCreationLogCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CardCreationLog.
     * @param {CardCreationLogDeleteArgs} args - Arguments to delete one CardCreationLog.
     * @example
     * // Delete one CardCreationLog
     * const CardCreationLog = await prisma.cardCreationLog.delete({
     *   where: {
     *     // ... filter to delete one CardCreationLog
     *   }
     * })
     * 
     */
    delete<T extends CardCreationLogDeleteArgs>(args: SelectSubset<T, CardCreationLogDeleteArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CardCreationLog.
     * @param {CardCreationLogUpdateArgs} args - Arguments to update one CardCreationLog.
     * @example
     * // Update one CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CardCreationLogUpdateArgs>(args: SelectSubset<T, CardCreationLogUpdateArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CardCreationLogs.
     * @param {CardCreationLogDeleteManyArgs} args - Arguments to filter CardCreationLogs to delete.
     * @example
     * // Delete a few CardCreationLogs
     * const { count } = await prisma.cardCreationLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CardCreationLogDeleteManyArgs>(args?: SelectSubset<T, CardCreationLogDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CardCreationLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CardCreationLogs
     * const cardCreationLog = await prisma.cardCreationLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CardCreationLogUpdateManyArgs>(args: SelectSubset<T, CardCreationLogUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CardCreationLogs and returns the data updated in the database.
     * @param {CardCreationLogUpdateManyAndReturnArgs} args - Arguments to update many CardCreationLogs.
     * @example
     * // Update many CardCreationLogs
     * const cardCreationLog = await prisma.cardCreationLog.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CardCreationLogs and only return the `id`
     * const cardCreationLogWithIdOnly = await prisma.cardCreationLog.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CardCreationLogUpdateManyAndReturnArgs>(args: SelectSubset<T, CardCreationLogUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CardCreationLog.
     * @param {CardCreationLogUpsertArgs} args - Arguments to update or create a CardCreationLog.
     * @example
     * // Update or create a CardCreationLog
     * const cardCreationLog = await prisma.cardCreationLog.upsert({
     *   create: {
     *     // ... data to create a CardCreationLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CardCreationLog we want to update
     *   }
     * })
     */
    upsert<T extends CardCreationLogUpsertArgs>(args: SelectSubset<T, CardCreationLogUpsertArgs<ExtArgs>>): Prisma__CardCreationLogClient<$Result.GetResult<Prisma.$CardCreationLogPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CardCreationLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogCountArgs} args - Arguments to filter CardCreationLogs to count.
     * @example
     * // Count the number of CardCreationLogs
     * const count = await prisma.cardCreationLog.count({
     *   where: {
     *     // ... the filter for the CardCreationLogs we want to count
     *   }
     * })
    **/
    count<T extends CardCreationLogCountArgs>(
      args?: Subset<T, CardCreationLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CardCreationLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CardCreationLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CardCreationLogAggregateArgs>(args: Subset<T, CardCreationLogAggregateArgs>): Prisma.PrismaPromise<GetCardCreationLogAggregateType<T>>

    /**
     * Group by CardCreationLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CardCreationLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CardCreationLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CardCreationLogGroupByArgs['orderBy'] }
        : { orderBy?: CardCreationLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CardCreationLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCardCreationLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CardCreationLog model
   */
  readonly fields: CardCreationLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CardCreationLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CardCreationLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CardCreationLog model
   */
  interface CardCreationLogFieldRefs {
    readonly id: FieldRef<"CardCreationLog", 'Int'>
    readonly userId: FieldRef<"CardCreationLog", 'String'>
    readonly year: FieldRef<"CardCreationLog", 'Int'>
    readonly month: FieldRef<"CardCreationLog", 'Int'>
    readonly count: FieldRef<"CardCreationLog", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * CardCreationLog findUnique
   */
  export type CardCreationLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter, which CardCreationLog to fetch.
     */
    where: CardCreationLogWhereUniqueInput
  }

  /**
   * CardCreationLog findUniqueOrThrow
   */
  export type CardCreationLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter, which CardCreationLog to fetch.
     */
    where: CardCreationLogWhereUniqueInput
  }

  /**
   * CardCreationLog findFirst
   */
  export type CardCreationLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter, which CardCreationLog to fetch.
     */
    where?: CardCreationLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CardCreationLogs to fetch.
     */
    orderBy?: CardCreationLogOrderByWithRelationInput | CardCreationLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CardCreationLogs.
     */
    cursor?: CardCreationLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CardCreationLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CardCreationLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CardCreationLogs.
     */
    distinct?: CardCreationLogScalarFieldEnum | CardCreationLogScalarFieldEnum[]
  }

  /**
   * CardCreationLog findFirstOrThrow
   */
  export type CardCreationLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter, which CardCreationLog to fetch.
     */
    where?: CardCreationLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CardCreationLogs to fetch.
     */
    orderBy?: CardCreationLogOrderByWithRelationInput | CardCreationLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CardCreationLogs.
     */
    cursor?: CardCreationLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CardCreationLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CardCreationLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CardCreationLogs.
     */
    distinct?: CardCreationLogScalarFieldEnum | CardCreationLogScalarFieldEnum[]
  }

  /**
   * CardCreationLog findMany
   */
  export type CardCreationLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter, which CardCreationLogs to fetch.
     */
    where?: CardCreationLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CardCreationLogs to fetch.
     */
    orderBy?: CardCreationLogOrderByWithRelationInput | CardCreationLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CardCreationLogs.
     */
    cursor?: CardCreationLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CardCreationLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CardCreationLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CardCreationLogs.
     */
    distinct?: CardCreationLogScalarFieldEnum | CardCreationLogScalarFieldEnum[]
  }

  /**
   * CardCreationLog create
   */
  export type CardCreationLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * The data needed to create a CardCreationLog.
     */
    data: XOR<CardCreationLogCreateInput, CardCreationLogUncheckedCreateInput>
  }

  /**
   * CardCreationLog createMany
   */
  export type CardCreationLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CardCreationLogs.
     */
    data: CardCreationLogCreateManyInput | CardCreationLogCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CardCreationLog createManyAndReturn
   */
  export type CardCreationLogCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * The data used to create many CardCreationLogs.
     */
    data: CardCreationLogCreateManyInput | CardCreationLogCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * CardCreationLog update
   */
  export type CardCreationLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * The data needed to update a CardCreationLog.
     */
    data: XOR<CardCreationLogUpdateInput, CardCreationLogUncheckedUpdateInput>
    /**
     * Choose, which CardCreationLog to update.
     */
    where: CardCreationLogWhereUniqueInput
  }

  /**
   * CardCreationLog updateMany
   */
  export type CardCreationLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CardCreationLogs.
     */
    data: XOR<CardCreationLogUpdateManyMutationInput, CardCreationLogUncheckedUpdateManyInput>
    /**
     * Filter which CardCreationLogs to update
     */
    where?: CardCreationLogWhereInput
    /**
     * Limit how many CardCreationLogs to update.
     */
    limit?: number
  }

  /**
   * CardCreationLog updateManyAndReturn
   */
  export type CardCreationLogUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * The data used to update CardCreationLogs.
     */
    data: XOR<CardCreationLogUpdateManyMutationInput, CardCreationLogUncheckedUpdateManyInput>
    /**
     * Filter which CardCreationLogs to update
     */
    where?: CardCreationLogWhereInput
    /**
     * Limit how many CardCreationLogs to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * CardCreationLog upsert
   */
  export type CardCreationLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * The filter to search for the CardCreationLog to update in case it exists.
     */
    where: CardCreationLogWhereUniqueInput
    /**
     * In case the CardCreationLog found by the `where` argument doesn't exist, create a new CardCreationLog with this data.
     */
    create: XOR<CardCreationLogCreateInput, CardCreationLogUncheckedCreateInput>
    /**
     * In case the CardCreationLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CardCreationLogUpdateInput, CardCreationLogUncheckedUpdateInput>
  }

  /**
   * CardCreationLog delete
   */
  export type CardCreationLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
    /**
     * Filter which CardCreationLog to delete.
     */
    where: CardCreationLogWhereUniqueInput
  }

  /**
   * CardCreationLog deleteMany
   */
  export type CardCreationLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CardCreationLogs to delete
     */
    where?: CardCreationLogWhereInput
    /**
     * Limit how many CardCreationLogs to delete.
     */
    limit?: number
  }

  /**
   * CardCreationLog without action
   */
  export type CardCreationLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CardCreationLog
     */
    select?: CardCreationLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CardCreationLog
     */
    omit?: CardCreationLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CardCreationLogInclude<ExtArgs> | null
  }


  /**
   * Model RefreshToken
   */

  export type AggregateRefreshToken = {
    _count: RefreshTokenCountAggregateOutputType | null
    _avg: RefreshTokenAvgAggregateOutputType | null
    _sum: RefreshTokenSumAggregateOutputType | null
    _min: RefreshTokenMinAggregateOutputType | null
    _max: RefreshTokenMaxAggregateOutputType | null
  }

  export type RefreshTokenAvgAggregateOutputType = {
    id: number | null
  }

  export type RefreshTokenSumAggregateOutputType = {
    id: number | null
  }

  export type RefreshTokenMinAggregateOutputType = {
    id: number | null
    userId: string | null
    token: string | null
    expiresAt: Date | null
    createdAt: Date | null
  }

  export type RefreshTokenMaxAggregateOutputType = {
    id: number | null
    userId: string | null
    token: string | null
    expiresAt: Date | null
    createdAt: Date | null
  }

  export type RefreshTokenCountAggregateOutputType = {
    id: number
    userId: number
    token: number
    expiresAt: number
    createdAt: number
    _all: number
  }


  export type RefreshTokenAvgAggregateInputType = {
    id?: true
  }

  export type RefreshTokenSumAggregateInputType = {
    id?: true
  }

  export type RefreshTokenMinAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    expiresAt?: true
    createdAt?: true
  }

  export type RefreshTokenMaxAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    expiresAt?: true
    createdAt?: true
  }

  export type RefreshTokenCountAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    expiresAt?: true
    createdAt?: true
    _all?: true
  }

  export type RefreshTokenAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RefreshToken to aggregate.
     */
    where?: RefreshTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RefreshTokens to fetch.
     */
    orderBy?: RefreshTokenOrderByWithRelationInput | RefreshTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: RefreshTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RefreshTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RefreshTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned RefreshTokens
    **/
    _count?: true | RefreshTokenCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RefreshTokenAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RefreshTokenSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RefreshTokenMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RefreshTokenMaxAggregateInputType
  }

  export type GetRefreshTokenAggregateType<T extends RefreshTokenAggregateArgs> = {
        [P in keyof T & keyof AggregateRefreshToken]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRefreshToken[P]>
      : GetScalarType<T[P], AggregateRefreshToken[P]>
  }




  export type RefreshTokenGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RefreshTokenWhereInput
    orderBy?: RefreshTokenOrderByWithAggregationInput | RefreshTokenOrderByWithAggregationInput[]
    by: RefreshTokenScalarFieldEnum[] | RefreshTokenScalarFieldEnum
    having?: RefreshTokenScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RefreshTokenCountAggregateInputType | true
    _avg?: RefreshTokenAvgAggregateInputType
    _sum?: RefreshTokenSumAggregateInputType
    _min?: RefreshTokenMinAggregateInputType
    _max?: RefreshTokenMaxAggregateInputType
  }

  export type RefreshTokenGroupByOutputType = {
    id: number
    userId: string
    token: string
    expiresAt: Date
    createdAt: Date
    _count: RefreshTokenCountAggregateOutputType | null
    _avg: RefreshTokenAvgAggregateOutputType | null
    _sum: RefreshTokenSumAggregateOutputType | null
    _min: RefreshTokenMinAggregateOutputType | null
    _max: RefreshTokenMaxAggregateOutputType | null
  }

  type GetRefreshTokenGroupByPayload<T extends RefreshTokenGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RefreshTokenGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RefreshTokenGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RefreshTokenGroupByOutputType[P]>
            : GetScalarType<T[P], RefreshTokenGroupByOutputType[P]>
        }
      >
    >


  export type RefreshTokenSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    expiresAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["refreshToken"]>

  export type RefreshTokenSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    expiresAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["refreshToken"]>

  export type RefreshTokenSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    expiresAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["refreshToken"]>

  export type RefreshTokenSelectScalar = {
    id?: boolean
    userId?: boolean
    token?: boolean
    expiresAt?: boolean
    createdAt?: boolean
  }

  export type RefreshTokenOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "token" | "expiresAt" | "createdAt", ExtArgs["result"]["refreshToken"]>
  export type RefreshTokenInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type RefreshTokenIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type RefreshTokenIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $RefreshTokenPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "RefreshToken"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: string
      token: string
      expiresAt: Date
      createdAt: Date
    }, ExtArgs["result"]["refreshToken"]>
    composites: {}
  }

  type RefreshTokenGetPayload<S extends boolean | null | undefined | RefreshTokenDefaultArgs> = $Result.GetResult<Prisma.$RefreshTokenPayload, S>

  type RefreshTokenCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<RefreshTokenFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RefreshTokenCountAggregateInputType | true
    }

  export interface RefreshTokenDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['RefreshToken'], meta: { name: 'RefreshToken' } }
    /**
     * Find zero or one RefreshToken that matches the filter.
     * @param {RefreshTokenFindUniqueArgs} args - Arguments to find a RefreshToken
     * @example
     * // Get one RefreshToken
     * const refreshToken = await prisma.refreshToken.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends RefreshTokenFindUniqueArgs>(args: SelectSubset<T, RefreshTokenFindUniqueArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one RefreshToken that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {RefreshTokenFindUniqueOrThrowArgs} args - Arguments to find a RefreshToken
     * @example
     * // Get one RefreshToken
     * const refreshToken = await prisma.refreshToken.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends RefreshTokenFindUniqueOrThrowArgs>(args: SelectSubset<T, RefreshTokenFindUniqueOrThrowArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RefreshToken that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenFindFirstArgs} args - Arguments to find a RefreshToken
     * @example
     * // Get one RefreshToken
     * const refreshToken = await prisma.refreshToken.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends RefreshTokenFindFirstArgs>(args?: SelectSubset<T, RefreshTokenFindFirstArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RefreshToken that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenFindFirstOrThrowArgs} args - Arguments to find a RefreshToken
     * @example
     * // Get one RefreshToken
     * const refreshToken = await prisma.refreshToken.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends RefreshTokenFindFirstOrThrowArgs>(args?: SelectSubset<T, RefreshTokenFindFirstOrThrowArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more RefreshTokens that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all RefreshTokens
     * const refreshTokens = await prisma.refreshToken.findMany()
     * 
     * // Get first 10 RefreshTokens
     * const refreshTokens = await prisma.refreshToken.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const refreshTokenWithIdOnly = await prisma.refreshToken.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends RefreshTokenFindManyArgs>(args?: SelectSubset<T, RefreshTokenFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a RefreshToken.
     * @param {RefreshTokenCreateArgs} args - Arguments to create a RefreshToken.
     * @example
     * // Create one RefreshToken
     * const RefreshToken = await prisma.refreshToken.create({
     *   data: {
     *     // ... data to create a RefreshToken
     *   }
     * })
     * 
     */
    create<T extends RefreshTokenCreateArgs>(args: SelectSubset<T, RefreshTokenCreateArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many RefreshTokens.
     * @param {RefreshTokenCreateManyArgs} args - Arguments to create many RefreshTokens.
     * @example
     * // Create many RefreshTokens
     * const refreshToken = await prisma.refreshToken.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends RefreshTokenCreateManyArgs>(args?: SelectSubset<T, RefreshTokenCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many RefreshTokens and returns the data saved in the database.
     * @param {RefreshTokenCreateManyAndReturnArgs} args - Arguments to create many RefreshTokens.
     * @example
     * // Create many RefreshTokens
     * const refreshToken = await prisma.refreshToken.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many RefreshTokens and only return the `id`
     * const refreshTokenWithIdOnly = await prisma.refreshToken.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends RefreshTokenCreateManyAndReturnArgs>(args?: SelectSubset<T, RefreshTokenCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a RefreshToken.
     * @param {RefreshTokenDeleteArgs} args - Arguments to delete one RefreshToken.
     * @example
     * // Delete one RefreshToken
     * const RefreshToken = await prisma.refreshToken.delete({
     *   where: {
     *     // ... filter to delete one RefreshToken
     *   }
     * })
     * 
     */
    delete<T extends RefreshTokenDeleteArgs>(args: SelectSubset<T, RefreshTokenDeleteArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one RefreshToken.
     * @param {RefreshTokenUpdateArgs} args - Arguments to update one RefreshToken.
     * @example
     * // Update one RefreshToken
     * const refreshToken = await prisma.refreshToken.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends RefreshTokenUpdateArgs>(args: SelectSubset<T, RefreshTokenUpdateArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more RefreshTokens.
     * @param {RefreshTokenDeleteManyArgs} args - Arguments to filter RefreshTokens to delete.
     * @example
     * // Delete a few RefreshTokens
     * const { count } = await prisma.refreshToken.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends RefreshTokenDeleteManyArgs>(args?: SelectSubset<T, RefreshTokenDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RefreshTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many RefreshTokens
     * const refreshToken = await prisma.refreshToken.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends RefreshTokenUpdateManyArgs>(args: SelectSubset<T, RefreshTokenUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RefreshTokens and returns the data updated in the database.
     * @param {RefreshTokenUpdateManyAndReturnArgs} args - Arguments to update many RefreshTokens.
     * @example
     * // Update many RefreshTokens
     * const refreshToken = await prisma.refreshToken.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more RefreshTokens and only return the `id`
     * const refreshTokenWithIdOnly = await prisma.refreshToken.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends RefreshTokenUpdateManyAndReturnArgs>(args: SelectSubset<T, RefreshTokenUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one RefreshToken.
     * @param {RefreshTokenUpsertArgs} args - Arguments to update or create a RefreshToken.
     * @example
     * // Update or create a RefreshToken
     * const refreshToken = await prisma.refreshToken.upsert({
     *   create: {
     *     // ... data to create a RefreshToken
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the RefreshToken we want to update
     *   }
     * })
     */
    upsert<T extends RefreshTokenUpsertArgs>(args: SelectSubset<T, RefreshTokenUpsertArgs<ExtArgs>>): Prisma__RefreshTokenClient<$Result.GetResult<Prisma.$RefreshTokenPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of RefreshTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenCountArgs} args - Arguments to filter RefreshTokens to count.
     * @example
     * // Count the number of RefreshTokens
     * const count = await prisma.refreshToken.count({
     *   where: {
     *     // ... the filter for the RefreshTokens we want to count
     *   }
     * })
    **/
    count<T extends RefreshTokenCountArgs>(
      args?: Subset<T, RefreshTokenCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RefreshTokenCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a RefreshToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RefreshTokenAggregateArgs>(args: Subset<T, RefreshTokenAggregateArgs>): Prisma.PrismaPromise<GetRefreshTokenAggregateType<T>>

    /**
     * Group by RefreshToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefreshTokenGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends RefreshTokenGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: RefreshTokenGroupByArgs['orderBy'] }
        : { orderBy?: RefreshTokenGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, RefreshTokenGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRefreshTokenGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the RefreshToken model
   */
  readonly fields: RefreshTokenFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for RefreshToken.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__RefreshTokenClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the RefreshToken model
   */
  interface RefreshTokenFieldRefs {
    readonly id: FieldRef<"RefreshToken", 'Int'>
    readonly userId: FieldRef<"RefreshToken", 'String'>
    readonly token: FieldRef<"RefreshToken", 'String'>
    readonly expiresAt: FieldRef<"RefreshToken", 'DateTime'>
    readonly createdAt: FieldRef<"RefreshToken", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * RefreshToken findUnique
   */
  export type RefreshTokenFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter, which RefreshToken to fetch.
     */
    where: RefreshTokenWhereUniqueInput
  }

  /**
   * RefreshToken findUniqueOrThrow
   */
  export type RefreshTokenFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter, which RefreshToken to fetch.
     */
    where: RefreshTokenWhereUniqueInput
  }

  /**
   * RefreshToken findFirst
   */
  export type RefreshTokenFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter, which RefreshToken to fetch.
     */
    where?: RefreshTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RefreshTokens to fetch.
     */
    orderBy?: RefreshTokenOrderByWithRelationInput | RefreshTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RefreshTokens.
     */
    cursor?: RefreshTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RefreshTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RefreshTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RefreshTokens.
     */
    distinct?: RefreshTokenScalarFieldEnum | RefreshTokenScalarFieldEnum[]
  }

  /**
   * RefreshToken findFirstOrThrow
   */
  export type RefreshTokenFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter, which RefreshToken to fetch.
     */
    where?: RefreshTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RefreshTokens to fetch.
     */
    orderBy?: RefreshTokenOrderByWithRelationInput | RefreshTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RefreshTokens.
     */
    cursor?: RefreshTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RefreshTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RefreshTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RefreshTokens.
     */
    distinct?: RefreshTokenScalarFieldEnum | RefreshTokenScalarFieldEnum[]
  }

  /**
   * RefreshToken findMany
   */
  export type RefreshTokenFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter, which RefreshTokens to fetch.
     */
    where?: RefreshTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RefreshTokens to fetch.
     */
    orderBy?: RefreshTokenOrderByWithRelationInput | RefreshTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing RefreshTokens.
     */
    cursor?: RefreshTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RefreshTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RefreshTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RefreshTokens.
     */
    distinct?: RefreshTokenScalarFieldEnum | RefreshTokenScalarFieldEnum[]
  }

  /**
   * RefreshToken create
   */
  export type RefreshTokenCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * The data needed to create a RefreshToken.
     */
    data: XOR<RefreshTokenCreateInput, RefreshTokenUncheckedCreateInput>
  }

  /**
   * RefreshToken createMany
   */
  export type RefreshTokenCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many RefreshTokens.
     */
    data: RefreshTokenCreateManyInput | RefreshTokenCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * RefreshToken createManyAndReturn
   */
  export type RefreshTokenCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * The data used to create many RefreshTokens.
     */
    data: RefreshTokenCreateManyInput | RefreshTokenCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * RefreshToken update
   */
  export type RefreshTokenUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * The data needed to update a RefreshToken.
     */
    data: XOR<RefreshTokenUpdateInput, RefreshTokenUncheckedUpdateInput>
    /**
     * Choose, which RefreshToken to update.
     */
    where: RefreshTokenWhereUniqueInput
  }

  /**
   * RefreshToken updateMany
   */
  export type RefreshTokenUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update RefreshTokens.
     */
    data: XOR<RefreshTokenUpdateManyMutationInput, RefreshTokenUncheckedUpdateManyInput>
    /**
     * Filter which RefreshTokens to update
     */
    where?: RefreshTokenWhereInput
    /**
     * Limit how many RefreshTokens to update.
     */
    limit?: number
  }

  /**
   * RefreshToken updateManyAndReturn
   */
  export type RefreshTokenUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * The data used to update RefreshTokens.
     */
    data: XOR<RefreshTokenUpdateManyMutationInput, RefreshTokenUncheckedUpdateManyInput>
    /**
     * Filter which RefreshTokens to update
     */
    where?: RefreshTokenWhereInput
    /**
     * Limit how many RefreshTokens to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * RefreshToken upsert
   */
  export type RefreshTokenUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * The filter to search for the RefreshToken to update in case it exists.
     */
    where: RefreshTokenWhereUniqueInput
    /**
     * In case the RefreshToken found by the `where` argument doesn't exist, create a new RefreshToken with this data.
     */
    create: XOR<RefreshTokenCreateInput, RefreshTokenUncheckedCreateInput>
    /**
     * In case the RefreshToken was found with the provided `where` argument, update it with this data.
     */
    update: XOR<RefreshTokenUpdateInput, RefreshTokenUncheckedUpdateInput>
  }

  /**
   * RefreshToken delete
   */
  export type RefreshTokenDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
    /**
     * Filter which RefreshToken to delete.
     */
    where: RefreshTokenWhereUniqueInput
  }

  /**
   * RefreshToken deleteMany
   */
  export type RefreshTokenDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RefreshTokens to delete
     */
    where?: RefreshTokenWhereInput
    /**
     * Limit how many RefreshTokens to delete.
     */
    limit?: number
  }

  /**
   * RefreshToken without action
   */
  export type RefreshTokenDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RefreshToken
     */
    select?: RefreshTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RefreshToken
     */
    omit?: RefreshTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RefreshTokenInclude<ExtArgs> | null
  }


  /**
   * Model History
   */

  export type AggregateHistory = {
    _count: HistoryCountAggregateOutputType | null
    _avg: HistoryAvgAggregateOutputType | null
    _sum: HistorySumAggregateOutputType | null
    _min: HistoryMinAggregateOutputType | null
    _max: HistoryMaxAggregateOutputType | null
  }

  export type HistoryAvgAggregateOutputType = {
    id: number | null
    recordId: number | null
  }

  export type HistorySumAggregateOutputType = {
    id: bigint | null
    recordId: bigint | null
  }

  export type HistoryMinAggregateOutputType = {
    id: bigint | null
    recordId: bigint | null
    tableName: string | null
    operationType: $Enums.OperationType | null
    changedBy: string | null
    createdAt: Date | null
  }

  export type HistoryMaxAggregateOutputType = {
    id: bigint | null
    recordId: bigint | null
    tableName: string | null
    operationType: $Enums.OperationType | null
    changedBy: string | null
    createdAt: Date | null
  }

  export type HistoryCountAggregateOutputType = {
    id: number
    recordId: number
    tableName: number
    operationType: number
    oldData: number
    newData: number
    changedBy: number
    createdAt: number
    _all: number
  }


  export type HistoryAvgAggregateInputType = {
    id?: true
    recordId?: true
  }

  export type HistorySumAggregateInputType = {
    id?: true
    recordId?: true
  }

  export type HistoryMinAggregateInputType = {
    id?: true
    recordId?: true
    tableName?: true
    operationType?: true
    changedBy?: true
    createdAt?: true
  }

  export type HistoryMaxAggregateInputType = {
    id?: true
    recordId?: true
    tableName?: true
    operationType?: true
    changedBy?: true
    createdAt?: true
  }

  export type HistoryCountAggregateInputType = {
    id?: true
    recordId?: true
    tableName?: true
    operationType?: true
    oldData?: true
    newData?: true
    changedBy?: true
    createdAt?: true
    _all?: true
  }

  export type HistoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which History to aggregate.
     */
    where?: HistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Histories to fetch.
     */
    orderBy?: HistoryOrderByWithRelationInput | HistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: HistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Histories
    **/
    _count?: true | HistoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: HistoryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: HistorySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HistoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HistoryMaxAggregateInputType
  }

  export type GetHistoryAggregateType<T extends HistoryAggregateArgs> = {
        [P in keyof T & keyof AggregateHistory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHistory[P]>
      : GetScalarType<T[P], AggregateHistory[P]>
  }




  export type HistoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HistoryWhereInput
    orderBy?: HistoryOrderByWithAggregationInput | HistoryOrderByWithAggregationInput[]
    by: HistoryScalarFieldEnum[] | HistoryScalarFieldEnum
    having?: HistoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HistoryCountAggregateInputType | true
    _avg?: HistoryAvgAggregateInputType
    _sum?: HistorySumAggregateInputType
    _min?: HistoryMinAggregateInputType
    _max?: HistoryMaxAggregateInputType
  }

  export type HistoryGroupByOutputType = {
    id: bigint
    recordId: bigint
    tableName: string
    operationType: $Enums.OperationType
    oldData: JsonValue | null
    newData: JsonValue | null
    changedBy: string | null
    createdAt: Date
    _count: HistoryCountAggregateOutputType | null
    _avg: HistoryAvgAggregateOutputType | null
    _sum: HistorySumAggregateOutputType | null
    _min: HistoryMinAggregateOutputType | null
    _max: HistoryMaxAggregateOutputType | null
  }

  type GetHistoryGroupByPayload<T extends HistoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<HistoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HistoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HistoryGroupByOutputType[P]>
            : GetScalarType<T[P], HistoryGroupByOutputType[P]>
        }
      >
    >


  export type HistorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    recordId?: boolean
    tableName?: boolean
    operationType?: boolean
    oldData?: boolean
    newData?: boolean
    changedBy?: boolean
    createdAt?: boolean
    user?: boolean | History$userArgs<ExtArgs>
  }, ExtArgs["result"]["history"]>

  export type HistorySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    recordId?: boolean
    tableName?: boolean
    operationType?: boolean
    oldData?: boolean
    newData?: boolean
    changedBy?: boolean
    createdAt?: boolean
    user?: boolean | History$userArgs<ExtArgs>
  }, ExtArgs["result"]["history"]>

  export type HistorySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    recordId?: boolean
    tableName?: boolean
    operationType?: boolean
    oldData?: boolean
    newData?: boolean
    changedBy?: boolean
    createdAt?: boolean
    user?: boolean | History$userArgs<ExtArgs>
  }, ExtArgs["result"]["history"]>

  export type HistorySelectScalar = {
    id?: boolean
    recordId?: boolean
    tableName?: boolean
    operationType?: boolean
    oldData?: boolean
    newData?: boolean
    changedBy?: boolean
    createdAt?: boolean
  }

  export type HistoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "recordId" | "tableName" | "operationType" | "oldData" | "newData" | "changedBy" | "createdAt", ExtArgs["result"]["history"]>
  export type HistoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | History$userArgs<ExtArgs>
  }
  export type HistoryIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | History$userArgs<ExtArgs>
  }
  export type HistoryIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | History$userArgs<ExtArgs>
  }

  export type $HistoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "History"
    objects: {
      user: Prisma.$UserPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      recordId: bigint
      tableName: string
      operationType: $Enums.OperationType
      oldData: Prisma.JsonValue | null
      newData: Prisma.JsonValue | null
      changedBy: string | null
      createdAt: Date
    }, ExtArgs["result"]["history"]>
    composites: {}
  }

  type HistoryGetPayload<S extends boolean | null | undefined | HistoryDefaultArgs> = $Result.GetResult<Prisma.$HistoryPayload, S>

  type HistoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<HistoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: HistoryCountAggregateInputType | true
    }

  export interface HistoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['History'], meta: { name: 'History' } }
    /**
     * Find zero or one History that matches the filter.
     * @param {HistoryFindUniqueArgs} args - Arguments to find a History
     * @example
     * // Get one History
     * const history = await prisma.history.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends HistoryFindUniqueArgs>(args: SelectSubset<T, HistoryFindUniqueArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one History that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {HistoryFindUniqueOrThrowArgs} args - Arguments to find a History
     * @example
     * // Get one History
     * const history = await prisma.history.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends HistoryFindUniqueOrThrowArgs>(args: SelectSubset<T, HistoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first History that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryFindFirstArgs} args - Arguments to find a History
     * @example
     * // Get one History
     * const history = await prisma.history.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends HistoryFindFirstArgs>(args?: SelectSubset<T, HistoryFindFirstArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first History that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryFindFirstOrThrowArgs} args - Arguments to find a History
     * @example
     * // Get one History
     * const history = await prisma.history.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends HistoryFindFirstOrThrowArgs>(args?: SelectSubset<T, HistoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Histories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Histories
     * const histories = await prisma.history.findMany()
     * 
     * // Get first 10 Histories
     * const histories = await prisma.history.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const historyWithIdOnly = await prisma.history.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends HistoryFindManyArgs>(args?: SelectSubset<T, HistoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a History.
     * @param {HistoryCreateArgs} args - Arguments to create a History.
     * @example
     * // Create one History
     * const History = await prisma.history.create({
     *   data: {
     *     // ... data to create a History
     *   }
     * })
     * 
     */
    create<T extends HistoryCreateArgs>(args: SelectSubset<T, HistoryCreateArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Histories.
     * @param {HistoryCreateManyArgs} args - Arguments to create many Histories.
     * @example
     * // Create many Histories
     * const history = await prisma.history.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends HistoryCreateManyArgs>(args?: SelectSubset<T, HistoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Histories and returns the data saved in the database.
     * @param {HistoryCreateManyAndReturnArgs} args - Arguments to create many Histories.
     * @example
     * // Create many Histories
     * const history = await prisma.history.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Histories and only return the `id`
     * const historyWithIdOnly = await prisma.history.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends HistoryCreateManyAndReturnArgs>(args?: SelectSubset<T, HistoryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a History.
     * @param {HistoryDeleteArgs} args - Arguments to delete one History.
     * @example
     * // Delete one History
     * const History = await prisma.history.delete({
     *   where: {
     *     // ... filter to delete one History
     *   }
     * })
     * 
     */
    delete<T extends HistoryDeleteArgs>(args: SelectSubset<T, HistoryDeleteArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one History.
     * @param {HistoryUpdateArgs} args - Arguments to update one History.
     * @example
     * // Update one History
     * const history = await prisma.history.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends HistoryUpdateArgs>(args: SelectSubset<T, HistoryUpdateArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Histories.
     * @param {HistoryDeleteManyArgs} args - Arguments to filter Histories to delete.
     * @example
     * // Delete a few Histories
     * const { count } = await prisma.history.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends HistoryDeleteManyArgs>(args?: SelectSubset<T, HistoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Histories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Histories
     * const history = await prisma.history.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends HistoryUpdateManyArgs>(args: SelectSubset<T, HistoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Histories and returns the data updated in the database.
     * @param {HistoryUpdateManyAndReturnArgs} args - Arguments to update many Histories.
     * @example
     * // Update many Histories
     * const history = await prisma.history.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Histories and only return the `id`
     * const historyWithIdOnly = await prisma.history.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends HistoryUpdateManyAndReturnArgs>(args: SelectSubset<T, HistoryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one History.
     * @param {HistoryUpsertArgs} args - Arguments to update or create a History.
     * @example
     * // Update or create a History
     * const history = await prisma.history.upsert({
     *   create: {
     *     // ... data to create a History
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the History we want to update
     *   }
     * })
     */
    upsert<T extends HistoryUpsertArgs>(args: SelectSubset<T, HistoryUpsertArgs<ExtArgs>>): Prisma__HistoryClient<$Result.GetResult<Prisma.$HistoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Histories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCountArgs} args - Arguments to filter Histories to count.
     * @example
     * // Count the number of Histories
     * const count = await prisma.history.count({
     *   where: {
     *     // ... the filter for the Histories we want to count
     *   }
     * })
    **/
    count<T extends HistoryCountArgs>(
      args?: Subset<T, HistoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HistoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a History.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HistoryAggregateArgs>(args: Subset<T, HistoryAggregateArgs>): Prisma.PrismaPromise<GetHistoryAggregateType<T>>

    /**
     * Group by History.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HistoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HistoryGroupByArgs['orderBy'] }
        : { orderBy?: HistoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HistoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHistoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the History model
   */
  readonly fields: HistoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for History.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__HistoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends History$userArgs<ExtArgs> = {}>(args?: Subset<T, History$userArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the History model
   */
  interface HistoryFieldRefs {
    readonly id: FieldRef<"History", 'BigInt'>
    readonly recordId: FieldRef<"History", 'BigInt'>
    readonly tableName: FieldRef<"History", 'String'>
    readonly operationType: FieldRef<"History", 'OperationType'>
    readonly oldData: FieldRef<"History", 'Json'>
    readonly newData: FieldRef<"History", 'Json'>
    readonly changedBy: FieldRef<"History", 'String'>
    readonly createdAt: FieldRef<"History", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * History findUnique
   */
  export type HistoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter, which History to fetch.
     */
    where: HistoryWhereUniqueInput
  }

  /**
   * History findUniqueOrThrow
   */
  export type HistoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter, which History to fetch.
     */
    where: HistoryWhereUniqueInput
  }

  /**
   * History findFirst
   */
  export type HistoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter, which History to fetch.
     */
    where?: HistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Histories to fetch.
     */
    orderBy?: HistoryOrderByWithRelationInput | HistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Histories.
     */
    cursor?: HistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Histories.
     */
    distinct?: HistoryScalarFieldEnum | HistoryScalarFieldEnum[]
  }

  /**
   * History findFirstOrThrow
   */
  export type HistoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter, which History to fetch.
     */
    where?: HistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Histories to fetch.
     */
    orderBy?: HistoryOrderByWithRelationInput | HistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Histories.
     */
    cursor?: HistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Histories.
     */
    distinct?: HistoryScalarFieldEnum | HistoryScalarFieldEnum[]
  }

  /**
   * History findMany
   */
  export type HistoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter, which Histories to fetch.
     */
    where?: HistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Histories to fetch.
     */
    orderBy?: HistoryOrderByWithRelationInput | HistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Histories.
     */
    cursor?: HistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Histories.
     */
    distinct?: HistoryScalarFieldEnum | HistoryScalarFieldEnum[]
  }

  /**
   * History create
   */
  export type HistoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * The data needed to create a History.
     */
    data: XOR<HistoryCreateInput, HistoryUncheckedCreateInput>
  }

  /**
   * History createMany
   */
  export type HistoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Histories.
     */
    data: HistoryCreateManyInput | HistoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * History createManyAndReturn
   */
  export type HistoryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * The data used to create many Histories.
     */
    data: HistoryCreateManyInput | HistoryCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * History update
   */
  export type HistoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * The data needed to update a History.
     */
    data: XOR<HistoryUpdateInput, HistoryUncheckedUpdateInput>
    /**
     * Choose, which History to update.
     */
    where: HistoryWhereUniqueInput
  }

  /**
   * History updateMany
   */
  export type HistoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Histories.
     */
    data: XOR<HistoryUpdateManyMutationInput, HistoryUncheckedUpdateManyInput>
    /**
     * Filter which Histories to update
     */
    where?: HistoryWhereInput
    /**
     * Limit how many Histories to update.
     */
    limit?: number
  }

  /**
   * History updateManyAndReturn
   */
  export type HistoryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * The data used to update Histories.
     */
    data: XOR<HistoryUpdateManyMutationInput, HistoryUncheckedUpdateManyInput>
    /**
     * Filter which Histories to update
     */
    where?: HistoryWhereInput
    /**
     * Limit how many Histories to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * History upsert
   */
  export type HistoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * The filter to search for the History to update in case it exists.
     */
    where: HistoryWhereUniqueInput
    /**
     * In case the History found by the `where` argument doesn't exist, create a new History with this data.
     */
    create: XOR<HistoryCreateInput, HistoryUncheckedCreateInput>
    /**
     * In case the History was found with the provided `where` argument, update it with this data.
     */
    update: XOR<HistoryUpdateInput, HistoryUncheckedUpdateInput>
  }

  /**
   * History delete
   */
  export type HistoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
    /**
     * Filter which History to delete.
     */
    where: HistoryWhereUniqueInput
  }

  /**
   * History deleteMany
   */
  export type HistoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Histories to delete
     */
    where?: HistoryWhereInput
    /**
     * Limit how many Histories to delete.
     */
    limit?: number
  }

  /**
   * History.user
   */
  export type History$userArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * History without action
   */
  export type HistoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the History
     */
    select?: HistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the History
     */
    omit?: HistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    password: 'password',
    nickname: 'nickname',
    provider: 'provider',
    providerId: 'providerId',
    createdAt: 'createdAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const UserPointScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    point: 'point',
    lastSpinAt: 'lastSpinAt',
    updatedAt: 'updatedAt'
  };

  export type UserPointScalarFieldEnum = (typeof UserPointScalarFieldEnum)[keyof typeof UserPointScalarFieldEnum]


  export const PhotoCardScalarFieldEnum: {
    id: 'id',
    creatorId: 'creatorId',
    name: 'name',
    description: 'description',
    genre: 'genre',
    grade: 'grade',
    price: 'price',
    totalQuantity: 'totalQuantity',
    imageUrl: 'imageUrl',
    createdAt: 'createdAt'
  };

  export type PhotoCardScalarFieldEnum = (typeof PhotoCardScalarFieldEnum)[keyof typeof PhotoCardScalarFieldEnum]


  export const MyCardScalarFieldEnum: {
    id: 'id',
    ownerId: 'ownerId',
    photoCardId: 'photoCardId',
    quantity: 'quantity',
    acquiredAt: 'acquiredAt'
  };

  export type MyCardScalarFieldEnum = (typeof MyCardScalarFieldEnum)[keyof typeof MyCardScalarFieldEnum]


  export const MarketItemScalarFieldEnum: {
    id: 'id',
    sellerId: 'sellerId',
    myCardId: 'myCardId',
    grade: 'grade',
    genre: 'genre',
    quantity: 'quantity',
    soldQuantity: 'soldQuantity',
    pricePerCard: 'pricePerCard',
    wantedGrade: 'wantedGrade',
    wantedGenre: 'wantedGenre',
    wantedDescription: 'wantedDescription',
    status: 'status',
    createdAt: 'createdAt'
  };

  export type MarketItemScalarFieldEnum = (typeof MarketItemScalarFieldEnum)[keyof typeof MarketItemScalarFieldEnum]


  export const ExchangeProposalScalarFieldEnum: {
    id: 'id',
    marketItemId: 'marketItemId',
    proposerId: 'proposerId',
    offeredCardId: 'offeredCardId',
    status: 'status',
    createdAt: 'createdAt'
  };

  export type ExchangeProposalScalarFieldEnum = (typeof ExchangeProposalScalarFieldEnum)[keyof typeof ExchangeProposalScalarFieldEnum]


  export const OrderScalarFieldEnum: {
    id: 'id',
    buyerId: 'buyerId',
    marketItemId: 'marketItemId',
    quantity: 'quantity',
    totalPrice: 'totalPrice',
    createdAt: 'createdAt'
  };

  export type OrderScalarFieldEnum = (typeof OrderScalarFieldEnum)[keyof typeof OrderScalarFieldEnum]


  export const PointLogScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    type: 'type',
    amount: 'amount',
    createdAt: 'createdAt'
  };

  export type PointLogScalarFieldEnum = (typeof PointLogScalarFieldEnum)[keyof typeof PointLogScalarFieldEnum]


  export const NotificationScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    type: 'type',
    routeType: 'routeType',
    targetId: 'targetId',
    message: 'message',
    isRead: 'isRead',
    createdAt: 'createdAt'
  };

  export type NotificationScalarFieldEnum = (typeof NotificationScalarFieldEnum)[keyof typeof NotificationScalarFieldEnum]


  export const CardCreationLogScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    year: 'year',
    month: 'month',
    count: 'count'
  };

  export type CardCreationLogScalarFieldEnum = (typeof CardCreationLogScalarFieldEnum)[keyof typeof CardCreationLogScalarFieldEnum]


  export const RefreshTokenScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    token: 'token',
    expiresAt: 'expiresAt',
    createdAt: 'createdAt'
  };

  export type RefreshTokenScalarFieldEnum = (typeof RefreshTokenScalarFieldEnum)[keyof typeof RefreshTokenScalarFieldEnum]


  export const HistoryScalarFieldEnum: {
    id: 'id',
    recordId: 'recordId',
    tableName: 'tableName',
    operationType: 'operationType',
    oldData: 'oldData',
    newData: 'newData',
    changedBy: 'changedBy',
    createdAt: 'createdAt'
  };

  export type HistoryScalarFieldEnum = (typeof HistoryScalarFieldEnum)[keyof typeof HistoryScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Provider'
   */
  export type EnumProviderFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Provider'>
    


  /**
   * Reference to a field of type 'Provider[]'
   */
  export type ListEnumProviderFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Provider[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Genre'
   */
  export type EnumGenreFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Genre'>
    


  /**
   * Reference to a field of type 'Genre[]'
   */
  export type ListEnumGenreFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Genre[]'>
    


  /**
   * Reference to a field of type 'CardGrade'
   */
  export type EnumCardGradeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'CardGrade'>
    


  /**
   * Reference to a field of type 'CardGrade[]'
   */
  export type ListEnumCardGradeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'CardGrade[]'>
    


  /**
   * Reference to a field of type 'MarketStatus'
   */
  export type EnumMarketStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MarketStatus'>
    


  /**
   * Reference to a field of type 'MarketStatus[]'
   */
  export type ListEnumMarketStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MarketStatus[]'>
    


  /**
   * Reference to a field of type 'ExchangeStatus'
   */
  export type EnumExchangeStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ExchangeStatus'>
    


  /**
   * Reference to a field of type 'ExchangeStatus[]'
   */
  export type ListEnumExchangeStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ExchangeStatus[]'>
    


  /**
   * Reference to a field of type 'PointLogType'
   */
  export type EnumPointLogTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PointLogType'>
    


  /**
   * Reference to a field of type 'PointLogType[]'
   */
  export type ListEnumPointLogTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PointLogType[]'>
    


  /**
   * Reference to a field of type 'NotificationType'
   */
  export type EnumNotificationTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'NotificationType'>
    


  /**
   * Reference to a field of type 'NotificationType[]'
   */
  export type ListEnumNotificationTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'NotificationType[]'>
    


  /**
   * Reference to a field of type 'RouteType'
   */
  export type EnumRouteTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'RouteType'>
    


  /**
   * Reference to a field of type 'RouteType[]'
   */
  export type ListEnumRouteTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'RouteType[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'BigInt'
   */
  export type BigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt'>
    


  /**
   * Reference to a field of type 'BigInt[]'
   */
  export type ListBigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt[]'>
    


  /**
   * Reference to a field of type 'OperationType'
   */
  export type EnumOperationTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'OperationType'>
    


  /**
   * Reference to a field of type 'OperationType[]'
   */
  export type ListEnumOperationTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'OperationType[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: UuidFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password?: StringNullableFilter<"User"> | string | null
    nickname?: StringFilter<"User"> | string
    provider?: EnumProviderFilter<"User"> | $Enums.Provider
    providerId?: StringNullableFilter<"User"> | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    userPoint?: XOR<UserPointNullableScalarRelationFilter, UserPointWhereInput> | null
    photoCards?: PhotoCardListRelationFilter
    myCards?: MyCardListRelationFilter
    marketItems?: MarketItemListRelationFilter
    exchangeProposals?: ExchangeProposalListRelationFilter
    orders?: OrderListRelationFilter
    pointLogs?: PointLogListRelationFilter
    notifications?: NotificationListRelationFilter
    creationLogs?: CardCreationLogListRelationFilter
    refreshTokens?: RefreshTokenListRelationFilter
    histories?: HistoryListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrderInput | SortOrder
    nickname?: SortOrder
    provider?: SortOrder
    providerId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    userPoint?: UserPointOrderByWithRelationInput
    photoCards?: PhotoCardOrderByRelationAggregateInput
    myCards?: MyCardOrderByRelationAggregateInput
    marketItems?: MarketItemOrderByRelationAggregateInput
    exchangeProposals?: ExchangeProposalOrderByRelationAggregateInput
    orders?: OrderOrderByRelationAggregateInput
    pointLogs?: PointLogOrderByRelationAggregateInput
    notifications?: NotificationOrderByRelationAggregateInput
    creationLogs?: CardCreationLogOrderByRelationAggregateInput
    refreshTokens?: RefreshTokenOrderByRelationAggregateInput
    histories?: HistoryOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    nickname?: string
    provider_providerId?: UserProviderProviderIdCompoundUniqueInput
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    password?: StringNullableFilter<"User"> | string | null
    provider?: EnumProviderFilter<"User"> | $Enums.Provider
    providerId?: StringNullableFilter<"User"> | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    userPoint?: XOR<UserPointNullableScalarRelationFilter, UserPointWhereInput> | null
    photoCards?: PhotoCardListRelationFilter
    myCards?: MyCardListRelationFilter
    marketItems?: MarketItemListRelationFilter
    exchangeProposals?: ExchangeProposalListRelationFilter
    orders?: OrderListRelationFilter
    pointLogs?: PointLogListRelationFilter
    notifications?: NotificationListRelationFilter
    creationLogs?: CardCreationLogListRelationFilter
    refreshTokens?: RefreshTokenListRelationFilter
    histories?: HistoryListRelationFilter
  }, "id" | "email" | "nickname" | "provider_providerId">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrderInput | SortOrder
    nickname?: SortOrder
    provider?: SortOrder
    providerId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: UuidWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    password?: StringNullableWithAggregatesFilter<"User"> | string | null
    nickname?: StringWithAggregatesFilter<"User"> | string
    provider?: EnumProviderWithAggregatesFilter<"User"> | $Enums.Provider
    providerId?: StringNullableWithAggregatesFilter<"User"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type UserPointWhereInput = {
    AND?: UserPointWhereInput | UserPointWhereInput[]
    OR?: UserPointWhereInput[]
    NOT?: UserPointWhereInput | UserPointWhereInput[]
    id?: IntFilter<"UserPoint"> | number
    userId?: UuidFilter<"UserPoint"> | string
    point?: IntFilter<"UserPoint"> | number
    lastSpinAt?: DateTimeNullableFilter<"UserPoint"> | Date | string | null
    updatedAt?: DateTimeFilter<"UserPoint"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type UserPointOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    point?: SortOrder
    lastSpinAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type UserPointWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    userId?: string
    AND?: UserPointWhereInput | UserPointWhereInput[]
    OR?: UserPointWhereInput[]
    NOT?: UserPointWhereInput | UserPointWhereInput[]
    point?: IntFilter<"UserPoint"> | number
    lastSpinAt?: DateTimeNullableFilter<"UserPoint"> | Date | string | null
    updatedAt?: DateTimeFilter<"UserPoint"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "userId">

  export type UserPointOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    point?: SortOrder
    lastSpinAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrder
    _count?: UserPointCountOrderByAggregateInput
    _avg?: UserPointAvgOrderByAggregateInput
    _max?: UserPointMaxOrderByAggregateInput
    _min?: UserPointMinOrderByAggregateInput
    _sum?: UserPointSumOrderByAggregateInput
  }

  export type UserPointScalarWhereWithAggregatesInput = {
    AND?: UserPointScalarWhereWithAggregatesInput | UserPointScalarWhereWithAggregatesInput[]
    OR?: UserPointScalarWhereWithAggregatesInput[]
    NOT?: UserPointScalarWhereWithAggregatesInput | UserPointScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"UserPoint"> | number
    userId?: UuidWithAggregatesFilter<"UserPoint"> | string
    point?: IntWithAggregatesFilter<"UserPoint"> | number
    lastSpinAt?: DateTimeNullableWithAggregatesFilter<"UserPoint"> | Date | string | null
    updatedAt?: DateTimeWithAggregatesFilter<"UserPoint"> | Date | string
  }

  export type PhotoCardWhereInput = {
    AND?: PhotoCardWhereInput | PhotoCardWhereInput[]
    OR?: PhotoCardWhereInput[]
    NOT?: PhotoCardWhereInput | PhotoCardWhereInput[]
    id?: IntFilter<"PhotoCard"> | number
    creatorId?: UuidFilter<"PhotoCard"> | string
    name?: StringFilter<"PhotoCard"> | string
    description?: StringNullableFilter<"PhotoCard"> | string | null
    genre?: EnumGenreFilter<"PhotoCard"> | $Enums.Genre
    grade?: EnumCardGradeFilter<"PhotoCard"> | $Enums.CardGrade
    price?: IntFilter<"PhotoCard"> | number
    totalQuantity?: IntFilter<"PhotoCard"> | number
    imageUrl?: StringFilter<"PhotoCard"> | string
    createdAt?: DateTimeFilter<"PhotoCard"> | Date | string
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    myCards?: MyCardListRelationFilter
  }

  export type PhotoCardOrderByWithRelationInput = {
    id?: SortOrder
    creatorId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    genre?: SortOrder
    grade?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
    creator?: UserOrderByWithRelationInput
    myCards?: MyCardOrderByRelationAggregateInput
  }

  export type PhotoCardWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: PhotoCardWhereInput | PhotoCardWhereInput[]
    OR?: PhotoCardWhereInput[]
    NOT?: PhotoCardWhereInput | PhotoCardWhereInput[]
    creatorId?: UuidFilter<"PhotoCard"> | string
    name?: StringFilter<"PhotoCard"> | string
    description?: StringNullableFilter<"PhotoCard"> | string | null
    genre?: EnumGenreFilter<"PhotoCard"> | $Enums.Genre
    grade?: EnumCardGradeFilter<"PhotoCard"> | $Enums.CardGrade
    price?: IntFilter<"PhotoCard"> | number
    totalQuantity?: IntFilter<"PhotoCard"> | number
    imageUrl?: StringFilter<"PhotoCard"> | string
    createdAt?: DateTimeFilter<"PhotoCard"> | Date | string
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    myCards?: MyCardListRelationFilter
  }, "id">

  export type PhotoCardOrderByWithAggregationInput = {
    id?: SortOrder
    creatorId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    genre?: SortOrder
    grade?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
    _count?: PhotoCardCountOrderByAggregateInput
    _avg?: PhotoCardAvgOrderByAggregateInput
    _max?: PhotoCardMaxOrderByAggregateInput
    _min?: PhotoCardMinOrderByAggregateInput
    _sum?: PhotoCardSumOrderByAggregateInput
  }

  export type PhotoCardScalarWhereWithAggregatesInput = {
    AND?: PhotoCardScalarWhereWithAggregatesInput | PhotoCardScalarWhereWithAggregatesInput[]
    OR?: PhotoCardScalarWhereWithAggregatesInput[]
    NOT?: PhotoCardScalarWhereWithAggregatesInput | PhotoCardScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"PhotoCard"> | number
    creatorId?: UuidWithAggregatesFilter<"PhotoCard"> | string
    name?: StringWithAggregatesFilter<"PhotoCard"> | string
    description?: StringNullableWithAggregatesFilter<"PhotoCard"> | string | null
    genre?: EnumGenreWithAggregatesFilter<"PhotoCard"> | $Enums.Genre
    grade?: EnumCardGradeWithAggregatesFilter<"PhotoCard"> | $Enums.CardGrade
    price?: IntWithAggregatesFilter<"PhotoCard"> | number
    totalQuantity?: IntWithAggregatesFilter<"PhotoCard"> | number
    imageUrl?: StringWithAggregatesFilter<"PhotoCard"> | string
    createdAt?: DateTimeWithAggregatesFilter<"PhotoCard"> | Date | string
  }

  export type MyCardWhereInput = {
    AND?: MyCardWhereInput | MyCardWhereInput[]
    OR?: MyCardWhereInput[]
    NOT?: MyCardWhereInput | MyCardWhereInput[]
    id?: IntFilter<"MyCard"> | number
    ownerId?: UuidFilter<"MyCard"> | string
    photoCardId?: IntFilter<"MyCard"> | number
    quantity?: IntFilter<"MyCard"> | number
    acquiredAt?: DateTimeFilter<"MyCard"> | Date | string
    owner?: XOR<UserScalarRelationFilter, UserWhereInput>
    photoCard?: XOR<PhotoCardScalarRelationFilter, PhotoCardWhereInput>
    marketItems?: MarketItemListRelationFilter
    offeredExchanges?: ExchangeProposalListRelationFilter
  }

  export type MyCardOrderByWithRelationInput = {
    id?: SortOrder
    ownerId?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
    acquiredAt?: SortOrder
    owner?: UserOrderByWithRelationInput
    photoCard?: PhotoCardOrderByWithRelationInput
    marketItems?: MarketItemOrderByRelationAggregateInput
    offeredExchanges?: ExchangeProposalOrderByRelationAggregateInput
  }

  export type MyCardWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MyCardWhereInput | MyCardWhereInput[]
    OR?: MyCardWhereInput[]
    NOT?: MyCardWhereInput | MyCardWhereInput[]
    ownerId?: UuidFilter<"MyCard"> | string
    photoCardId?: IntFilter<"MyCard"> | number
    quantity?: IntFilter<"MyCard"> | number
    acquiredAt?: DateTimeFilter<"MyCard"> | Date | string
    owner?: XOR<UserScalarRelationFilter, UserWhereInput>
    photoCard?: XOR<PhotoCardScalarRelationFilter, PhotoCardWhereInput>
    marketItems?: MarketItemListRelationFilter
    offeredExchanges?: ExchangeProposalListRelationFilter
  }, "id">

  export type MyCardOrderByWithAggregationInput = {
    id?: SortOrder
    ownerId?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
    acquiredAt?: SortOrder
    _count?: MyCardCountOrderByAggregateInput
    _avg?: MyCardAvgOrderByAggregateInput
    _max?: MyCardMaxOrderByAggregateInput
    _min?: MyCardMinOrderByAggregateInput
    _sum?: MyCardSumOrderByAggregateInput
  }

  export type MyCardScalarWhereWithAggregatesInput = {
    AND?: MyCardScalarWhereWithAggregatesInput | MyCardScalarWhereWithAggregatesInput[]
    OR?: MyCardScalarWhereWithAggregatesInput[]
    NOT?: MyCardScalarWhereWithAggregatesInput | MyCardScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MyCard"> | number
    ownerId?: UuidWithAggregatesFilter<"MyCard"> | string
    photoCardId?: IntWithAggregatesFilter<"MyCard"> | number
    quantity?: IntWithAggregatesFilter<"MyCard"> | number
    acquiredAt?: DateTimeWithAggregatesFilter<"MyCard"> | Date | string
  }

  export type MarketItemWhereInput = {
    AND?: MarketItemWhereInput | MarketItemWhereInput[]
    OR?: MarketItemWhereInput[]
    NOT?: MarketItemWhereInput | MarketItemWhereInput[]
    id?: IntFilter<"MarketItem"> | number
    sellerId?: UuidFilter<"MarketItem"> | string
    myCardId?: IntFilter<"MarketItem"> | number
    grade?: EnumCardGradeFilter<"MarketItem"> | $Enums.CardGrade
    genre?: EnumGenreFilter<"MarketItem"> | $Enums.Genre
    quantity?: IntFilter<"MarketItem"> | number
    soldQuantity?: IntFilter<"MarketItem"> | number
    pricePerCard?: IntFilter<"MarketItem"> | number
    wantedGrade?: EnumCardGradeNullableFilter<"MarketItem"> | $Enums.CardGrade | null
    wantedGenre?: EnumGenreNullableFilter<"MarketItem"> | $Enums.Genre | null
    wantedDescription?: StringNullableFilter<"MarketItem"> | string | null
    status?: EnumMarketStatusFilter<"MarketItem"> | $Enums.MarketStatus
    createdAt?: DateTimeFilter<"MarketItem"> | Date | string
    seller?: XOR<UserScalarRelationFilter, UserWhereInput>
    myCard?: XOR<MyCardScalarRelationFilter, MyCardWhereInput>
    exchangeProposals?: ExchangeProposalListRelationFilter
    orders?: OrderListRelationFilter
  }

  export type MarketItemOrderByWithRelationInput = {
    id?: SortOrder
    sellerId?: SortOrder
    myCardId?: SortOrder
    grade?: SortOrder
    genre?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
    wantedGrade?: SortOrderInput | SortOrder
    wantedGenre?: SortOrderInput | SortOrder
    wantedDescription?: SortOrderInput | SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    seller?: UserOrderByWithRelationInput
    myCard?: MyCardOrderByWithRelationInput
    exchangeProposals?: ExchangeProposalOrderByRelationAggregateInput
    orders?: OrderOrderByRelationAggregateInput
  }

  export type MarketItemWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MarketItemWhereInput | MarketItemWhereInput[]
    OR?: MarketItemWhereInput[]
    NOT?: MarketItemWhereInput | MarketItemWhereInput[]
    sellerId?: UuidFilter<"MarketItem"> | string
    myCardId?: IntFilter<"MarketItem"> | number
    grade?: EnumCardGradeFilter<"MarketItem"> | $Enums.CardGrade
    genre?: EnumGenreFilter<"MarketItem"> | $Enums.Genre
    quantity?: IntFilter<"MarketItem"> | number
    soldQuantity?: IntFilter<"MarketItem"> | number
    pricePerCard?: IntFilter<"MarketItem"> | number
    wantedGrade?: EnumCardGradeNullableFilter<"MarketItem"> | $Enums.CardGrade | null
    wantedGenre?: EnumGenreNullableFilter<"MarketItem"> | $Enums.Genre | null
    wantedDescription?: StringNullableFilter<"MarketItem"> | string | null
    status?: EnumMarketStatusFilter<"MarketItem"> | $Enums.MarketStatus
    createdAt?: DateTimeFilter<"MarketItem"> | Date | string
    seller?: XOR<UserScalarRelationFilter, UserWhereInput>
    myCard?: XOR<MyCardScalarRelationFilter, MyCardWhereInput>
    exchangeProposals?: ExchangeProposalListRelationFilter
    orders?: OrderListRelationFilter
  }, "id">

  export type MarketItemOrderByWithAggregationInput = {
    id?: SortOrder
    sellerId?: SortOrder
    myCardId?: SortOrder
    grade?: SortOrder
    genre?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
    wantedGrade?: SortOrderInput | SortOrder
    wantedGenre?: SortOrderInput | SortOrder
    wantedDescription?: SortOrderInput | SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    _count?: MarketItemCountOrderByAggregateInput
    _avg?: MarketItemAvgOrderByAggregateInput
    _max?: MarketItemMaxOrderByAggregateInput
    _min?: MarketItemMinOrderByAggregateInput
    _sum?: MarketItemSumOrderByAggregateInput
  }

  export type MarketItemScalarWhereWithAggregatesInput = {
    AND?: MarketItemScalarWhereWithAggregatesInput | MarketItemScalarWhereWithAggregatesInput[]
    OR?: MarketItemScalarWhereWithAggregatesInput[]
    NOT?: MarketItemScalarWhereWithAggregatesInput | MarketItemScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MarketItem"> | number
    sellerId?: UuidWithAggregatesFilter<"MarketItem"> | string
    myCardId?: IntWithAggregatesFilter<"MarketItem"> | number
    grade?: EnumCardGradeWithAggregatesFilter<"MarketItem"> | $Enums.CardGrade
    genre?: EnumGenreWithAggregatesFilter<"MarketItem"> | $Enums.Genre
    quantity?: IntWithAggregatesFilter<"MarketItem"> | number
    soldQuantity?: IntWithAggregatesFilter<"MarketItem"> | number
    pricePerCard?: IntWithAggregatesFilter<"MarketItem"> | number
    wantedGrade?: EnumCardGradeNullableWithAggregatesFilter<"MarketItem"> | $Enums.CardGrade | null
    wantedGenre?: EnumGenreNullableWithAggregatesFilter<"MarketItem"> | $Enums.Genre | null
    wantedDescription?: StringNullableWithAggregatesFilter<"MarketItem"> | string | null
    status?: EnumMarketStatusWithAggregatesFilter<"MarketItem"> | $Enums.MarketStatus
    createdAt?: DateTimeWithAggregatesFilter<"MarketItem"> | Date | string
  }

  export type ExchangeProposalWhereInput = {
    AND?: ExchangeProposalWhereInput | ExchangeProposalWhereInput[]
    OR?: ExchangeProposalWhereInput[]
    NOT?: ExchangeProposalWhereInput | ExchangeProposalWhereInput[]
    id?: IntFilter<"ExchangeProposal"> | number
    marketItemId?: IntFilter<"ExchangeProposal"> | number
    proposerId?: UuidFilter<"ExchangeProposal"> | string
    offeredCardId?: IntFilter<"ExchangeProposal"> | number
    status?: EnumExchangeStatusFilter<"ExchangeProposal"> | $Enums.ExchangeStatus
    createdAt?: DateTimeFilter<"ExchangeProposal"> | Date | string
    marketItem?: XOR<MarketItemScalarRelationFilter, MarketItemWhereInput>
    proposer?: XOR<UserScalarRelationFilter, UserWhereInput>
    offeredCard?: XOR<MyCardScalarRelationFilter, MyCardWhereInput>
  }

  export type ExchangeProposalOrderByWithRelationInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    proposerId?: SortOrder
    offeredCardId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    marketItem?: MarketItemOrderByWithRelationInput
    proposer?: UserOrderByWithRelationInput
    offeredCard?: MyCardOrderByWithRelationInput
  }

  export type ExchangeProposalWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ExchangeProposalWhereInput | ExchangeProposalWhereInput[]
    OR?: ExchangeProposalWhereInput[]
    NOT?: ExchangeProposalWhereInput | ExchangeProposalWhereInput[]
    marketItemId?: IntFilter<"ExchangeProposal"> | number
    proposerId?: UuidFilter<"ExchangeProposal"> | string
    offeredCardId?: IntFilter<"ExchangeProposal"> | number
    status?: EnumExchangeStatusFilter<"ExchangeProposal"> | $Enums.ExchangeStatus
    createdAt?: DateTimeFilter<"ExchangeProposal"> | Date | string
    marketItem?: XOR<MarketItemScalarRelationFilter, MarketItemWhereInput>
    proposer?: XOR<UserScalarRelationFilter, UserWhereInput>
    offeredCard?: XOR<MyCardScalarRelationFilter, MyCardWhereInput>
  }, "id">

  export type ExchangeProposalOrderByWithAggregationInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    proposerId?: SortOrder
    offeredCardId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    _count?: ExchangeProposalCountOrderByAggregateInput
    _avg?: ExchangeProposalAvgOrderByAggregateInput
    _max?: ExchangeProposalMaxOrderByAggregateInput
    _min?: ExchangeProposalMinOrderByAggregateInput
    _sum?: ExchangeProposalSumOrderByAggregateInput
  }

  export type ExchangeProposalScalarWhereWithAggregatesInput = {
    AND?: ExchangeProposalScalarWhereWithAggregatesInput | ExchangeProposalScalarWhereWithAggregatesInput[]
    OR?: ExchangeProposalScalarWhereWithAggregatesInput[]
    NOT?: ExchangeProposalScalarWhereWithAggregatesInput | ExchangeProposalScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ExchangeProposal"> | number
    marketItemId?: IntWithAggregatesFilter<"ExchangeProposal"> | number
    proposerId?: UuidWithAggregatesFilter<"ExchangeProposal"> | string
    offeredCardId?: IntWithAggregatesFilter<"ExchangeProposal"> | number
    status?: EnumExchangeStatusWithAggregatesFilter<"ExchangeProposal"> | $Enums.ExchangeStatus
    createdAt?: DateTimeWithAggregatesFilter<"ExchangeProposal"> | Date | string
  }

  export type OrderWhereInput = {
    AND?: OrderWhereInput | OrderWhereInput[]
    OR?: OrderWhereInput[]
    NOT?: OrderWhereInput | OrderWhereInput[]
    id?: IntFilter<"Order"> | number
    buyerId?: UuidFilter<"Order"> | string
    marketItemId?: IntFilter<"Order"> | number
    quantity?: IntFilter<"Order"> | number
    totalPrice?: IntFilter<"Order"> | number
    createdAt?: DateTimeFilter<"Order"> | Date | string
    buyer?: XOR<UserScalarRelationFilter, UserWhereInput>
    marketItem?: XOR<MarketItemScalarRelationFilter, MarketItemWhereInput>
  }

  export type OrderOrderByWithRelationInput = {
    id?: SortOrder
    buyerId?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
    createdAt?: SortOrder
    buyer?: UserOrderByWithRelationInput
    marketItem?: MarketItemOrderByWithRelationInput
  }

  export type OrderWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: OrderWhereInput | OrderWhereInput[]
    OR?: OrderWhereInput[]
    NOT?: OrderWhereInput | OrderWhereInput[]
    buyerId?: UuidFilter<"Order"> | string
    marketItemId?: IntFilter<"Order"> | number
    quantity?: IntFilter<"Order"> | number
    totalPrice?: IntFilter<"Order"> | number
    createdAt?: DateTimeFilter<"Order"> | Date | string
    buyer?: XOR<UserScalarRelationFilter, UserWhereInput>
    marketItem?: XOR<MarketItemScalarRelationFilter, MarketItemWhereInput>
  }, "id">

  export type OrderOrderByWithAggregationInput = {
    id?: SortOrder
    buyerId?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
    createdAt?: SortOrder
    _count?: OrderCountOrderByAggregateInput
    _avg?: OrderAvgOrderByAggregateInput
    _max?: OrderMaxOrderByAggregateInput
    _min?: OrderMinOrderByAggregateInput
    _sum?: OrderSumOrderByAggregateInput
  }

  export type OrderScalarWhereWithAggregatesInput = {
    AND?: OrderScalarWhereWithAggregatesInput | OrderScalarWhereWithAggregatesInput[]
    OR?: OrderScalarWhereWithAggregatesInput[]
    NOT?: OrderScalarWhereWithAggregatesInput | OrderScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Order"> | number
    buyerId?: UuidWithAggregatesFilter<"Order"> | string
    marketItemId?: IntWithAggregatesFilter<"Order"> | number
    quantity?: IntWithAggregatesFilter<"Order"> | number
    totalPrice?: IntWithAggregatesFilter<"Order"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Order"> | Date | string
  }

  export type PointLogWhereInput = {
    AND?: PointLogWhereInput | PointLogWhereInput[]
    OR?: PointLogWhereInput[]
    NOT?: PointLogWhereInput | PointLogWhereInput[]
    id?: IntFilter<"PointLog"> | number
    userId?: UuidFilter<"PointLog"> | string
    type?: EnumPointLogTypeFilter<"PointLog"> | $Enums.PointLogType
    amount?: IntFilter<"PointLog"> | number
    createdAt?: DateTimeFilter<"PointLog"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type PointLogOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    amount?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type PointLogWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: PointLogWhereInput | PointLogWhereInput[]
    OR?: PointLogWhereInput[]
    NOT?: PointLogWhereInput | PointLogWhereInput[]
    userId?: UuidFilter<"PointLog"> | string
    type?: EnumPointLogTypeFilter<"PointLog"> | $Enums.PointLogType
    amount?: IntFilter<"PointLog"> | number
    createdAt?: DateTimeFilter<"PointLog"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type PointLogOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    amount?: SortOrder
    createdAt?: SortOrder
    _count?: PointLogCountOrderByAggregateInput
    _avg?: PointLogAvgOrderByAggregateInput
    _max?: PointLogMaxOrderByAggregateInput
    _min?: PointLogMinOrderByAggregateInput
    _sum?: PointLogSumOrderByAggregateInput
  }

  export type PointLogScalarWhereWithAggregatesInput = {
    AND?: PointLogScalarWhereWithAggregatesInput | PointLogScalarWhereWithAggregatesInput[]
    OR?: PointLogScalarWhereWithAggregatesInput[]
    NOT?: PointLogScalarWhereWithAggregatesInput | PointLogScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"PointLog"> | number
    userId?: UuidWithAggregatesFilter<"PointLog"> | string
    type?: EnumPointLogTypeWithAggregatesFilter<"PointLog"> | $Enums.PointLogType
    amount?: IntWithAggregatesFilter<"PointLog"> | number
    createdAt?: DateTimeWithAggregatesFilter<"PointLog"> | Date | string
  }

  export type NotificationWhereInput = {
    AND?: NotificationWhereInput | NotificationWhereInput[]
    OR?: NotificationWhereInput[]
    NOT?: NotificationWhereInput | NotificationWhereInput[]
    id?: IntFilter<"Notification"> | number
    userId?: UuidFilter<"Notification"> | string
    type?: EnumNotificationTypeFilter<"Notification"> | $Enums.NotificationType
    routeType?: EnumRouteTypeFilter<"Notification"> | $Enums.RouteType
    targetId?: IntNullableFilter<"Notification"> | number | null
    message?: StringFilter<"Notification"> | string
    isRead?: BoolFilter<"Notification"> | boolean
    createdAt?: DateTimeFilter<"Notification"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type NotificationOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    routeType?: SortOrder
    targetId?: SortOrderInput | SortOrder
    message?: SortOrder
    isRead?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type NotificationWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: NotificationWhereInput | NotificationWhereInput[]
    OR?: NotificationWhereInput[]
    NOT?: NotificationWhereInput | NotificationWhereInput[]
    userId?: UuidFilter<"Notification"> | string
    type?: EnumNotificationTypeFilter<"Notification"> | $Enums.NotificationType
    routeType?: EnumRouteTypeFilter<"Notification"> | $Enums.RouteType
    targetId?: IntNullableFilter<"Notification"> | number | null
    message?: StringFilter<"Notification"> | string
    isRead?: BoolFilter<"Notification"> | boolean
    createdAt?: DateTimeFilter<"Notification"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type NotificationOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    routeType?: SortOrder
    targetId?: SortOrderInput | SortOrder
    message?: SortOrder
    isRead?: SortOrder
    createdAt?: SortOrder
    _count?: NotificationCountOrderByAggregateInput
    _avg?: NotificationAvgOrderByAggregateInput
    _max?: NotificationMaxOrderByAggregateInput
    _min?: NotificationMinOrderByAggregateInput
    _sum?: NotificationSumOrderByAggregateInput
  }

  export type NotificationScalarWhereWithAggregatesInput = {
    AND?: NotificationScalarWhereWithAggregatesInput | NotificationScalarWhereWithAggregatesInput[]
    OR?: NotificationScalarWhereWithAggregatesInput[]
    NOT?: NotificationScalarWhereWithAggregatesInput | NotificationScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Notification"> | number
    userId?: UuidWithAggregatesFilter<"Notification"> | string
    type?: EnumNotificationTypeWithAggregatesFilter<"Notification"> | $Enums.NotificationType
    routeType?: EnumRouteTypeWithAggregatesFilter<"Notification"> | $Enums.RouteType
    targetId?: IntNullableWithAggregatesFilter<"Notification"> | number | null
    message?: StringWithAggregatesFilter<"Notification"> | string
    isRead?: BoolWithAggregatesFilter<"Notification"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"Notification"> | Date | string
  }

  export type CardCreationLogWhereInput = {
    AND?: CardCreationLogWhereInput | CardCreationLogWhereInput[]
    OR?: CardCreationLogWhereInput[]
    NOT?: CardCreationLogWhereInput | CardCreationLogWhereInput[]
    id?: IntFilter<"CardCreationLog"> | number
    userId?: UuidFilter<"CardCreationLog"> | string
    year?: IntFilter<"CardCreationLog"> | number
    month?: IntFilter<"CardCreationLog"> | number
    count?: IntFilter<"CardCreationLog"> | number
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type CardCreationLogOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type CardCreationLogWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    userId_year_month?: CardCreationLogUserIdYearMonthCompoundUniqueInput
    AND?: CardCreationLogWhereInput | CardCreationLogWhereInput[]
    OR?: CardCreationLogWhereInput[]
    NOT?: CardCreationLogWhereInput | CardCreationLogWhereInput[]
    userId?: UuidFilter<"CardCreationLog"> | string
    year?: IntFilter<"CardCreationLog"> | number
    month?: IntFilter<"CardCreationLog"> | number
    count?: IntFilter<"CardCreationLog"> | number
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "userId_year_month">

  export type CardCreationLogOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
    _count?: CardCreationLogCountOrderByAggregateInput
    _avg?: CardCreationLogAvgOrderByAggregateInput
    _max?: CardCreationLogMaxOrderByAggregateInput
    _min?: CardCreationLogMinOrderByAggregateInput
    _sum?: CardCreationLogSumOrderByAggregateInput
  }

  export type CardCreationLogScalarWhereWithAggregatesInput = {
    AND?: CardCreationLogScalarWhereWithAggregatesInput | CardCreationLogScalarWhereWithAggregatesInput[]
    OR?: CardCreationLogScalarWhereWithAggregatesInput[]
    NOT?: CardCreationLogScalarWhereWithAggregatesInput | CardCreationLogScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"CardCreationLog"> | number
    userId?: UuidWithAggregatesFilter<"CardCreationLog"> | string
    year?: IntWithAggregatesFilter<"CardCreationLog"> | number
    month?: IntWithAggregatesFilter<"CardCreationLog"> | number
    count?: IntWithAggregatesFilter<"CardCreationLog"> | number
  }

  export type RefreshTokenWhereInput = {
    AND?: RefreshTokenWhereInput | RefreshTokenWhereInput[]
    OR?: RefreshTokenWhereInput[]
    NOT?: RefreshTokenWhereInput | RefreshTokenWhereInput[]
    id?: IntFilter<"RefreshToken"> | number
    userId?: UuidFilter<"RefreshToken"> | string
    token?: StringFilter<"RefreshToken"> | string
    expiresAt?: DateTimeFilter<"RefreshToken"> | Date | string
    createdAt?: DateTimeFilter<"RefreshToken"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type RefreshTokenOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    expiresAt?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type RefreshTokenWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    token?: string
    AND?: RefreshTokenWhereInput | RefreshTokenWhereInput[]
    OR?: RefreshTokenWhereInput[]
    NOT?: RefreshTokenWhereInput | RefreshTokenWhereInput[]
    userId?: UuidFilter<"RefreshToken"> | string
    expiresAt?: DateTimeFilter<"RefreshToken"> | Date | string
    createdAt?: DateTimeFilter<"RefreshToken"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "token">

  export type RefreshTokenOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    expiresAt?: SortOrder
    createdAt?: SortOrder
    _count?: RefreshTokenCountOrderByAggregateInput
    _avg?: RefreshTokenAvgOrderByAggregateInput
    _max?: RefreshTokenMaxOrderByAggregateInput
    _min?: RefreshTokenMinOrderByAggregateInput
    _sum?: RefreshTokenSumOrderByAggregateInput
  }

  export type RefreshTokenScalarWhereWithAggregatesInput = {
    AND?: RefreshTokenScalarWhereWithAggregatesInput | RefreshTokenScalarWhereWithAggregatesInput[]
    OR?: RefreshTokenScalarWhereWithAggregatesInput[]
    NOT?: RefreshTokenScalarWhereWithAggregatesInput | RefreshTokenScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"RefreshToken"> | number
    userId?: UuidWithAggregatesFilter<"RefreshToken"> | string
    token?: StringWithAggregatesFilter<"RefreshToken"> | string
    expiresAt?: DateTimeWithAggregatesFilter<"RefreshToken"> | Date | string
    createdAt?: DateTimeWithAggregatesFilter<"RefreshToken"> | Date | string
  }

  export type HistoryWhereInput = {
    AND?: HistoryWhereInput | HistoryWhereInput[]
    OR?: HistoryWhereInput[]
    NOT?: HistoryWhereInput | HistoryWhereInput[]
    id?: BigIntFilter<"History"> | bigint | number
    recordId?: BigIntFilter<"History"> | bigint | number
    tableName?: StringFilter<"History"> | string
    operationType?: EnumOperationTypeFilter<"History"> | $Enums.OperationType
    oldData?: JsonNullableFilter<"History">
    newData?: JsonNullableFilter<"History">
    changedBy?: UuidNullableFilter<"History"> | string | null
    createdAt?: DateTimeFilter<"History"> | Date | string
    user?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }

  export type HistoryOrderByWithRelationInput = {
    id?: SortOrder
    recordId?: SortOrder
    tableName?: SortOrder
    operationType?: SortOrder
    oldData?: SortOrderInput | SortOrder
    newData?: SortOrderInput | SortOrder
    changedBy?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type HistoryWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    AND?: HistoryWhereInput | HistoryWhereInput[]
    OR?: HistoryWhereInput[]
    NOT?: HistoryWhereInput | HistoryWhereInput[]
    recordId?: BigIntFilter<"History"> | bigint | number
    tableName?: StringFilter<"History"> | string
    operationType?: EnumOperationTypeFilter<"History"> | $Enums.OperationType
    oldData?: JsonNullableFilter<"History">
    newData?: JsonNullableFilter<"History">
    changedBy?: UuidNullableFilter<"History"> | string | null
    createdAt?: DateTimeFilter<"History"> | Date | string
    user?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }, "id">

  export type HistoryOrderByWithAggregationInput = {
    id?: SortOrder
    recordId?: SortOrder
    tableName?: SortOrder
    operationType?: SortOrder
    oldData?: SortOrderInput | SortOrder
    newData?: SortOrderInput | SortOrder
    changedBy?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: HistoryCountOrderByAggregateInput
    _avg?: HistoryAvgOrderByAggregateInput
    _max?: HistoryMaxOrderByAggregateInput
    _min?: HistoryMinOrderByAggregateInput
    _sum?: HistorySumOrderByAggregateInput
  }

  export type HistoryScalarWhereWithAggregatesInput = {
    AND?: HistoryScalarWhereWithAggregatesInput | HistoryScalarWhereWithAggregatesInput[]
    OR?: HistoryScalarWhereWithAggregatesInput[]
    NOT?: HistoryScalarWhereWithAggregatesInput | HistoryScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"History"> | bigint | number
    recordId?: BigIntWithAggregatesFilter<"History"> | bigint | number
    tableName?: StringWithAggregatesFilter<"History"> | string
    operationType?: EnumOperationTypeWithAggregatesFilter<"History"> | $Enums.OperationType
    oldData?: JsonNullableWithAggregatesFilter<"History">
    newData?: JsonNullableWithAggregatesFilter<"History">
    changedBy?: UuidNullableWithAggregatesFilter<"History"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"History"> | Date | string
  }

  export type UserCreateInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserPointCreateInput = {
    point?: number
    lastSpinAt?: Date | string | null
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutUserPointInput
  }

  export type UserPointUncheckedCreateInput = {
    id?: number
    userId: string
    point?: number
    lastSpinAt?: Date | string | null
    updatedAt?: Date | string
  }

  export type UserPointUpdateInput = {
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutUserPointNestedInput
  }

  export type UserPointUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserPointCreateManyInput = {
    id?: number
    userId: string
    point?: number
    lastSpinAt?: Date | string | null
    updatedAt?: Date | string
  }

  export type UserPointUpdateManyMutationInput = {
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserPointUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCardCreateInput = {
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
    creator: UserCreateNestedOneWithoutPhotoCardsInput
    myCards?: MyCardCreateNestedManyWithoutPhotoCardInput
  }

  export type PhotoCardUncheckedCreateInput = {
    id?: number
    creatorId: string
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
    myCards?: MyCardUncheckedCreateNestedManyWithoutPhotoCardInput
  }

  export type PhotoCardUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    creator?: UserUpdateOneRequiredWithoutPhotoCardsNestedInput
    myCards?: MyCardUpdateManyWithoutPhotoCardNestedInput
  }

  export type PhotoCardUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    creatorId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    myCards?: MyCardUncheckedUpdateManyWithoutPhotoCardNestedInput
  }

  export type PhotoCardCreateManyInput = {
    id?: number
    creatorId: string
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
  }

  export type PhotoCardUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCardUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    creatorId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MyCardCreateInput = {
    quantity?: number
    acquiredAt?: Date | string
    owner: UserCreateNestedOneWithoutMyCardsInput
    photoCard: PhotoCardCreateNestedOneWithoutMyCardsInput
    marketItems?: MarketItemCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardUncheckedCreateInput = {
    id?: number
    ownerId: string
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalUncheckedCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardUpdateInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    owner?: UserUpdateOneRequiredWithoutMyCardsNestedInput
    photoCard?: PhotoCardUpdateOneRequiredWithoutMyCardsNestedInput
    marketItems?: MarketItemUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItems?: MarketItemUncheckedUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUncheckedUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardCreateManyInput = {
    id?: number
    ownerId: string
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
  }

  export type MyCardUpdateManyMutationInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MyCardUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MarketItemCreateInput = {
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    seller: UserCreateNestedOneWithoutMarketItemsInput
    myCard: MyCardCreateNestedOneWithoutMarketItemsInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutMarketItemInput
    orders?: OrderCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUncheckedCreateInput = {
    id?: number
    sellerId: string
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutMarketItemInput
    orders?: OrderUncheckedCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUpdateInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    seller?: UserUpdateOneRequiredWithoutMarketItemsNestedInput
    myCard?: MyCardUpdateOneRequiredWithoutMarketItemsNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUncheckedUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemCreateManyInput = {
    id?: number
    sellerId: string
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
  }

  export type MarketItemUpdateManyMutationInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MarketItemUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalCreateInput = {
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
    marketItem: MarketItemCreateNestedOneWithoutExchangeProposalsInput
    proposer: UserCreateNestedOneWithoutExchangeProposalsInput
    offeredCard: MyCardCreateNestedOneWithoutOfferedExchangesInput
  }

  export type ExchangeProposalUncheckedCreateInput = {
    id?: number
    marketItemId: number
    proposerId: string
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalUpdateInput = {
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItem?: MarketItemUpdateOneRequiredWithoutExchangeProposalsNestedInput
    proposer?: UserUpdateOneRequiredWithoutExchangeProposalsNestedInput
    offeredCard?: MyCardUpdateOneRequiredWithoutOfferedExchangesNestedInput
  }

  export type ExchangeProposalUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalCreateManyInput = {
    id?: number
    marketItemId: number
    proposerId: string
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalUpdateManyMutationInput = {
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderCreateInput = {
    quantity: number
    totalPrice: number
    createdAt?: Date | string
    buyer: UserCreateNestedOneWithoutOrdersInput
    marketItem: MarketItemCreateNestedOneWithoutOrdersInput
  }

  export type OrderUncheckedCreateInput = {
    id?: number
    buyerId: string
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type OrderUpdateInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    buyer?: UserUpdateOneRequiredWithoutOrdersNestedInput
    marketItem?: MarketItemUpdateOneRequiredWithoutOrdersNestedInput
  }

  export type OrderUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    buyerId?: StringFieldUpdateOperationsInput | string
    marketItemId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderCreateManyInput = {
    id?: number
    buyerId: string
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type OrderUpdateManyMutationInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    buyerId?: StringFieldUpdateOperationsInput | string
    marketItemId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogCreateInput = {
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPointLogsInput
  }

  export type PointLogUncheckedCreateInput = {
    id?: number
    userId: string
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
  }

  export type PointLogUpdateInput = {
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPointLogsNestedInput
  }

  export type PointLogUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogCreateManyInput = {
    id?: number
    userId: string
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
  }

  export type PointLogUpdateManyMutationInput = {
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationCreateInput = {
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutNotificationsInput
  }

  export type NotificationUncheckedCreateInput = {
    id?: number
    userId: string
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
  }

  export type NotificationUpdateInput = {
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutNotificationsNestedInput
  }

  export type NotificationUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationCreateManyInput = {
    id?: number
    userId: string
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
  }

  export type NotificationUpdateManyMutationInput = {
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CardCreationLogCreateInput = {
    year: number
    month: number
    count?: number
    user: UserCreateNestedOneWithoutCreationLogsInput
  }

  export type CardCreationLogUncheckedCreateInput = {
    id?: number
    userId: string
    year: number
    month: number
    count?: number
  }

  export type CardCreationLogUpdateInput = {
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
    user?: UserUpdateOneRequiredWithoutCreationLogsNestedInput
  }

  export type CardCreationLogUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type CardCreationLogCreateManyInput = {
    id?: number
    userId: string
    year: number
    month: number
    count?: number
  }

  export type CardCreationLogUpdateManyMutationInput = {
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type CardCreationLogUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type RefreshTokenCreateInput = {
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutRefreshTokensInput
  }

  export type RefreshTokenUncheckedCreateInput = {
    id?: number
    userId: string
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
  }

  export type RefreshTokenUpdateInput = {
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutRefreshTokensNestedInput
  }

  export type RefreshTokenUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RefreshTokenCreateManyInput = {
    id?: number
    userId: string
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
  }

  export type RefreshTokenUpdateManyMutationInput = {
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RefreshTokenUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCreateInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    user?: UserCreateNestedOneWithoutHistoriesInput
  }

  export type HistoryUncheckedCreateInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    changedBy?: string | null
    createdAt?: Date | string
  }

  export type HistoryUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneWithoutHistoriesNestedInput
  }

  export type HistoryUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    changedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCreateManyInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    changedBy?: string | null
    createdAt?: Date | string
  }

  export type HistoryUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    changedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UuidFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidFilter<$PrismaModel> | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumProviderFilter<$PrismaModel = never> = {
    equals?: $Enums.Provider | EnumProviderFieldRefInput<$PrismaModel>
    in?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    notIn?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    not?: NestedEnumProviderFilter<$PrismaModel> | $Enums.Provider
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type UserPointNullableScalarRelationFilter = {
    is?: UserPointWhereInput | null
    isNot?: UserPointWhereInput | null
  }

  export type PhotoCardListRelationFilter = {
    every?: PhotoCardWhereInput
    some?: PhotoCardWhereInput
    none?: PhotoCardWhereInput
  }

  export type MyCardListRelationFilter = {
    every?: MyCardWhereInput
    some?: MyCardWhereInput
    none?: MyCardWhereInput
  }

  export type MarketItemListRelationFilter = {
    every?: MarketItemWhereInput
    some?: MarketItemWhereInput
    none?: MarketItemWhereInput
  }

  export type ExchangeProposalListRelationFilter = {
    every?: ExchangeProposalWhereInput
    some?: ExchangeProposalWhereInput
    none?: ExchangeProposalWhereInput
  }

  export type OrderListRelationFilter = {
    every?: OrderWhereInput
    some?: OrderWhereInput
    none?: OrderWhereInput
  }

  export type PointLogListRelationFilter = {
    every?: PointLogWhereInput
    some?: PointLogWhereInput
    none?: PointLogWhereInput
  }

  export type NotificationListRelationFilter = {
    every?: NotificationWhereInput
    some?: NotificationWhereInput
    none?: NotificationWhereInput
  }

  export type CardCreationLogListRelationFilter = {
    every?: CardCreationLogWhereInput
    some?: CardCreationLogWhereInput
    none?: CardCreationLogWhereInput
  }

  export type RefreshTokenListRelationFilter = {
    every?: RefreshTokenWhereInput
    some?: RefreshTokenWhereInput
    none?: RefreshTokenWhereInput
  }

  export type HistoryListRelationFilter = {
    every?: HistoryWhereInput
    some?: HistoryWhereInput
    none?: HistoryWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type PhotoCardOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MyCardOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MarketItemOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ExchangeProposalOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type OrderOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PointLogOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type NotificationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CardCreationLogOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type RefreshTokenOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type HistoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserProviderProviderIdCompoundUniqueInput = {
    provider: $Enums.Provider
    providerId: string
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    nickname?: SortOrder
    provider?: SortOrder
    providerId?: SortOrder
    createdAt?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    nickname?: SortOrder
    provider?: SortOrder
    providerId?: SortOrder
    createdAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    nickname?: SortOrder
    provider?: SortOrder
    providerId?: SortOrder
    createdAt?: SortOrder
  }

  export type UuidWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumProviderWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Provider | EnumProviderFieldRefInput<$PrismaModel>
    in?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    notIn?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    not?: NestedEnumProviderWithAggregatesFilter<$PrismaModel> | $Enums.Provider
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumProviderFilter<$PrismaModel>
    _max?: NestedEnumProviderFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type UserPointCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    point?: SortOrder
    lastSpinAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserPointAvgOrderByAggregateInput = {
    id?: SortOrder
    point?: SortOrder
  }

  export type UserPointMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    point?: SortOrder
    lastSpinAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserPointMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    point?: SortOrder
    lastSpinAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserPointSumOrderByAggregateInput = {
    id?: SortOrder
    point?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type EnumGenreFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel>
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    not?: NestedEnumGenreFilter<$PrismaModel> | $Enums.Genre
  }

  export type EnumCardGradeFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel>
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    not?: NestedEnumCardGradeFilter<$PrismaModel> | $Enums.CardGrade
  }

  export type PhotoCardCountOrderByAggregateInput = {
    id?: SortOrder
    creatorId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    genre?: SortOrder
    grade?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoCardAvgOrderByAggregateInput = {
    id?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
  }

  export type PhotoCardMaxOrderByAggregateInput = {
    id?: SortOrder
    creatorId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    genre?: SortOrder
    grade?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoCardMinOrderByAggregateInput = {
    id?: SortOrder
    creatorId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    genre?: SortOrder
    grade?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoCardSumOrderByAggregateInput = {
    id?: SortOrder
    price?: SortOrder
    totalQuantity?: SortOrder
  }

  export type EnumGenreWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel>
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    not?: NestedEnumGenreWithAggregatesFilter<$PrismaModel> | $Enums.Genre
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumGenreFilter<$PrismaModel>
    _max?: NestedEnumGenreFilter<$PrismaModel>
  }

  export type EnumCardGradeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel>
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    not?: NestedEnumCardGradeWithAggregatesFilter<$PrismaModel> | $Enums.CardGrade
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumCardGradeFilter<$PrismaModel>
    _max?: NestedEnumCardGradeFilter<$PrismaModel>
  }

  export type PhotoCardScalarRelationFilter = {
    is?: PhotoCardWhereInput
    isNot?: PhotoCardWhereInput
  }

  export type MyCardCountOrderByAggregateInput = {
    id?: SortOrder
    ownerId?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
    acquiredAt?: SortOrder
  }

  export type MyCardAvgOrderByAggregateInput = {
    id?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
  }

  export type MyCardMaxOrderByAggregateInput = {
    id?: SortOrder
    ownerId?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
    acquiredAt?: SortOrder
  }

  export type MyCardMinOrderByAggregateInput = {
    id?: SortOrder
    ownerId?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
    acquiredAt?: SortOrder
  }

  export type MyCardSumOrderByAggregateInput = {
    id?: SortOrder
    photoCardId?: SortOrder
    quantity?: SortOrder
  }

  export type EnumCardGradeNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel> | null
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    not?: NestedEnumCardGradeNullableFilter<$PrismaModel> | $Enums.CardGrade | null
  }

  export type EnumGenreNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel> | null
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    not?: NestedEnumGenreNullableFilter<$PrismaModel> | $Enums.Genre | null
  }

  export type EnumMarketStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketStatus | EnumMarketStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketStatusFilter<$PrismaModel> | $Enums.MarketStatus
  }

  export type MyCardScalarRelationFilter = {
    is?: MyCardWhereInput
    isNot?: MyCardWhereInput
  }

  export type MarketItemCountOrderByAggregateInput = {
    id?: SortOrder
    sellerId?: SortOrder
    myCardId?: SortOrder
    grade?: SortOrder
    genre?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
    wantedGrade?: SortOrder
    wantedGenre?: SortOrder
    wantedDescription?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type MarketItemAvgOrderByAggregateInput = {
    id?: SortOrder
    myCardId?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
  }

  export type MarketItemMaxOrderByAggregateInput = {
    id?: SortOrder
    sellerId?: SortOrder
    myCardId?: SortOrder
    grade?: SortOrder
    genre?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
    wantedGrade?: SortOrder
    wantedGenre?: SortOrder
    wantedDescription?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type MarketItemMinOrderByAggregateInput = {
    id?: SortOrder
    sellerId?: SortOrder
    myCardId?: SortOrder
    grade?: SortOrder
    genre?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
    wantedGrade?: SortOrder
    wantedGenre?: SortOrder
    wantedDescription?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type MarketItemSumOrderByAggregateInput = {
    id?: SortOrder
    myCardId?: SortOrder
    quantity?: SortOrder
    soldQuantity?: SortOrder
    pricePerCard?: SortOrder
  }

  export type EnumCardGradeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel> | null
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    not?: NestedEnumCardGradeNullableWithAggregatesFilter<$PrismaModel> | $Enums.CardGrade | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumCardGradeNullableFilter<$PrismaModel>
    _max?: NestedEnumCardGradeNullableFilter<$PrismaModel>
  }

  export type EnumGenreNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel> | null
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    not?: NestedEnumGenreNullableWithAggregatesFilter<$PrismaModel> | $Enums.Genre | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumGenreNullableFilter<$PrismaModel>
    _max?: NestedEnumGenreNullableFilter<$PrismaModel>
  }

  export type EnumMarketStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketStatus | EnumMarketStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketStatusWithAggregatesFilter<$PrismaModel> | $Enums.MarketStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMarketStatusFilter<$PrismaModel>
    _max?: NestedEnumMarketStatusFilter<$PrismaModel>
  }

  export type EnumExchangeStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ExchangeStatus | EnumExchangeStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumExchangeStatusFilter<$PrismaModel> | $Enums.ExchangeStatus
  }

  export type MarketItemScalarRelationFilter = {
    is?: MarketItemWhereInput
    isNot?: MarketItemWhereInput
  }

  export type ExchangeProposalCountOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    proposerId?: SortOrder
    offeredCardId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type ExchangeProposalAvgOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    offeredCardId?: SortOrder
  }

  export type ExchangeProposalMaxOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    proposerId?: SortOrder
    offeredCardId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type ExchangeProposalMinOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    proposerId?: SortOrder
    offeredCardId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type ExchangeProposalSumOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    offeredCardId?: SortOrder
  }

  export type EnumExchangeStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ExchangeStatus | EnumExchangeStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumExchangeStatusWithAggregatesFilter<$PrismaModel> | $Enums.ExchangeStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumExchangeStatusFilter<$PrismaModel>
    _max?: NestedEnumExchangeStatusFilter<$PrismaModel>
  }

  export type OrderCountOrderByAggregateInput = {
    id?: SortOrder
    buyerId?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
    createdAt?: SortOrder
  }

  export type OrderAvgOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
  }

  export type OrderMaxOrderByAggregateInput = {
    id?: SortOrder
    buyerId?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
    createdAt?: SortOrder
  }

  export type OrderMinOrderByAggregateInput = {
    id?: SortOrder
    buyerId?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
    createdAt?: SortOrder
  }

  export type OrderSumOrderByAggregateInput = {
    id?: SortOrder
    marketItemId?: SortOrder
    quantity?: SortOrder
    totalPrice?: SortOrder
  }

  export type EnumPointLogTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.PointLogType | EnumPointLogTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumPointLogTypeFilter<$PrismaModel> | $Enums.PointLogType
  }

  export type PointLogCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    amount?: SortOrder
    createdAt?: SortOrder
  }

  export type PointLogAvgOrderByAggregateInput = {
    id?: SortOrder
    amount?: SortOrder
  }

  export type PointLogMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    amount?: SortOrder
    createdAt?: SortOrder
  }

  export type PointLogMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    amount?: SortOrder
    createdAt?: SortOrder
  }

  export type PointLogSumOrderByAggregateInput = {
    id?: SortOrder
    amount?: SortOrder
  }

  export type EnumPointLogTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PointLogType | EnumPointLogTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumPointLogTypeWithAggregatesFilter<$PrismaModel> | $Enums.PointLogType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPointLogTypeFilter<$PrismaModel>
    _max?: NestedEnumPointLogTypeFilter<$PrismaModel>
  }

  export type EnumNotificationTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.NotificationType | EnumNotificationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumNotificationTypeFilter<$PrismaModel> | $Enums.NotificationType
  }

  export type EnumRouteTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.RouteType | EnumRouteTypeFieldRefInput<$PrismaModel>
    in?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumRouteTypeFilter<$PrismaModel> | $Enums.RouteType
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NotificationCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    routeType?: SortOrder
    targetId?: SortOrder
    message?: SortOrder
    isRead?: SortOrder
    createdAt?: SortOrder
  }

  export type NotificationAvgOrderByAggregateInput = {
    id?: SortOrder
    targetId?: SortOrder
  }

  export type NotificationMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    routeType?: SortOrder
    targetId?: SortOrder
    message?: SortOrder
    isRead?: SortOrder
    createdAt?: SortOrder
  }

  export type NotificationMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    routeType?: SortOrder
    targetId?: SortOrder
    message?: SortOrder
    isRead?: SortOrder
    createdAt?: SortOrder
  }

  export type NotificationSumOrderByAggregateInput = {
    id?: SortOrder
    targetId?: SortOrder
  }

  export type EnumNotificationTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.NotificationType | EnumNotificationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumNotificationTypeWithAggregatesFilter<$PrismaModel> | $Enums.NotificationType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumNotificationTypeFilter<$PrismaModel>
    _max?: NestedEnumNotificationTypeFilter<$PrismaModel>
  }

  export type EnumRouteTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.RouteType | EnumRouteTypeFieldRefInput<$PrismaModel>
    in?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumRouteTypeWithAggregatesFilter<$PrismaModel> | $Enums.RouteType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRouteTypeFilter<$PrismaModel>
    _max?: NestedEnumRouteTypeFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type CardCreationLogUserIdYearMonthCompoundUniqueInput = {
    userId: string
    year: number
    month: number
  }

  export type CardCreationLogCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
  }

  export type CardCreationLogAvgOrderByAggregateInput = {
    id?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
  }

  export type CardCreationLogMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
  }

  export type CardCreationLogMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
  }

  export type CardCreationLogSumOrderByAggregateInput = {
    id?: SortOrder
    year?: SortOrder
    month?: SortOrder
    count?: SortOrder
  }

  export type RefreshTokenCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    expiresAt?: SortOrder
    createdAt?: SortOrder
  }

  export type RefreshTokenAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type RefreshTokenMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    expiresAt?: SortOrder
    createdAt?: SortOrder
  }

  export type RefreshTokenMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    expiresAt?: SortOrder
    createdAt?: SortOrder
  }

  export type RefreshTokenSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type BigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }

  export type EnumOperationTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.OperationType | EnumOperationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumOperationTypeFilter<$PrismaModel> | $Enums.OperationType
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type UuidNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidNullableFilter<$PrismaModel> | string | null
  }

  export type UserNullableScalarRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type HistoryCountOrderByAggregateInput = {
    id?: SortOrder
    recordId?: SortOrder
    tableName?: SortOrder
    operationType?: SortOrder
    oldData?: SortOrder
    newData?: SortOrder
    changedBy?: SortOrder
    createdAt?: SortOrder
  }

  export type HistoryAvgOrderByAggregateInput = {
    id?: SortOrder
    recordId?: SortOrder
  }

  export type HistoryMaxOrderByAggregateInput = {
    id?: SortOrder
    recordId?: SortOrder
    tableName?: SortOrder
    operationType?: SortOrder
    changedBy?: SortOrder
    createdAt?: SortOrder
  }

  export type HistoryMinOrderByAggregateInput = {
    id?: SortOrder
    recordId?: SortOrder
    tableName?: SortOrder
    operationType?: SortOrder
    changedBy?: SortOrder
    createdAt?: SortOrder
  }

  export type HistorySumOrderByAggregateInput = {
    id?: SortOrder
    recordId?: SortOrder
  }

  export type BigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }

  export type EnumOperationTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.OperationType | EnumOperationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumOperationTypeWithAggregatesFilter<$PrismaModel> | $Enums.OperationType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumOperationTypeFilter<$PrismaModel>
    _max?: NestedEnumOperationTypeFilter<$PrismaModel>
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type UuidNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type UserPointCreateNestedOneWithoutUserInput = {
    create?: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
    connectOrCreate?: UserPointCreateOrConnectWithoutUserInput
    connect?: UserPointWhereUniqueInput
  }

  export type PhotoCardCreateNestedManyWithoutCreatorInput = {
    create?: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput> | PhotoCardCreateWithoutCreatorInput[] | PhotoCardUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: PhotoCardCreateOrConnectWithoutCreatorInput | PhotoCardCreateOrConnectWithoutCreatorInput[]
    createMany?: PhotoCardCreateManyCreatorInputEnvelope
    connect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
  }

  export type MyCardCreateNestedManyWithoutOwnerInput = {
    create?: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput> | MyCardCreateWithoutOwnerInput[] | MyCardUncheckedCreateWithoutOwnerInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutOwnerInput | MyCardCreateOrConnectWithoutOwnerInput[]
    createMany?: MyCardCreateManyOwnerInputEnvelope
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
  }

  export type MarketItemCreateNestedManyWithoutSellerInput = {
    create?: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput> | MarketItemCreateWithoutSellerInput[] | MarketItemUncheckedCreateWithoutSellerInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutSellerInput | MarketItemCreateOrConnectWithoutSellerInput[]
    createMany?: MarketItemCreateManySellerInputEnvelope
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
  }

  export type ExchangeProposalCreateNestedManyWithoutProposerInput = {
    create?: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput> | ExchangeProposalCreateWithoutProposerInput[] | ExchangeProposalUncheckedCreateWithoutProposerInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutProposerInput | ExchangeProposalCreateOrConnectWithoutProposerInput[]
    createMany?: ExchangeProposalCreateManyProposerInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type OrderCreateNestedManyWithoutBuyerInput = {
    create?: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput> | OrderCreateWithoutBuyerInput[] | OrderUncheckedCreateWithoutBuyerInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutBuyerInput | OrderCreateOrConnectWithoutBuyerInput[]
    createMany?: OrderCreateManyBuyerInputEnvelope
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
  }

  export type PointLogCreateNestedManyWithoutUserInput = {
    create?: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput> | PointLogCreateWithoutUserInput[] | PointLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PointLogCreateOrConnectWithoutUserInput | PointLogCreateOrConnectWithoutUserInput[]
    createMany?: PointLogCreateManyUserInputEnvelope
    connect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
  }

  export type NotificationCreateNestedManyWithoutUserInput = {
    create?: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput> | NotificationCreateWithoutUserInput[] | NotificationUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NotificationCreateOrConnectWithoutUserInput | NotificationCreateOrConnectWithoutUserInput[]
    createMany?: NotificationCreateManyUserInputEnvelope
    connect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
  }

  export type CardCreationLogCreateNestedManyWithoutUserInput = {
    create?: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput> | CardCreationLogCreateWithoutUserInput[] | CardCreationLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: CardCreationLogCreateOrConnectWithoutUserInput | CardCreationLogCreateOrConnectWithoutUserInput[]
    createMany?: CardCreationLogCreateManyUserInputEnvelope
    connect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
  }

  export type RefreshTokenCreateNestedManyWithoutUserInput = {
    create?: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput> | RefreshTokenCreateWithoutUserInput[] | RefreshTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: RefreshTokenCreateOrConnectWithoutUserInput | RefreshTokenCreateOrConnectWithoutUserInput[]
    createMany?: RefreshTokenCreateManyUserInputEnvelope
    connect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
  }

  export type HistoryCreateNestedManyWithoutUserInput = {
    create?: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput> | HistoryCreateWithoutUserInput[] | HistoryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HistoryCreateOrConnectWithoutUserInput | HistoryCreateOrConnectWithoutUserInput[]
    createMany?: HistoryCreateManyUserInputEnvelope
    connect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
  }

  export type UserPointUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
    connectOrCreate?: UserPointCreateOrConnectWithoutUserInput
    connect?: UserPointWhereUniqueInput
  }

  export type PhotoCardUncheckedCreateNestedManyWithoutCreatorInput = {
    create?: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput> | PhotoCardCreateWithoutCreatorInput[] | PhotoCardUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: PhotoCardCreateOrConnectWithoutCreatorInput | PhotoCardCreateOrConnectWithoutCreatorInput[]
    createMany?: PhotoCardCreateManyCreatorInputEnvelope
    connect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
  }

  export type MyCardUncheckedCreateNestedManyWithoutOwnerInput = {
    create?: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput> | MyCardCreateWithoutOwnerInput[] | MyCardUncheckedCreateWithoutOwnerInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutOwnerInput | MyCardCreateOrConnectWithoutOwnerInput[]
    createMany?: MyCardCreateManyOwnerInputEnvelope
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
  }

  export type MarketItemUncheckedCreateNestedManyWithoutSellerInput = {
    create?: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput> | MarketItemCreateWithoutSellerInput[] | MarketItemUncheckedCreateWithoutSellerInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutSellerInput | MarketItemCreateOrConnectWithoutSellerInput[]
    createMany?: MarketItemCreateManySellerInputEnvelope
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
  }

  export type ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput = {
    create?: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput> | ExchangeProposalCreateWithoutProposerInput[] | ExchangeProposalUncheckedCreateWithoutProposerInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutProposerInput | ExchangeProposalCreateOrConnectWithoutProposerInput[]
    createMany?: ExchangeProposalCreateManyProposerInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type OrderUncheckedCreateNestedManyWithoutBuyerInput = {
    create?: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput> | OrderCreateWithoutBuyerInput[] | OrderUncheckedCreateWithoutBuyerInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutBuyerInput | OrderCreateOrConnectWithoutBuyerInput[]
    createMany?: OrderCreateManyBuyerInputEnvelope
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
  }

  export type PointLogUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput> | PointLogCreateWithoutUserInput[] | PointLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PointLogCreateOrConnectWithoutUserInput | PointLogCreateOrConnectWithoutUserInput[]
    createMany?: PointLogCreateManyUserInputEnvelope
    connect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
  }

  export type NotificationUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput> | NotificationCreateWithoutUserInput[] | NotificationUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NotificationCreateOrConnectWithoutUserInput | NotificationCreateOrConnectWithoutUserInput[]
    createMany?: NotificationCreateManyUserInputEnvelope
    connect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
  }

  export type CardCreationLogUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput> | CardCreationLogCreateWithoutUserInput[] | CardCreationLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: CardCreationLogCreateOrConnectWithoutUserInput | CardCreationLogCreateOrConnectWithoutUserInput[]
    createMany?: CardCreationLogCreateManyUserInputEnvelope
    connect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
  }

  export type RefreshTokenUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput> | RefreshTokenCreateWithoutUserInput[] | RefreshTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: RefreshTokenCreateOrConnectWithoutUserInput | RefreshTokenCreateOrConnectWithoutUserInput[]
    createMany?: RefreshTokenCreateManyUserInputEnvelope
    connect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
  }

  export type HistoryUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput> | HistoryCreateWithoutUserInput[] | HistoryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HistoryCreateOrConnectWithoutUserInput | HistoryCreateOrConnectWithoutUserInput[]
    createMany?: HistoryCreateManyUserInputEnvelope
    connect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumProviderFieldUpdateOperationsInput = {
    set?: $Enums.Provider
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type UserPointUpdateOneWithoutUserNestedInput = {
    create?: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
    connectOrCreate?: UserPointCreateOrConnectWithoutUserInput
    upsert?: UserPointUpsertWithoutUserInput
    disconnect?: UserPointWhereInput | boolean
    delete?: UserPointWhereInput | boolean
    connect?: UserPointWhereUniqueInput
    update?: XOR<XOR<UserPointUpdateToOneWithWhereWithoutUserInput, UserPointUpdateWithoutUserInput>, UserPointUncheckedUpdateWithoutUserInput>
  }

  export type PhotoCardUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput> | PhotoCardCreateWithoutCreatorInput[] | PhotoCardUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: PhotoCardCreateOrConnectWithoutCreatorInput | PhotoCardCreateOrConnectWithoutCreatorInput[]
    upsert?: PhotoCardUpsertWithWhereUniqueWithoutCreatorInput | PhotoCardUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: PhotoCardCreateManyCreatorInputEnvelope
    set?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    disconnect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    delete?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    connect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    update?: PhotoCardUpdateWithWhereUniqueWithoutCreatorInput | PhotoCardUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: PhotoCardUpdateManyWithWhereWithoutCreatorInput | PhotoCardUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: PhotoCardScalarWhereInput | PhotoCardScalarWhereInput[]
  }

  export type MyCardUpdateManyWithoutOwnerNestedInput = {
    create?: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput> | MyCardCreateWithoutOwnerInput[] | MyCardUncheckedCreateWithoutOwnerInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutOwnerInput | MyCardCreateOrConnectWithoutOwnerInput[]
    upsert?: MyCardUpsertWithWhereUniqueWithoutOwnerInput | MyCardUpsertWithWhereUniqueWithoutOwnerInput[]
    createMany?: MyCardCreateManyOwnerInputEnvelope
    set?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    disconnect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    delete?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    update?: MyCardUpdateWithWhereUniqueWithoutOwnerInput | MyCardUpdateWithWhereUniqueWithoutOwnerInput[]
    updateMany?: MyCardUpdateManyWithWhereWithoutOwnerInput | MyCardUpdateManyWithWhereWithoutOwnerInput[]
    deleteMany?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
  }

  export type MarketItemUpdateManyWithoutSellerNestedInput = {
    create?: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput> | MarketItemCreateWithoutSellerInput[] | MarketItemUncheckedCreateWithoutSellerInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutSellerInput | MarketItemCreateOrConnectWithoutSellerInput[]
    upsert?: MarketItemUpsertWithWhereUniqueWithoutSellerInput | MarketItemUpsertWithWhereUniqueWithoutSellerInput[]
    createMany?: MarketItemCreateManySellerInputEnvelope
    set?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    disconnect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    delete?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    update?: MarketItemUpdateWithWhereUniqueWithoutSellerInput | MarketItemUpdateWithWhereUniqueWithoutSellerInput[]
    updateMany?: MarketItemUpdateManyWithWhereWithoutSellerInput | MarketItemUpdateManyWithWhereWithoutSellerInput[]
    deleteMany?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
  }

  export type ExchangeProposalUpdateManyWithoutProposerNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput> | ExchangeProposalCreateWithoutProposerInput[] | ExchangeProposalUncheckedCreateWithoutProposerInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutProposerInput | ExchangeProposalCreateOrConnectWithoutProposerInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutProposerInput | ExchangeProposalUpsertWithWhereUniqueWithoutProposerInput[]
    createMany?: ExchangeProposalCreateManyProposerInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutProposerInput | ExchangeProposalUpdateWithWhereUniqueWithoutProposerInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutProposerInput | ExchangeProposalUpdateManyWithWhereWithoutProposerInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type OrderUpdateManyWithoutBuyerNestedInput = {
    create?: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput> | OrderCreateWithoutBuyerInput[] | OrderUncheckedCreateWithoutBuyerInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutBuyerInput | OrderCreateOrConnectWithoutBuyerInput[]
    upsert?: OrderUpsertWithWhereUniqueWithoutBuyerInput | OrderUpsertWithWhereUniqueWithoutBuyerInput[]
    createMany?: OrderCreateManyBuyerInputEnvelope
    set?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    disconnect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    delete?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    update?: OrderUpdateWithWhereUniqueWithoutBuyerInput | OrderUpdateWithWhereUniqueWithoutBuyerInput[]
    updateMany?: OrderUpdateManyWithWhereWithoutBuyerInput | OrderUpdateManyWithWhereWithoutBuyerInput[]
    deleteMany?: OrderScalarWhereInput | OrderScalarWhereInput[]
  }

  export type PointLogUpdateManyWithoutUserNestedInput = {
    create?: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput> | PointLogCreateWithoutUserInput[] | PointLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PointLogCreateOrConnectWithoutUserInput | PointLogCreateOrConnectWithoutUserInput[]
    upsert?: PointLogUpsertWithWhereUniqueWithoutUserInput | PointLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PointLogCreateManyUserInputEnvelope
    set?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    disconnect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    delete?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    connect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    update?: PointLogUpdateWithWhereUniqueWithoutUserInput | PointLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PointLogUpdateManyWithWhereWithoutUserInput | PointLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PointLogScalarWhereInput | PointLogScalarWhereInput[]
  }

  export type NotificationUpdateManyWithoutUserNestedInput = {
    create?: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput> | NotificationCreateWithoutUserInput[] | NotificationUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NotificationCreateOrConnectWithoutUserInput | NotificationCreateOrConnectWithoutUserInput[]
    upsert?: NotificationUpsertWithWhereUniqueWithoutUserInput | NotificationUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: NotificationCreateManyUserInputEnvelope
    set?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    disconnect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    delete?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    connect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    update?: NotificationUpdateWithWhereUniqueWithoutUserInput | NotificationUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: NotificationUpdateManyWithWhereWithoutUserInput | NotificationUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: NotificationScalarWhereInput | NotificationScalarWhereInput[]
  }

  export type CardCreationLogUpdateManyWithoutUserNestedInput = {
    create?: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput> | CardCreationLogCreateWithoutUserInput[] | CardCreationLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: CardCreationLogCreateOrConnectWithoutUserInput | CardCreationLogCreateOrConnectWithoutUserInput[]
    upsert?: CardCreationLogUpsertWithWhereUniqueWithoutUserInput | CardCreationLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: CardCreationLogCreateManyUserInputEnvelope
    set?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    disconnect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    delete?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    connect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    update?: CardCreationLogUpdateWithWhereUniqueWithoutUserInput | CardCreationLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: CardCreationLogUpdateManyWithWhereWithoutUserInput | CardCreationLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: CardCreationLogScalarWhereInput | CardCreationLogScalarWhereInput[]
  }

  export type RefreshTokenUpdateManyWithoutUserNestedInput = {
    create?: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput> | RefreshTokenCreateWithoutUserInput[] | RefreshTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: RefreshTokenCreateOrConnectWithoutUserInput | RefreshTokenCreateOrConnectWithoutUserInput[]
    upsert?: RefreshTokenUpsertWithWhereUniqueWithoutUserInput | RefreshTokenUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: RefreshTokenCreateManyUserInputEnvelope
    set?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    disconnect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    delete?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    connect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    update?: RefreshTokenUpdateWithWhereUniqueWithoutUserInput | RefreshTokenUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: RefreshTokenUpdateManyWithWhereWithoutUserInput | RefreshTokenUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: RefreshTokenScalarWhereInput | RefreshTokenScalarWhereInput[]
  }

  export type HistoryUpdateManyWithoutUserNestedInput = {
    create?: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput> | HistoryCreateWithoutUserInput[] | HistoryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HistoryCreateOrConnectWithoutUserInput | HistoryCreateOrConnectWithoutUserInput[]
    upsert?: HistoryUpsertWithWhereUniqueWithoutUserInput | HistoryUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: HistoryCreateManyUserInputEnvelope
    set?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    disconnect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    delete?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    connect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    update?: HistoryUpdateWithWhereUniqueWithoutUserInput | HistoryUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: HistoryUpdateManyWithWhereWithoutUserInput | HistoryUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: HistoryScalarWhereInput | HistoryScalarWhereInput[]
  }

  export type UserPointUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
    connectOrCreate?: UserPointCreateOrConnectWithoutUserInput
    upsert?: UserPointUpsertWithoutUserInput
    disconnect?: UserPointWhereInput | boolean
    delete?: UserPointWhereInput | boolean
    connect?: UserPointWhereUniqueInput
    update?: XOR<XOR<UserPointUpdateToOneWithWhereWithoutUserInput, UserPointUpdateWithoutUserInput>, UserPointUncheckedUpdateWithoutUserInput>
  }

  export type PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput> | PhotoCardCreateWithoutCreatorInput[] | PhotoCardUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: PhotoCardCreateOrConnectWithoutCreatorInput | PhotoCardCreateOrConnectWithoutCreatorInput[]
    upsert?: PhotoCardUpsertWithWhereUniqueWithoutCreatorInput | PhotoCardUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: PhotoCardCreateManyCreatorInputEnvelope
    set?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    disconnect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    delete?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    connect?: PhotoCardWhereUniqueInput | PhotoCardWhereUniqueInput[]
    update?: PhotoCardUpdateWithWhereUniqueWithoutCreatorInput | PhotoCardUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: PhotoCardUpdateManyWithWhereWithoutCreatorInput | PhotoCardUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: PhotoCardScalarWhereInput | PhotoCardScalarWhereInput[]
  }

  export type MyCardUncheckedUpdateManyWithoutOwnerNestedInput = {
    create?: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput> | MyCardCreateWithoutOwnerInput[] | MyCardUncheckedCreateWithoutOwnerInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutOwnerInput | MyCardCreateOrConnectWithoutOwnerInput[]
    upsert?: MyCardUpsertWithWhereUniqueWithoutOwnerInput | MyCardUpsertWithWhereUniqueWithoutOwnerInput[]
    createMany?: MyCardCreateManyOwnerInputEnvelope
    set?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    disconnect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    delete?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    update?: MyCardUpdateWithWhereUniqueWithoutOwnerInput | MyCardUpdateWithWhereUniqueWithoutOwnerInput[]
    updateMany?: MyCardUpdateManyWithWhereWithoutOwnerInput | MyCardUpdateManyWithWhereWithoutOwnerInput[]
    deleteMany?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
  }

  export type MarketItemUncheckedUpdateManyWithoutSellerNestedInput = {
    create?: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput> | MarketItemCreateWithoutSellerInput[] | MarketItemUncheckedCreateWithoutSellerInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutSellerInput | MarketItemCreateOrConnectWithoutSellerInput[]
    upsert?: MarketItemUpsertWithWhereUniqueWithoutSellerInput | MarketItemUpsertWithWhereUniqueWithoutSellerInput[]
    createMany?: MarketItemCreateManySellerInputEnvelope
    set?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    disconnect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    delete?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    update?: MarketItemUpdateWithWhereUniqueWithoutSellerInput | MarketItemUpdateWithWhereUniqueWithoutSellerInput[]
    updateMany?: MarketItemUpdateManyWithWhereWithoutSellerInput | MarketItemUpdateManyWithWhereWithoutSellerInput[]
    deleteMany?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput> | ExchangeProposalCreateWithoutProposerInput[] | ExchangeProposalUncheckedCreateWithoutProposerInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutProposerInput | ExchangeProposalCreateOrConnectWithoutProposerInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutProposerInput | ExchangeProposalUpsertWithWhereUniqueWithoutProposerInput[]
    createMany?: ExchangeProposalCreateManyProposerInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutProposerInput | ExchangeProposalUpdateWithWhereUniqueWithoutProposerInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutProposerInput | ExchangeProposalUpdateManyWithWhereWithoutProposerInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type OrderUncheckedUpdateManyWithoutBuyerNestedInput = {
    create?: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput> | OrderCreateWithoutBuyerInput[] | OrderUncheckedCreateWithoutBuyerInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutBuyerInput | OrderCreateOrConnectWithoutBuyerInput[]
    upsert?: OrderUpsertWithWhereUniqueWithoutBuyerInput | OrderUpsertWithWhereUniqueWithoutBuyerInput[]
    createMany?: OrderCreateManyBuyerInputEnvelope
    set?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    disconnect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    delete?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    update?: OrderUpdateWithWhereUniqueWithoutBuyerInput | OrderUpdateWithWhereUniqueWithoutBuyerInput[]
    updateMany?: OrderUpdateManyWithWhereWithoutBuyerInput | OrderUpdateManyWithWhereWithoutBuyerInput[]
    deleteMany?: OrderScalarWhereInput | OrderScalarWhereInput[]
  }

  export type PointLogUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput> | PointLogCreateWithoutUserInput[] | PointLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PointLogCreateOrConnectWithoutUserInput | PointLogCreateOrConnectWithoutUserInput[]
    upsert?: PointLogUpsertWithWhereUniqueWithoutUserInput | PointLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PointLogCreateManyUserInputEnvelope
    set?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    disconnect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    delete?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    connect?: PointLogWhereUniqueInput | PointLogWhereUniqueInput[]
    update?: PointLogUpdateWithWhereUniqueWithoutUserInput | PointLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PointLogUpdateManyWithWhereWithoutUserInput | PointLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PointLogScalarWhereInput | PointLogScalarWhereInput[]
  }

  export type NotificationUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput> | NotificationCreateWithoutUserInput[] | NotificationUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NotificationCreateOrConnectWithoutUserInput | NotificationCreateOrConnectWithoutUserInput[]
    upsert?: NotificationUpsertWithWhereUniqueWithoutUserInput | NotificationUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: NotificationCreateManyUserInputEnvelope
    set?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    disconnect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    delete?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    connect?: NotificationWhereUniqueInput | NotificationWhereUniqueInput[]
    update?: NotificationUpdateWithWhereUniqueWithoutUserInput | NotificationUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: NotificationUpdateManyWithWhereWithoutUserInput | NotificationUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: NotificationScalarWhereInput | NotificationScalarWhereInput[]
  }

  export type CardCreationLogUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput> | CardCreationLogCreateWithoutUserInput[] | CardCreationLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: CardCreationLogCreateOrConnectWithoutUserInput | CardCreationLogCreateOrConnectWithoutUserInput[]
    upsert?: CardCreationLogUpsertWithWhereUniqueWithoutUserInput | CardCreationLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: CardCreationLogCreateManyUserInputEnvelope
    set?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    disconnect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    delete?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    connect?: CardCreationLogWhereUniqueInput | CardCreationLogWhereUniqueInput[]
    update?: CardCreationLogUpdateWithWhereUniqueWithoutUserInput | CardCreationLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: CardCreationLogUpdateManyWithWhereWithoutUserInput | CardCreationLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: CardCreationLogScalarWhereInput | CardCreationLogScalarWhereInput[]
  }

  export type RefreshTokenUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput> | RefreshTokenCreateWithoutUserInput[] | RefreshTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: RefreshTokenCreateOrConnectWithoutUserInput | RefreshTokenCreateOrConnectWithoutUserInput[]
    upsert?: RefreshTokenUpsertWithWhereUniqueWithoutUserInput | RefreshTokenUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: RefreshTokenCreateManyUserInputEnvelope
    set?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    disconnect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    delete?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    connect?: RefreshTokenWhereUniqueInput | RefreshTokenWhereUniqueInput[]
    update?: RefreshTokenUpdateWithWhereUniqueWithoutUserInput | RefreshTokenUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: RefreshTokenUpdateManyWithWhereWithoutUserInput | RefreshTokenUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: RefreshTokenScalarWhereInput | RefreshTokenScalarWhereInput[]
  }

  export type HistoryUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput> | HistoryCreateWithoutUserInput[] | HistoryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HistoryCreateOrConnectWithoutUserInput | HistoryCreateOrConnectWithoutUserInput[]
    upsert?: HistoryUpsertWithWhereUniqueWithoutUserInput | HistoryUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: HistoryCreateManyUserInputEnvelope
    set?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    disconnect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    delete?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    connect?: HistoryWhereUniqueInput | HistoryWhereUniqueInput[]
    update?: HistoryUpdateWithWhereUniqueWithoutUserInput | HistoryUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: HistoryUpdateManyWithWhereWithoutUserInput | HistoryUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: HistoryScalarWhereInput | HistoryScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutUserPointInput = {
    create?: XOR<UserCreateWithoutUserPointInput, UserUncheckedCreateWithoutUserPointInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserPointInput
    connect?: UserWhereUniqueInput
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type UserUpdateOneRequiredWithoutUserPointNestedInput = {
    create?: XOR<UserCreateWithoutUserPointInput, UserUncheckedCreateWithoutUserPointInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserPointInput
    upsert?: UserUpsertWithoutUserPointInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutUserPointInput, UserUpdateWithoutUserPointInput>, UserUncheckedUpdateWithoutUserPointInput>
  }

  export type UserCreateNestedOneWithoutPhotoCardsInput = {
    create?: XOR<UserCreateWithoutPhotoCardsInput, UserUncheckedCreateWithoutPhotoCardsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPhotoCardsInput
    connect?: UserWhereUniqueInput
  }

  export type MyCardCreateNestedManyWithoutPhotoCardInput = {
    create?: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput> | MyCardCreateWithoutPhotoCardInput[] | MyCardUncheckedCreateWithoutPhotoCardInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutPhotoCardInput | MyCardCreateOrConnectWithoutPhotoCardInput[]
    createMany?: MyCardCreateManyPhotoCardInputEnvelope
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
  }

  export type MyCardUncheckedCreateNestedManyWithoutPhotoCardInput = {
    create?: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput> | MyCardCreateWithoutPhotoCardInput[] | MyCardUncheckedCreateWithoutPhotoCardInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutPhotoCardInput | MyCardCreateOrConnectWithoutPhotoCardInput[]
    createMany?: MyCardCreateManyPhotoCardInputEnvelope
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
  }

  export type EnumGenreFieldUpdateOperationsInput = {
    set?: $Enums.Genre
  }

  export type EnumCardGradeFieldUpdateOperationsInput = {
    set?: $Enums.CardGrade
  }

  export type UserUpdateOneRequiredWithoutPhotoCardsNestedInput = {
    create?: XOR<UserCreateWithoutPhotoCardsInput, UserUncheckedCreateWithoutPhotoCardsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPhotoCardsInput
    upsert?: UserUpsertWithoutPhotoCardsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPhotoCardsInput, UserUpdateWithoutPhotoCardsInput>, UserUncheckedUpdateWithoutPhotoCardsInput>
  }

  export type MyCardUpdateManyWithoutPhotoCardNestedInput = {
    create?: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput> | MyCardCreateWithoutPhotoCardInput[] | MyCardUncheckedCreateWithoutPhotoCardInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutPhotoCardInput | MyCardCreateOrConnectWithoutPhotoCardInput[]
    upsert?: MyCardUpsertWithWhereUniqueWithoutPhotoCardInput | MyCardUpsertWithWhereUniqueWithoutPhotoCardInput[]
    createMany?: MyCardCreateManyPhotoCardInputEnvelope
    set?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    disconnect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    delete?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    update?: MyCardUpdateWithWhereUniqueWithoutPhotoCardInput | MyCardUpdateWithWhereUniqueWithoutPhotoCardInput[]
    updateMany?: MyCardUpdateManyWithWhereWithoutPhotoCardInput | MyCardUpdateManyWithWhereWithoutPhotoCardInput[]
    deleteMany?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
  }

  export type MyCardUncheckedUpdateManyWithoutPhotoCardNestedInput = {
    create?: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput> | MyCardCreateWithoutPhotoCardInput[] | MyCardUncheckedCreateWithoutPhotoCardInput[]
    connectOrCreate?: MyCardCreateOrConnectWithoutPhotoCardInput | MyCardCreateOrConnectWithoutPhotoCardInput[]
    upsert?: MyCardUpsertWithWhereUniqueWithoutPhotoCardInput | MyCardUpsertWithWhereUniqueWithoutPhotoCardInput[]
    createMany?: MyCardCreateManyPhotoCardInputEnvelope
    set?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    disconnect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    delete?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    connect?: MyCardWhereUniqueInput | MyCardWhereUniqueInput[]
    update?: MyCardUpdateWithWhereUniqueWithoutPhotoCardInput | MyCardUpdateWithWhereUniqueWithoutPhotoCardInput[]
    updateMany?: MyCardUpdateManyWithWhereWithoutPhotoCardInput | MyCardUpdateManyWithWhereWithoutPhotoCardInput[]
    deleteMany?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutMyCardsInput = {
    create?: XOR<UserCreateWithoutMyCardsInput, UserUncheckedCreateWithoutMyCardsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMyCardsInput
    connect?: UserWhereUniqueInput
  }

  export type PhotoCardCreateNestedOneWithoutMyCardsInput = {
    create?: XOR<PhotoCardCreateWithoutMyCardsInput, PhotoCardUncheckedCreateWithoutMyCardsInput>
    connectOrCreate?: PhotoCardCreateOrConnectWithoutMyCardsInput
    connect?: PhotoCardWhereUniqueInput
  }

  export type MarketItemCreateNestedManyWithoutMyCardInput = {
    create?: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput> | MarketItemCreateWithoutMyCardInput[] | MarketItemUncheckedCreateWithoutMyCardInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutMyCardInput | MarketItemCreateOrConnectWithoutMyCardInput[]
    createMany?: MarketItemCreateManyMyCardInputEnvelope
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
  }

  export type ExchangeProposalCreateNestedManyWithoutOfferedCardInput = {
    create?: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput> | ExchangeProposalCreateWithoutOfferedCardInput[] | ExchangeProposalUncheckedCreateWithoutOfferedCardInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutOfferedCardInput | ExchangeProposalCreateOrConnectWithoutOfferedCardInput[]
    createMany?: ExchangeProposalCreateManyOfferedCardInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type MarketItemUncheckedCreateNestedManyWithoutMyCardInput = {
    create?: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput> | MarketItemCreateWithoutMyCardInput[] | MarketItemUncheckedCreateWithoutMyCardInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutMyCardInput | MarketItemCreateOrConnectWithoutMyCardInput[]
    createMany?: MarketItemCreateManyMyCardInputEnvelope
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
  }

  export type ExchangeProposalUncheckedCreateNestedManyWithoutOfferedCardInput = {
    create?: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput> | ExchangeProposalCreateWithoutOfferedCardInput[] | ExchangeProposalUncheckedCreateWithoutOfferedCardInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutOfferedCardInput | ExchangeProposalCreateOrConnectWithoutOfferedCardInput[]
    createMany?: ExchangeProposalCreateManyOfferedCardInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutMyCardsNestedInput = {
    create?: XOR<UserCreateWithoutMyCardsInput, UserUncheckedCreateWithoutMyCardsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMyCardsInput
    upsert?: UserUpsertWithoutMyCardsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutMyCardsInput, UserUpdateWithoutMyCardsInput>, UserUncheckedUpdateWithoutMyCardsInput>
  }

  export type PhotoCardUpdateOneRequiredWithoutMyCardsNestedInput = {
    create?: XOR<PhotoCardCreateWithoutMyCardsInput, PhotoCardUncheckedCreateWithoutMyCardsInput>
    connectOrCreate?: PhotoCardCreateOrConnectWithoutMyCardsInput
    upsert?: PhotoCardUpsertWithoutMyCardsInput
    connect?: PhotoCardWhereUniqueInput
    update?: XOR<XOR<PhotoCardUpdateToOneWithWhereWithoutMyCardsInput, PhotoCardUpdateWithoutMyCardsInput>, PhotoCardUncheckedUpdateWithoutMyCardsInput>
  }

  export type MarketItemUpdateManyWithoutMyCardNestedInput = {
    create?: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput> | MarketItemCreateWithoutMyCardInput[] | MarketItemUncheckedCreateWithoutMyCardInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutMyCardInput | MarketItemCreateOrConnectWithoutMyCardInput[]
    upsert?: MarketItemUpsertWithWhereUniqueWithoutMyCardInput | MarketItemUpsertWithWhereUniqueWithoutMyCardInput[]
    createMany?: MarketItemCreateManyMyCardInputEnvelope
    set?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    disconnect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    delete?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    update?: MarketItemUpdateWithWhereUniqueWithoutMyCardInput | MarketItemUpdateWithWhereUniqueWithoutMyCardInput[]
    updateMany?: MarketItemUpdateManyWithWhereWithoutMyCardInput | MarketItemUpdateManyWithWhereWithoutMyCardInput[]
    deleteMany?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
  }

  export type ExchangeProposalUpdateManyWithoutOfferedCardNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput> | ExchangeProposalCreateWithoutOfferedCardInput[] | ExchangeProposalUncheckedCreateWithoutOfferedCardInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutOfferedCardInput | ExchangeProposalCreateOrConnectWithoutOfferedCardInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutOfferedCardInput | ExchangeProposalUpsertWithWhereUniqueWithoutOfferedCardInput[]
    createMany?: ExchangeProposalCreateManyOfferedCardInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutOfferedCardInput | ExchangeProposalUpdateWithWhereUniqueWithoutOfferedCardInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutOfferedCardInput | ExchangeProposalUpdateManyWithWhereWithoutOfferedCardInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type MarketItemUncheckedUpdateManyWithoutMyCardNestedInput = {
    create?: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput> | MarketItemCreateWithoutMyCardInput[] | MarketItemUncheckedCreateWithoutMyCardInput[]
    connectOrCreate?: MarketItemCreateOrConnectWithoutMyCardInput | MarketItemCreateOrConnectWithoutMyCardInput[]
    upsert?: MarketItemUpsertWithWhereUniqueWithoutMyCardInput | MarketItemUpsertWithWhereUniqueWithoutMyCardInput[]
    createMany?: MarketItemCreateManyMyCardInputEnvelope
    set?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    disconnect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    delete?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    connect?: MarketItemWhereUniqueInput | MarketItemWhereUniqueInput[]
    update?: MarketItemUpdateWithWhereUniqueWithoutMyCardInput | MarketItemUpdateWithWhereUniqueWithoutMyCardInput[]
    updateMany?: MarketItemUpdateManyWithWhereWithoutMyCardInput | MarketItemUpdateManyWithWhereWithoutMyCardInput[]
    deleteMany?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutOfferedCardNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput> | ExchangeProposalCreateWithoutOfferedCardInput[] | ExchangeProposalUncheckedCreateWithoutOfferedCardInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutOfferedCardInput | ExchangeProposalCreateOrConnectWithoutOfferedCardInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutOfferedCardInput | ExchangeProposalUpsertWithWhereUniqueWithoutOfferedCardInput[]
    createMany?: ExchangeProposalCreateManyOfferedCardInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutOfferedCardInput | ExchangeProposalUpdateWithWhereUniqueWithoutOfferedCardInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutOfferedCardInput | ExchangeProposalUpdateManyWithWhereWithoutOfferedCardInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutMarketItemsInput = {
    create?: XOR<UserCreateWithoutMarketItemsInput, UserUncheckedCreateWithoutMarketItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMarketItemsInput
    connect?: UserWhereUniqueInput
  }

  export type MyCardCreateNestedOneWithoutMarketItemsInput = {
    create?: XOR<MyCardCreateWithoutMarketItemsInput, MyCardUncheckedCreateWithoutMarketItemsInput>
    connectOrCreate?: MyCardCreateOrConnectWithoutMarketItemsInput
    connect?: MyCardWhereUniqueInput
  }

  export type ExchangeProposalCreateNestedManyWithoutMarketItemInput = {
    create?: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput> | ExchangeProposalCreateWithoutMarketItemInput[] | ExchangeProposalUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutMarketItemInput | ExchangeProposalCreateOrConnectWithoutMarketItemInput[]
    createMany?: ExchangeProposalCreateManyMarketItemInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type OrderCreateNestedManyWithoutMarketItemInput = {
    create?: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput> | OrderCreateWithoutMarketItemInput[] | OrderUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutMarketItemInput | OrderCreateOrConnectWithoutMarketItemInput[]
    createMany?: OrderCreateManyMarketItemInputEnvelope
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
  }

  export type ExchangeProposalUncheckedCreateNestedManyWithoutMarketItemInput = {
    create?: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput> | ExchangeProposalCreateWithoutMarketItemInput[] | ExchangeProposalUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutMarketItemInput | ExchangeProposalCreateOrConnectWithoutMarketItemInput[]
    createMany?: ExchangeProposalCreateManyMarketItemInputEnvelope
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
  }

  export type OrderUncheckedCreateNestedManyWithoutMarketItemInput = {
    create?: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput> | OrderCreateWithoutMarketItemInput[] | OrderUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutMarketItemInput | OrderCreateOrConnectWithoutMarketItemInput[]
    createMany?: OrderCreateManyMarketItemInputEnvelope
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
  }

  export type NullableEnumCardGradeFieldUpdateOperationsInput = {
    set?: $Enums.CardGrade | null
  }

  export type NullableEnumGenreFieldUpdateOperationsInput = {
    set?: $Enums.Genre | null
  }

  export type EnumMarketStatusFieldUpdateOperationsInput = {
    set?: $Enums.MarketStatus
  }

  export type UserUpdateOneRequiredWithoutMarketItemsNestedInput = {
    create?: XOR<UserCreateWithoutMarketItemsInput, UserUncheckedCreateWithoutMarketItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMarketItemsInput
    upsert?: UserUpsertWithoutMarketItemsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutMarketItemsInput, UserUpdateWithoutMarketItemsInput>, UserUncheckedUpdateWithoutMarketItemsInput>
  }

  export type MyCardUpdateOneRequiredWithoutMarketItemsNestedInput = {
    create?: XOR<MyCardCreateWithoutMarketItemsInput, MyCardUncheckedCreateWithoutMarketItemsInput>
    connectOrCreate?: MyCardCreateOrConnectWithoutMarketItemsInput
    upsert?: MyCardUpsertWithoutMarketItemsInput
    connect?: MyCardWhereUniqueInput
    update?: XOR<XOR<MyCardUpdateToOneWithWhereWithoutMarketItemsInput, MyCardUpdateWithoutMarketItemsInput>, MyCardUncheckedUpdateWithoutMarketItemsInput>
  }

  export type ExchangeProposalUpdateManyWithoutMarketItemNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput> | ExchangeProposalCreateWithoutMarketItemInput[] | ExchangeProposalUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutMarketItemInput | ExchangeProposalCreateOrConnectWithoutMarketItemInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutMarketItemInput | ExchangeProposalUpsertWithWhereUniqueWithoutMarketItemInput[]
    createMany?: ExchangeProposalCreateManyMarketItemInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutMarketItemInput | ExchangeProposalUpdateWithWhereUniqueWithoutMarketItemInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutMarketItemInput | ExchangeProposalUpdateManyWithWhereWithoutMarketItemInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type OrderUpdateManyWithoutMarketItemNestedInput = {
    create?: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput> | OrderCreateWithoutMarketItemInput[] | OrderUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutMarketItemInput | OrderCreateOrConnectWithoutMarketItemInput[]
    upsert?: OrderUpsertWithWhereUniqueWithoutMarketItemInput | OrderUpsertWithWhereUniqueWithoutMarketItemInput[]
    createMany?: OrderCreateManyMarketItemInputEnvelope
    set?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    disconnect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    delete?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    update?: OrderUpdateWithWhereUniqueWithoutMarketItemInput | OrderUpdateWithWhereUniqueWithoutMarketItemInput[]
    updateMany?: OrderUpdateManyWithWhereWithoutMarketItemInput | OrderUpdateManyWithWhereWithoutMarketItemInput[]
    deleteMany?: OrderScalarWhereInput | OrderScalarWhereInput[]
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutMarketItemNestedInput = {
    create?: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput> | ExchangeProposalCreateWithoutMarketItemInput[] | ExchangeProposalUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: ExchangeProposalCreateOrConnectWithoutMarketItemInput | ExchangeProposalCreateOrConnectWithoutMarketItemInput[]
    upsert?: ExchangeProposalUpsertWithWhereUniqueWithoutMarketItemInput | ExchangeProposalUpsertWithWhereUniqueWithoutMarketItemInput[]
    createMany?: ExchangeProposalCreateManyMarketItemInputEnvelope
    set?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    disconnect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    delete?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    connect?: ExchangeProposalWhereUniqueInput | ExchangeProposalWhereUniqueInput[]
    update?: ExchangeProposalUpdateWithWhereUniqueWithoutMarketItemInput | ExchangeProposalUpdateWithWhereUniqueWithoutMarketItemInput[]
    updateMany?: ExchangeProposalUpdateManyWithWhereWithoutMarketItemInput | ExchangeProposalUpdateManyWithWhereWithoutMarketItemInput[]
    deleteMany?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
  }

  export type OrderUncheckedUpdateManyWithoutMarketItemNestedInput = {
    create?: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput> | OrderCreateWithoutMarketItemInput[] | OrderUncheckedCreateWithoutMarketItemInput[]
    connectOrCreate?: OrderCreateOrConnectWithoutMarketItemInput | OrderCreateOrConnectWithoutMarketItemInput[]
    upsert?: OrderUpsertWithWhereUniqueWithoutMarketItemInput | OrderUpsertWithWhereUniqueWithoutMarketItemInput[]
    createMany?: OrderCreateManyMarketItemInputEnvelope
    set?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    disconnect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    delete?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    connect?: OrderWhereUniqueInput | OrderWhereUniqueInput[]
    update?: OrderUpdateWithWhereUniqueWithoutMarketItemInput | OrderUpdateWithWhereUniqueWithoutMarketItemInput[]
    updateMany?: OrderUpdateManyWithWhereWithoutMarketItemInput | OrderUpdateManyWithWhereWithoutMarketItemInput[]
    deleteMany?: OrderScalarWhereInput | OrderScalarWhereInput[]
  }

  export type MarketItemCreateNestedOneWithoutExchangeProposalsInput = {
    create?: XOR<MarketItemCreateWithoutExchangeProposalsInput, MarketItemUncheckedCreateWithoutExchangeProposalsInput>
    connectOrCreate?: MarketItemCreateOrConnectWithoutExchangeProposalsInput
    connect?: MarketItemWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutExchangeProposalsInput = {
    create?: XOR<UserCreateWithoutExchangeProposalsInput, UserUncheckedCreateWithoutExchangeProposalsInput>
    connectOrCreate?: UserCreateOrConnectWithoutExchangeProposalsInput
    connect?: UserWhereUniqueInput
  }

  export type MyCardCreateNestedOneWithoutOfferedExchangesInput = {
    create?: XOR<MyCardCreateWithoutOfferedExchangesInput, MyCardUncheckedCreateWithoutOfferedExchangesInput>
    connectOrCreate?: MyCardCreateOrConnectWithoutOfferedExchangesInput
    connect?: MyCardWhereUniqueInput
  }

  export type EnumExchangeStatusFieldUpdateOperationsInput = {
    set?: $Enums.ExchangeStatus
  }

  export type MarketItemUpdateOneRequiredWithoutExchangeProposalsNestedInput = {
    create?: XOR<MarketItemCreateWithoutExchangeProposalsInput, MarketItemUncheckedCreateWithoutExchangeProposalsInput>
    connectOrCreate?: MarketItemCreateOrConnectWithoutExchangeProposalsInput
    upsert?: MarketItemUpsertWithoutExchangeProposalsInput
    connect?: MarketItemWhereUniqueInput
    update?: XOR<XOR<MarketItemUpdateToOneWithWhereWithoutExchangeProposalsInput, MarketItemUpdateWithoutExchangeProposalsInput>, MarketItemUncheckedUpdateWithoutExchangeProposalsInput>
  }

  export type UserUpdateOneRequiredWithoutExchangeProposalsNestedInput = {
    create?: XOR<UserCreateWithoutExchangeProposalsInput, UserUncheckedCreateWithoutExchangeProposalsInput>
    connectOrCreate?: UserCreateOrConnectWithoutExchangeProposalsInput
    upsert?: UserUpsertWithoutExchangeProposalsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutExchangeProposalsInput, UserUpdateWithoutExchangeProposalsInput>, UserUncheckedUpdateWithoutExchangeProposalsInput>
  }

  export type MyCardUpdateOneRequiredWithoutOfferedExchangesNestedInput = {
    create?: XOR<MyCardCreateWithoutOfferedExchangesInput, MyCardUncheckedCreateWithoutOfferedExchangesInput>
    connectOrCreate?: MyCardCreateOrConnectWithoutOfferedExchangesInput
    upsert?: MyCardUpsertWithoutOfferedExchangesInput
    connect?: MyCardWhereUniqueInput
    update?: XOR<XOR<MyCardUpdateToOneWithWhereWithoutOfferedExchangesInput, MyCardUpdateWithoutOfferedExchangesInput>, MyCardUncheckedUpdateWithoutOfferedExchangesInput>
  }

  export type UserCreateNestedOneWithoutOrdersInput = {
    create?: XOR<UserCreateWithoutOrdersInput, UserUncheckedCreateWithoutOrdersInput>
    connectOrCreate?: UserCreateOrConnectWithoutOrdersInput
    connect?: UserWhereUniqueInput
  }

  export type MarketItemCreateNestedOneWithoutOrdersInput = {
    create?: XOR<MarketItemCreateWithoutOrdersInput, MarketItemUncheckedCreateWithoutOrdersInput>
    connectOrCreate?: MarketItemCreateOrConnectWithoutOrdersInput
    connect?: MarketItemWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutOrdersNestedInput = {
    create?: XOR<UserCreateWithoutOrdersInput, UserUncheckedCreateWithoutOrdersInput>
    connectOrCreate?: UserCreateOrConnectWithoutOrdersInput
    upsert?: UserUpsertWithoutOrdersInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutOrdersInput, UserUpdateWithoutOrdersInput>, UserUncheckedUpdateWithoutOrdersInput>
  }

  export type MarketItemUpdateOneRequiredWithoutOrdersNestedInput = {
    create?: XOR<MarketItemCreateWithoutOrdersInput, MarketItemUncheckedCreateWithoutOrdersInput>
    connectOrCreate?: MarketItemCreateOrConnectWithoutOrdersInput
    upsert?: MarketItemUpsertWithoutOrdersInput
    connect?: MarketItemWhereUniqueInput
    update?: XOR<XOR<MarketItemUpdateToOneWithWhereWithoutOrdersInput, MarketItemUpdateWithoutOrdersInput>, MarketItemUncheckedUpdateWithoutOrdersInput>
  }

  export type UserCreateNestedOneWithoutPointLogsInput = {
    create?: XOR<UserCreateWithoutPointLogsInput, UserUncheckedCreateWithoutPointLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPointLogsInput
    connect?: UserWhereUniqueInput
  }

  export type EnumPointLogTypeFieldUpdateOperationsInput = {
    set?: $Enums.PointLogType
  }

  export type UserUpdateOneRequiredWithoutPointLogsNestedInput = {
    create?: XOR<UserCreateWithoutPointLogsInput, UserUncheckedCreateWithoutPointLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPointLogsInput
    upsert?: UserUpsertWithoutPointLogsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPointLogsInput, UserUpdateWithoutPointLogsInput>, UserUncheckedUpdateWithoutPointLogsInput>
  }

  export type UserCreateNestedOneWithoutNotificationsInput = {
    create?: XOR<UserCreateWithoutNotificationsInput, UserUncheckedCreateWithoutNotificationsInput>
    connectOrCreate?: UserCreateOrConnectWithoutNotificationsInput
    connect?: UserWhereUniqueInput
  }

  export type EnumNotificationTypeFieldUpdateOperationsInput = {
    set?: $Enums.NotificationType
  }

  export type EnumRouteTypeFieldUpdateOperationsInput = {
    set?: $Enums.RouteType
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type UserUpdateOneRequiredWithoutNotificationsNestedInput = {
    create?: XOR<UserCreateWithoutNotificationsInput, UserUncheckedCreateWithoutNotificationsInput>
    connectOrCreate?: UserCreateOrConnectWithoutNotificationsInput
    upsert?: UserUpsertWithoutNotificationsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutNotificationsInput, UserUpdateWithoutNotificationsInput>, UserUncheckedUpdateWithoutNotificationsInput>
  }

  export type UserCreateNestedOneWithoutCreationLogsInput = {
    create?: XOR<UserCreateWithoutCreationLogsInput, UserUncheckedCreateWithoutCreationLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreationLogsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutCreationLogsNestedInput = {
    create?: XOR<UserCreateWithoutCreationLogsInput, UserUncheckedCreateWithoutCreationLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreationLogsInput
    upsert?: UserUpsertWithoutCreationLogsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCreationLogsInput, UserUpdateWithoutCreationLogsInput>, UserUncheckedUpdateWithoutCreationLogsInput>
  }

  export type UserCreateNestedOneWithoutRefreshTokensInput = {
    create?: XOR<UserCreateWithoutRefreshTokensInput, UserUncheckedCreateWithoutRefreshTokensInput>
    connectOrCreate?: UserCreateOrConnectWithoutRefreshTokensInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutRefreshTokensNestedInput = {
    create?: XOR<UserCreateWithoutRefreshTokensInput, UserUncheckedCreateWithoutRefreshTokensInput>
    connectOrCreate?: UserCreateOrConnectWithoutRefreshTokensInput
    upsert?: UserUpsertWithoutRefreshTokensInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutRefreshTokensInput, UserUpdateWithoutRefreshTokensInput>, UserUncheckedUpdateWithoutRefreshTokensInput>
  }

  export type UserCreateNestedOneWithoutHistoriesInput = {
    create?: XOR<UserCreateWithoutHistoriesInput, UserUncheckedCreateWithoutHistoriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutHistoriesInput
    connect?: UserWhereUniqueInput
  }

  export type BigIntFieldUpdateOperationsInput = {
    set?: bigint | number
    increment?: bigint | number
    decrement?: bigint | number
    multiply?: bigint | number
    divide?: bigint | number
  }

  export type EnumOperationTypeFieldUpdateOperationsInput = {
    set?: $Enums.OperationType
  }

  export type UserUpdateOneWithoutHistoriesNestedInput = {
    create?: XOR<UserCreateWithoutHistoriesInput, UserUncheckedCreateWithoutHistoriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutHistoriesInput
    upsert?: UserUpsertWithoutHistoriesInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutHistoriesInput, UserUpdateWithoutHistoriesInput>, UserUncheckedUpdateWithoutHistoriesInput>
  }

  export type NestedUuidFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidFilter<$PrismaModel> | string
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumProviderFilter<$PrismaModel = never> = {
    equals?: $Enums.Provider | EnumProviderFieldRefInput<$PrismaModel>
    in?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    notIn?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    not?: NestedEnumProviderFilter<$PrismaModel> | $Enums.Provider
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedUuidWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumProviderWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Provider | EnumProviderFieldRefInput<$PrismaModel>
    in?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    notIn?: $Enums.Provider[] | ListEnumProviderFieldRefInput<$PrismaModel>
    not?: NestedEnumProviderWithAggregatesFilter<$PrismaModel> | $Enums.Provider
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumProviderFilter<$PrismaModel>
    _max?: NestedEnumProviderFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedEnumGenreFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel>
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    not?: NestedEnumGenreFilter<$PrismaModel> | $Enums.Genre
  }

  export type NestedEnumCardGradeFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel>
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    not?: NestedEnumCardGradeFilter<$PrismaModel> | $Enums.CardGrade
  }

  export type NestedEnumGenreWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel>
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel>
    not?: NestedEnumGenreWithAggregatesFilter<$PrismaModel> | $Enums.Genre
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumGenreFilter<$PrismaModel>
    _max?: NestedEnumGenreFilter<$PrismaModel>
  }

  export type NestedEnumCardGradeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel>
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel>
    not?: NestedEnumCardGradeWithAggregatesFilter<$PrismaModel> | $Enums.CardGrade
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumCardGradeFilter<$PrismaModel>
    _max?: NestedEnumCardGradeFilter<$PrismaModel>
  }

  export type NestedEnumCardGradeNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel> | null
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    not?: NestedEnumCardGradeNullableFilter<$PrismaModel> | $Enums.CardGrade | null
  }

  export type NestedEnumGenreNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel> | null
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    not?: NestedEnumGenreNullableFilter<$PrismaModel> | $Enums.Genre | null
  }

  export type NestedEnumMarketStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketStatus | EnumMarketStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketStatusFilter<$PrismaModel> | $Enums.MarketStatus
  }

  export type NestedEnumCardGradeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CardGrade | EnumCardGradeFieldRefInput<$PrismaModel> | null
    in?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.CardGrade[] | ListEnumCardGradeFieldRefInput<$PrismaModel> | null
    not?: NestedEnumCardGradeNullableWithAggregatesFilter<$PrismaModel> | $Enums.CardGrade | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumCardGradeNullableFilter<$PrismaModel>
    _max?: NestedEnumCardGradeNullableFilter<$PrismaModel>
  }

  export type NestedEnumGenreNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Genre | EnumGenreFieldRefInput<$PrismaModel> | null
    in?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.Genre[] | ListEnumGenreFieldRefInput<$PrismaModel> | null
    not?: NestedEnumGenreNullableWithAggregatesFilter<$PrismaModel> | $Enums.Genre | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumGenreNullableFilter<$PrismaModel>
    _max?: NestedEnumGenreNullableFilter<$PrismaModel>
  }

  export type NestedEnumMarketStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketStatus | EnumMarketStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketStatus[] | ListEnumMarketStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketStatusWithAggregatesFilter<$PrismaModel> | $Enums.MarketStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMarketStatusFilter<$PrismaModel>
    _max?: NestedEnumMarketStatusFilter<$PrismaModel>
  }

  export type NestedEnumExchangeStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ExchangeStatus | EnumExchangeStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumExchangeStatusFilter<$PrismaModel> | $Enums.ExchangeStatus
  }

  export type NestedEnumExchangeStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ExchangeStatus | EnumExchangeStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.ExchangeStatus[] | ListEnumExchangeStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumExchangeStatusWithAggregatesFilter<$PrismaModel> | $Enums.ExchangeStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumExchangeStatusFilter<$PrismaModel>
    _max?: NestedEnumExchangeStatusFilter<$PrismaModel>
  }

  export type NestedEnumPointLogTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.PointLogType | EnumPointLogTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumPointLogTypeFilter<$PrismaModel> | $Enums.PointLogType
  }

  export type NestedEnumPointLogTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PointLogType | EnumPointLogTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.PointLogType[] | ListEnumPointLogTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumPointLogTypeWithAggregatesFilter<$PrismaModel> | $Enums.PointLogType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPointLogTypeFilter<$PrismaModel>
    _max?: NestedEnumPointLogTypeFilter<$PrismaModel>
  }

  export type NestedEnumNotificationTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.NotificationType | EnumNotificationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumNotificationTypeFilter<$PrismaModel> | $Enums.NotificationType
  }

  export type NestedEnumRouteTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.RouteType | EnumRouteTypeFieldRefInput<$PrismaModel>
    in?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumRouteTypeFilter<$PrismaModel> | $Enums.RouteType
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedEnumNotificationTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.NotificationType | EnumNotificationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.NotificationType[] | ListEnumNotificationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumNotificationTypeWithAggregatesFilter<$PrismaModel> | $Enums.NotificationType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumNotificationTypeFilter<$PrismaModel>
    _max?: NestedEnumNotificationTypeFilter<$PrismaModel>
  }

  export type NestedEnumRouteTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.RouteType | EnumRouteTypeFieldRefInput<$PrismaModel>
    in?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.RouteType[] | ListEnumRouteTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumRouteTypeWithAggregatesFilter<$PrismaModel> | $Enums.RouteType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRouteTypeFilter<$PrismaModel>
    _max?: NestedEnumRouteTypeFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedBigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }

  export type NestedEnumOperationTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.OperationType | EnumOperationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumOperationTypeFilter<$PrismaModel> | $Enums.OperationType
  }

  export type NestedUuidNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidNullableFilter<$PrismaModel> | string | null
  }

  export type NestedBigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }

  export type NestedEnumOperationTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.OperationType | EnumOperationTypeFieldRefInput<$PrismaModel>
    in?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    notIn?: $Enums.OperationType[] | ListEnumOperationTypeFieldRefInput<$PrismaModel>
    not?: NestedEnumOperationTypeWithAggregatesFilter<$PrismaModel> | $Enums.OperationType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumOperationTypeFilter<$PrismaModel>
    _max?: NestedEnumOperationTypeFilter<$PrismaModel>
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedUuidNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type UserPointCreateWithoutUserInput = {
    point?: number
    lastSpinAt?: Date | string | null
    updatedAt?: Date | string
  }

  export type UserPointUncheckedCreateWithoutUserInput = {
    id?: number
    point?: number
    lastSpinAt?: Date | string | null
    updatedAt?: Date | string
  }

  export type UserPointCreateOrConnectWithoutUserInput = {
    where: UserPointWhereUniqueInput
    create: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
  }

  export type PhotoCardCreateWithoutCreatorInput = {
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
    myCards?: MyCardCreateNestedManyWithoutPhotoCardInput
  }

  export type PhotoCardUncheckedCreateWithoutCreatorInput = {
    id?: number
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
    myCards?: MyCardUncheckedCreateNestedManyWithoutPhotoCardInput
  }

  export type PhotoCardCreateOrConnectWithoutCreatorInput = {
    where: PhotoCardWhereUniqueInput
    create: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput>
  }

  export type PhotoCardCreateManyCreatorInputEnvelope = {
    data: PhotoCardCreateManyCreatorInput | PhotoCardCreateManyCreatorInput[]
    skipDuplicates?: boolean
  }

  export type MyCardCreateWithoutOwnerInput = {
    quantity?: number
    acquiredAt?: Date | string
    photoCard: PhotoCardCreateNestedOneWithoutMyCardsInput
    marketItems?: MarketItemCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardUncheckedCreateWithoutOwnerInput = {
    id?: number
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalUncheckedCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardCreateOrConnectWithoutOwnerInput = {
    where: MyCardWhereUniqueInput
    create: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput>
  }

  export type MyCardCreateManyOwnerInputEnvelope = {
    data: MyCardCreateManyOwnerInput | MyCardCreateManyOwnerInput[]
    skipDuplicates?: boolean
  }

  export type MarketItemCreateWithoutSellerInput = {
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    myCard: MyCardCreateNestedOneWithoutMarketItemsInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutMarketItemInput
    orders?: OrderCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUncheckedCreateWithoutSellerInput = {
    id?: number
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutMarketItemInput
    orders?: OrderUncheckedCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemCreateOrConnectWithoutSellerInput = {
    where: MarketItemWhereUniqueInput
    create: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput>
  }

  export type MarketItemCreateManySellerInputEnvelope = {
    data: MarketItemCreateManySellerInput | MarketItemCreateManySellerInput[]
    skipDuplicates?: boolean
  }

  export type ExchangeProposalCreateWithoutProposerInput = {
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
    marketItem: MarketItemCreateNestedOneWithoutExchangeProposalsInput
    offeredCard: MyCardCreateNestedOneWithoutOfferedExchangesInput
  }

  export type ExchangeProposalUncheckedCreateWithoutProposerInput = {
    id?: number
    marketItemId: number
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalCreateOrConnectWithoutProposerInput = {
    where: ExchangeProposalWhereUniqueInput
    create: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput>
  }

  export type ExchangeProposalCreateManyProposerInputEnvelope = {
    data: ExchangeProposalCreateManyProposerInput | ExchangeProposalCreateManyProposerInput[]
    skipDuplicates?: boolean
  }

  export type OrderCreateWithoutBuyerInput = {
    quantity: number
    totalPrice: number
    createdAt?: Date | string
    marketItem: MarketItemCreateNestedOneWithoutOrdersInput
  }

  export type OrderUncheckedCreateWithoutBuyerInput = {
    id?: number
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type OrderCreateOrConnectWithoutBuyerInput = {
    where: OrderWhereUniqueInput
    create: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput>
  }

  export type OrderCreateManyBuyerInputEnvelope = {
    data: OrderCreateManyBuyerInput | OrderCreateManyBuyerInput[]
    skipDuplicates?: boolean
  }

  export type PointLogCreateWithoutUserInput = {
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
  }

  export type PointLogUncheckedCreateWithoutUserInput = {
    id?: number
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
  }

  export type PointLogCreateOrConnectWithoutUserInput = {
    where: PointLogWhereUniqueInput
    create: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput>
  }

  export type PointLogCreateManyUserInputEnvelope = {
    data: PointLogCreateManyUserInput | PointLogCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type NotificationCreateWithoutUserInput = {
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
  }

  export type NotificationUncheckedCreateWithoutUserInput = {
    id?: number
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
  }

  export type NotificationCreateOrConnectWithoutUserInput = {
    where: NotificationWhereUniqueInput
    create: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput>
  }

  export type NotificationCreateManyUserInputEnvelope = {
    data: NotificationCreateManyUserInput | NotificationCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type CardCreationLogCreateWithoutUserInput = {
    year: number
    month: number
    count?: number
  }

  export type CardCreationLogUncheckedCreateWithoutUserInput = {
    id?: number
    year: number
    month: number
    count?: number
  }

  export type CardCreationLogCreateOrConnectWithoutUserInput = {
    where: CardCreationLogWhereUniqueInput
    create: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput>
  }

  export type CardCreationLogCreateManyUserInputEnvelope = {
    data: CardCreationLogCreateManyUserInput | CardCreationLogCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type RefreshTokenCreateWithoutUserInput = {
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
  }

  export type RefreshTokenUncheckedCreateWithoutUserInput = {
    id?: number
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
  }

  export type RefreshTokenCreateOrConnectWithoutUserInput = {
    where: RefreshTokenWhereUniqueInput
    create: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput>
  }

  export type RefreshTokenCreateManyUserInputEnvelope = {
    data: RefreshTokenCreateManyUserInput | RefreshTokenCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type HistoryCreateWithoutUserInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
  }

  export type HistoryUncheckedCreateWithoutUserInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
  }

  export type HistoryCreateOrConnectWithoutUserInput = {
    where: HistoryWhereUniqueInput
    create: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput>
  }

  export type HistoryCreateManyUserInputEnvelope = {
    data: HistoryCreateManyUserInput | HistoryCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type UserPointUpsertWithoutUserInput = {
    update: XOR<UserPointUpdateWithoutUserInput, UserPointUncheckedUpdateWithoutUserInput>
    create: XOR<UserPointCreateWithoutUserInput, UserPointUncheckedCreateWithoutUserInput>
    where?: UserPointWhereInput
  }

  export type UserPointUpdateToOneWithWhereWithoutUserInput = {
    where?: UserPointWhereInput
    data: XOR<UserPointUpdateWithoutUserInput, UserPointUncheckedUpdateWithoutUserInput>
  }

  export type UserPointUpdateWithoutUserInput = {
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserPointUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    point?: IntFieldUpdateOperationsInput | number
    lastSpinAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCardUpsertWithWhereUniqueWithoutCreatorInput = {
    where: PhotoCardWhereUniqueInput
    update: XOR<PhotoCardUpdateWithoutCreatorInput, PhotoCardUncheckedUpdateWithoutCreatorInput>
    create: XOR<PhotoCardCreateWithoutCreatorInput, PhotoCardUncheckedCreateWithoutCreatorInput>
  }

  export type PhotoCardUpdateWithWhereUniqueWithoutCreatorInput = {
    where: PhotoCardWhereUniqueInput
    data: XOR<PhotoCardUpdateWithoutCreatorInput, PhotoCardUncheckedUpdateWithoutCreatorInput>
  }

  export type PhotoCardUpdateManyWithWhereWithoutCreatorInput = {
    where: PhotoCardScalarWhereInput
    data: XOR<PhotoCardUpdateManyMutationInput, PhotoCardUncheckedUpdateManyWithoutCreatorInput>
  }

  export type PhotoCardScalarWhereInput = {
    AND?: PhotoCardScalarWhereInput | PhotoCardScalarWhereInput[]
    OR?: PhotoCardScalarWhereInput[]
    NOT?: PhotoCardScalarWhereInput | PhotoCardScalarWhereInput[]
    id?: IntFilter<"PhotoCard"> | number
    creatorId?: UuidFilter<"PhotoCard"> | string
    name?: StringFilter<"PhotoCard"> | string
    description?: StringNullableFilter<"PhotoCard"> | string | null
    genre?: EnumGenreFilter<"PhotoCard"> | $Enums.Genre
    grade?: EnumCardGradeFilter<"PhotoCard"> | $Enums.CardGrade
    price?: IntFilter<"PhotoCard"> | number
    totalQuantity?: IntFilter<"PhotoCard"> | number
    imageUrl?: StringFilter<"PhotoCard"> | string
    createdAt?: DateTimeFilter<"PhotoCard"> | Date | string
  }

  export type MyCardUpsertWithWhereUniqueWithoutOwnerInput = {
    where: MyCardWhereUniqueInput
    update: XOR<MyCardUpdateWithoutOwnerInput, MyCardUncheckedUpdateWithoutOwnerInput>
    create: XOR<MyCardCreateWithoutOwnerInput, MyCardUncheckedCreateWithoutOwnerInput>
  }

  export type MyCardUpdateWithWhereUniqueWithoutOwnerInput = {
    where: MyCardWhereUniqueInput
    data: XOR<MyCardUpdateWithoutOwnerInput, MyCardUncheckedUpdateWithoutOwnerInput>
  }

  export type MyCardUpdateManyWithWhereWithoutOwnerInput = {
    where: MyCardScalarWhereInput
    data: XOR<MyCardUpdateManyMutationInput, MyCardUncheckedUpdateManyWithoutOwnerInput>
  }

  export type MyCardScalarWhereInput = {
    AND?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
    OR?: MyCardScalarWhereInput[]
    NOT?: MyCardScalarWhereInput | MyCardScalarWhereInput[]
    id?: IntFilter<"MyCard"> | number
    ownerId?: UuidFilter<"MyCard"> | string
    photoCardId?: IntFilter<"MyCard"> | number
    quantity?: IntFilter<"MyCard"> | number
    acquiredAt?: DateTimeFilter<"MyCard"> | Date | string
  }

  export type MarketItemUpsertWithWhereUniqueWithoutSellerInput = {
    where: MarketItemWhereUniqueInput
    update: XOR<MarketItemUpdateWithoutSellerInput, MarketItemUncheckedUpdateWithoutSellerInput>
    create: XOR<MarketItemCreateWithoutSellerInput, MarketItemUncheckedCreateWithoutSellerInput>
  }

  export type MarketItemUpdateWithWhereUniqueWithoutSellerInput = {
    where: MarketItemWhereUniqueInput
    data: XOR<MarketItemUpdateWithoutSellerInput, MarketItemUncheckedUpdateWithoutSellerInput>
  }

  export type MarketItemUpdateManyWithWhereWithoutSellerInput = {
    where: MarketItemScalarWhereInput
    data: XOR<MarketItemUpdateManyMutationInput, MarketItemUncheckedUpdateManyWithoutSellerInput>
  }

  export type MarketItemScalarWhereInput = {
    AND?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
    OR?: MarketItemScalarWhereInput[]
    NOT?: MarketItemScalarWhereInput | MarketItemScalarWhereInput[]
    id?: IntFilter<"MarketItem"> | number
    sellerId?: UuidFilter<"MarketItem"> | string
    myCardId?: IntFilter<"MarketItem"> | number
    grade?: EnumCardGradeFilter<"MarketItem"> | $Enums.CardGrade
    genre?: EnumGenreFilter<"MarketItem"> | $Enums.Genre
    quantity?: IntFilter<"MarketItem"> | number
    soldQuantity?: IntFilter<"MarketItem"> | number
    pricePerCard?: IntFilter<"MarketItem"> | number
    wantedGrade?: EnumCardGradeNullableFilter<"MarketItem"> | $Enums.CardGrade | null
    wantedGenre?: EnumGenreNullableFilter<"MarketItem"> | $Enums.Genre | null
    wantedDescription?: StringNullableFilter<"MarketItem"> | string | null
    status?: EnumMarketStatusFilter<"MarketItem"> | $Enums.MarketStatus
    createdAt?: DateTimeFilter<"MarketItem"> | Date | string
  }

  export type ExchangeProposalUpsertWithWhereUniqueWithoutProposerInput = {
    where: ExchangeProposalWhereUniqueInput
    update: XOR<ExchangeProposalUpdateWithoutProposerInput, ExchangeProposalUncheckedUpdateWithoutProposerInput>
    create: XOR<ExchangeProposalCreateWithoutProposerInput, ExchangeProposalUncheckedCreateWithoutProposerInput>
  }

  export type ExchangeProposalUpdateWithWhereUniqueWithoutProposerInput = {
    where: ExchangeProposalWhereUniqueInput
    data: XOR<ExchangeProposalUpdateWithoutProposerInput, ExchangeProposalUncheckedUpdateWithoutProposerInput>
  }

  export type ExchangeProposalUpdateManyWithWhereWithoutProposerInput = {
    where: ExchangeProposalScalarWhereInput
    data: XOR<ExchangeProposalUpdateManyMutationInput, ExchangeProposalUncheckedUpdateManyWithoutProposerInput>
  }

  export type ExchangeProposalScalarWhereInput = {
    AND?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
    OR?: ExchangeProposalScalarWhereInput[]
    NOT?: ExchangeProposalScalarWhereInput | ExchangeProposalScalarWhereInput[]
    id?: IntFilter<"ExchangeProposal"> | number
    marketItemId?: IntFilter<"ExchangeProposal"> | number
    proposerId?: UuidFilter<"ExchangeProposal"> | string
    offeredCardId?: IntFilter<"ExchangeProposal"> | number
    status?: EnumExchangeStatusFilter<"ExchangeProposal"> | $Enums.ExchangeStatus
    createdAt?: DateTimeFilter<"ExchangeProposal"> | Date | string
  }

  export type OrderUpsertWithWhereUniqueWithoutBuyerInput = {
    where: OrderWhereUniqueInput
    update: XOR<OrderUpdateWithoutBuyerInput, OrderUncheckedUpdateWithoutBuyerInput>
    create: XOR<OrderCreateWithoutBuyerInput, OrderUncheckedCreateWithoutBuyerInput>
  }

  export type OrderUpdateWithWhereUniqueWithoutBuyerInput = {
    where: OrderWhereUniqueInput
    data: XOR<OrderUpdateWithoutBuyerInput, OrderUncheckedUpdateWithoutBuyerInput>
  }

  export type OrderUpdateManyWithWhereWithoutBuyerInput = {
    where: OrderScalarWhereInput
    data: XOR<OrderUpdateManyMutationInput, OrderUncheckedUpdateManyWithoutBuyerInput>
  }

  export type OrderScalarWhereInput = {
    AND?: OrderScalarWhereInput | OrderScalarWhereInput[]
    OR?: OrderScalarWhereInput[]
    NOT?: OrderScalarWhereInput | OrderScalarWhereInput[]
    id?: IntFilter<"Order"> | number
    buyerId?: UuidFilter<"Order"> | string
    marketItemId?: IntFilter<"Order"> | number
    quantity?: IntFilter<"Order"> | number
    totalPrice?: IntFilter<"Order"> | number
    createdAt?: DateTimeFilter<"Order"> | Date | string
  }

  export type PointLogUpsertWithWhereUniqueWithoutUserInput = {
    where: PointLogWhereUniqueInput
    update: XOR<PointLogUpdateWithoutUserInput, PointLogUncheckedUpdateWithoutUserInput>
    create: XOR<PointLogCreateWithoutUserInput, PointLogUncheckedCreateWithoutUserInput>
  }

  export type PointLogUpdateWithWhereUniqueWithoutUserInput = {
    where: PointLogWhereUniqueInput
    data: XOR<PointLogUpdateWithoutUserInput, PointLogUncheckedUpdateWithoutUserInput>
  }

  export type PointLogUpdateManyWithWhereWithoutUserInput = {
    where: PointLogScalarWhereInput
    data: XOR<PointLogUpdateManyMutationInput, PointLogUncheckedUpdateManyWithoutUserInput>
  }

  export type PointLogScalarWhereInput = {
    AND?: PointLogScalarWhereInput | PointLogScalarWhereInput[]
    OR?: PointLogScalarWhereInput[]
    NOT?: PointLogScalarWhereInput | PointLogScalarWhereInput[]
    id?: IntFilter<"PointLog"> | number
    userId?: UuidFilter<"PointLog"> | string
    type?: EnumPointLogTypeFilter<"PointLog"> | $Enums.PointLogType
    amount?: IntFilter<"PointLog"> | number
    createdAt?: DateTimeFilter<"PointLog"> | Date | string
  }

  export type NotificationUpsertWithWhereUniqueWithoutUserInput = {
    where: NotificationWhereUniqueInput
    update: XOR<NotificationUpdateWithoutUserInput, NotificationUncheckedUpdateWithoutUserInput>
    create: XOR<NotificationCreateWithoutUserInput, NotificationUncheckedCreateWithoutUserInput>
  }

  export type NotificationUpdateWithWhereUniqueWithoutUserInput = {
    where: NotificationWhereUniqueInput
    data: XOR<NotificationUpdateWithoutUserInput, NotificationUncheckedUpdateWithoutUserInput>
  }

  export type NotificationUpdateManyWithWhereWithoutUserInput = {
    where: NotificationScalarWhereInput
    data: XOR<NotificationUpdateManyMutationInput, NotificationUncheckedUpdateManyWithoutUserInput>
  }

  export type NotificationScalarWhereInput = {
    AND?: NotificationScalarWhereInput | NotificationScalarWhereInput[]
    OR?: NotificationScalarWhereInput[]
    NOT?: NotificationScalarWhereInput | NotificationScalarWhereInput[]
    id?: IntFilter<"Notification"> | number
    userId?: UuidFilter<"Notification"> | string
    type?: EnumNotificationTypeFilter<"Notification"> | $Enums.NotificationType
    routeType?: EnumRouteTypeFilter<"Notification"> | $Enums.RouteType
    targetId?: IntNullableFilter<"Notification"> | number | null
    message?: StringFilter<"Notification"> | string
    isRead?: BoolFilter<"Notification"> | boolean
    createdAt?: DateTimeFilter<"Notification"> | Date | string
  }

  export type CardCreationLogUpsertWithWhereUniqueWithoutUserInput = {
    where: CardCreationLogWhereUniqueInput
    update: XOR<CardCreationLogUpdateWithoutUserInput, CardCreationLogUncheckedUpdateWithoutUserInput>
    create: XOR<CardCreationLogCreateWithoutUserInput, CardCreationLogUncheckedCreateWithoutUserInput>
  }

  export type CardCreationLogUpdateWithWhereUniqueWithoutUserInput = {
    where: CardCreationLogWhereUniqueInput
    data: XOR<CardCreationLogUpdateWithoutUserInput, CardCreationLogUncheckedUpdateWithoutUserInput>
  }

  export type CardCreationLogUpdateManyWithWhereWithoutUserInput = {
    where: CardCreationLogScalarWhereInput
    data: XOR<CardCreationLogUpdateManyMutationInput, CardCreationLogUncheckedUpdateManyWithoutUserInput>
  }

  export type CardCreationLogScalarWhereInput = {
    AND?: CardCreationLogScalarWhereInput | CardCreationLogScalarWhereInput[]
    OR?: CardCreationLogScalarWhereInput[]
    NOT?: CardCreationLogScalarWhereInput | CardCreationLogScalarWhereInput[]
    id?: IntFilter<"CardCreationLog"> | number
    userId?: UuidFilter<"CardCreationLog"> | string
    year?: IntFilter<"CardCreationLog"> | number
    month?: IntFilter<"CardCreationLog"> | number
    count?: IntFilter<"CardCreationLog"> | number
  }

  export type RefreshTokenUpsertWithWhereUniqueWithoutUserInput = {
    where: RefreshTokenWhereUniqueInput
    update: XOR<RefreshTokenUpdateWithoutUserInput, RefreshTokenUncheckedUpdateWithoutUserInput>
    create: XOR<RefreshTokenCreateWithoutUserInput, RefreshTokenUncheckedCreateWithoutUserInput>
  }

  export type RefreshTokenUpdateWithWhereUniqueWithoutUserInput = {
    where: RefreshTokenWhereUniqueInput
    data: XOR<RefreshTokenUpdateWithoutUserInput, RefreshTokenUncheckedUpdateWithoutUserInput>
  }

  export type RefreshTokenUpdateManyWithWhereWithoutUserInput = {
    where: RefreshTokenScalarWhereInput
    data: XOR<RefreshTokenUpdateManyMutationInput, RefreshTokenUncheckedUpdateManyWithoutUserInput>
  }

  export type RefreshTokenScalarWhereInput = {
    AND?: RefreshTokenScalarWhereInput | RefreshTokenScalarWhereInput[]
    OR?: RefreshTokenScalarWhereInput[]
    NOT?: RefreshTokenScalarWhereInput | RefreshTokenScalarWhereInput[]
    id?: IntFilter<"RefreshToken"> | number
    userId?: UuidFilter<"RefreshToken"> | string
    token?: StringFilter<"RefreshToken"> | string
    expiresAt?: DateTimeFilter<"RefreshToken"> | Date | string
    createdAt?: DateTimeFilter<"RefreshToken"> | Date | string
  }

  export type HistoryUpsertWithWhereUniqueWithoutUserInput = {
    where: HistoryWhereUniqueInput
    update: XOR<HistoryUpdateWithoutUserInput, HistoryUncheckedUpdateWithoutUserInput>
    create: XOR<HistoryCreateWithoutUserInput, HistoryUncheckedCreateWithoutUserInput>
  }

  export type HistoryUpdateWithWhereUniqueWithoutUserInput = {
    where: HistoryWhereUniqueInput
    data: XOR<HistoryUpdateWithoutUserInput, HistoryUncheckedUpdateWithoutUserInput>
  }

  export type HistoryUpdateManyWithWhereWithoutUserInput = {
    where: HistoryScalarWhereInput
    data: XOR<HistoryUpdateManyMutationInput, HistoryUncheckedUpdateManyWithoutUserInput>
  }

  export type HistoryScalarWhereInput = {
    AND?: HistoryScalarWhereInput | HistoryScalarWhereInput[]
    OR?: HistoryScalarWhereInput[]
    NOT?: HistoryScalarWhereInput | HistoryScalarWhereInput[]
    id?: BigIntFilter<"History"> | bigint | number
    recordId?: BigIntFilter<"History"> | bigint | number
    tableName?: StringFilter<"History"> | string
    operationType?: EnumOperationTypeFilter<"History"> | $Enums.OperationType
    oldData?: JsonNullableFilter<"History">
    newData?: JsonNullableFilter<"History">
    changedBy?: UuidNullableFilter<"History"> | string | null
    createdAt?: DateTimeFilter<"History"> | Date | string
  }

  export type UserCreateWithoutUserPointInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutUserPointInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutUserPointInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutUserPointInput, UserUncheckedCreateWithoutUserPointInput>
  }

  export type UserUpsertWithoutUserPointInput = {
    update: XOR<UserUpdateWithoutUserPointInput, UserUncheckedUpdateWithoutUserPointInput>
    create: XOR<UserCreateWithoutUserPointInput, UserUncheckedCreateWithoutUserPointInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutUserPointInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutUserPointInput, UserUncheckedUpdateWithoutUserPointInput>
  }

  export type UserUpdateWithoutUserPointInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutUserPointInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutPhotoCardsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutPhotoCardsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutPhotoCardsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPhotoCardsInput, UserUncheckedCreateWithoutPhotoCardsInput>
  }

  export type MyCardCreateWithoutPhotoCardInput = {
    quantity?: number
    acquiredAt?: Date | string
    owner: UserCreateNestedOneWithoutMyCardsInput
    marketItems?: MarketItemCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardUncheckedCreateWithoutPhotoCardInput = {
    id?: number
    ownerId: string
    quantity?: number
    acquiredAt?: Date | string
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutMyCardInput
    offeredExchanges?: ExchangeProposalUncheckedCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardCreateOrConnectWithoutPhotoCardInput = {
    where: MyCardWhereUniqueInput
    create: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput>
  }

  export type MyCardCreateManyPhotoCardInputEnvelope = {
    data: MyCardCreateManyPhotoCardInput | MyCardCreateManyPhotoCardInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutPhotoCardsInput = {
    update: XOR<UserUpdateWithoutPhotoCardsInput, UserUncheckedUpdateWithoutPhotoCardsInput>
    create: XOR<UserCreateWithoutPhotoCardsInput, UserUncheckedCreateWithoutPhotoCardsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPhotoCardsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPhotoCardsInput, UserUncheckedUpdateWithoutPhotoCardsInput>
  }

  export type UserUpdateWithoutPhotoCardsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutPhotoCardsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type MyCardUpsertWithWhereUniqueWithoutPhotoCardInput = {
    where: MyCardWhereUniqueInput
    update: XOR<MyCardUpdateWithoutPhotoCardInput, MyCardUncheckedUpdateWithoutPhotoCardInput>
    create: XOR<MyCardCreateWithoutPhotoCardInput, MyCardUncheckedCreateWithoutPhotoCardInput>
  }

  export type MyCardUpdateWithWhereUniqueWithoutPhotoCardInput = {
    where: MyCardWhereUniqueInput
    data: XOR<MyCardUpdateWithoutPhotoCardInput, MyCardUncheckedUpdateWithoutPhotoCardInput>
  }

  export type MyCardUpdateManyWithWhereWithoutPhotoCardInput = {
    where: MyCardScalarWhereInput
    data: XOR<MyCardUpdateManyMutationInput, MyCardUncheckedUpdateManyWithoutPhotoCardInput>
  }

  export type UserCreateWithoutMyCardsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutMyCardsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutMyCardsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutMyCardsInput, UserUncheckedCreateWithoutMyCardsInput>
  }

  export type PhotoCardCreateWithoutMyCardsInput = {
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
    creator: UserCreateNestedOneWithoutPhotoCardsInput
  }

  export type PhotoCardUncheckedCreateWithoutMyCardsInput = {
    id?: number
    creatorId: string
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
  }

  export type PhotoCardCreateOrConnectWithoutMyCardsInput = {
    where: PhotoCardWhereUniqueInput
    create: XOR<PhotoCardCreateWithoutMyCardsInput, PhotoCardUncheckedCreateWithoutMyCardsInput>
  }

  export type MarketItemCreateWithoutMyCardInput = {
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    seller: UserCreateNestedOneWithoutMarketItemsInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutMarketItemInput
    orders?: OrderCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUncheckedCreateWithoutMyCardInput = {
    id?: number
    sellerId: string
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutMarketItemInput
    orders?: OrderUncheckedCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemCreateOrConnectWithoutMyCardInput = {
    where: MarketItemWhereUniqueInput
    create: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput>
  }

  export type MarketItemCreateManyMyCardInputEnvelope = {
    data: MarketItemCreateManyMyCardInput | MarketItemCreateManyMyCardInput[]
    skipDuplicates?: boolean
  }

  export type ExchangeProposalCreateWithoutOfferedCardInput = {
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
    marketItem: MarketItemCreateNestedOneWithoutExchangeProposalsInput
    proposer: UserCreateNestedOneWithoutExchangeProposalsInput
  }

  export type ExchangeProposalUncheckedCreateWithoutOfferedCardInput = {
    id?: number
    marketItemId: number
    proposerId: string
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalCreateOrConnectWithoutOfferedCardInput = {
    where: ExchangeProposalWhereUniqueInput
    create: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput>
  }

  export type ExchangeProposalCreateManyOfferedCardInputEnvelope = {
    data: ExchangeProposalCreateManyOfferedCardInput | ExchangeProposalCreateManyOfferedCardInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutMyCardsInput = {
    update: XOR<UserUpdateWithoutMyCardsInput, UserUncheckedUpdateWithoutMyCardsInput>
    create: XOR<UserCreateWithoutMyCardsInput, UserUncheckedCreateWithoutMyCardsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutMyCardsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutMyCardsInput, UserUncheckedUpdateWithoutMyCardsInput>
  }

  export type UserUpdateWithoutMyCardsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutMyCardsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PhotoCardUpsertWithoutMyCardsInput = {
    update: XOR<PhotoCardUpdateWithoutMyCardsInput, PhotoCardUncheckedUpdateWithoutMyCardsInput>
    create: XOR<PhotoCardCreateWithoutMyCardsInput, PhotoCardUncheckedCreateWithoutMyCardsInput>
    where?: PhotoCardWhereInput
  }

  export type PhotoCardUpdateToOneWithWhereWithoutMyCardsInput = {
    where?: PhotoCardWhereInput
    data: XOR<PhotoCardUpdateWithoutMyCardsInput, PhotoCardUncheckedUpdateWithoutMyCardsInput>
  }

  export type PhotoCardUpdateWithoutMyCardsInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    creator?: UserUpdateOneRequiredWithoutPhotoCardsNestedInput
  }

  export type PhotoCardUncheckedUpdateWithoutMyCardsInput = {
    id?: IntFieldUpdateOperationsInput | number
    creatorId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MarketItemUpsertWithWhereUniqueWithoutMyCardInput = {
    where: MarketItemWhereUniqueInput
    update: XOR<MarketItemUpdateWithoutMyCardInput, MarketItemUncheckedUpdateWithoutMyCardInput>
    create: XOR<MarketItemCreateWithoutMyCardInput, MarketItemUncheckedCreateWithoutMyCardInput>
  }

  export type MarketItemUpdateWithWhereUniqueWithoutMyCardInput = {
    where: MarketItemWhereUniqueInput
    data: XOR<MarketItemUpdateWithoutMyCardInput, MarketItemUncheckedUpdateWithoutMyCardInput>
  }

  export type MarketItemUpdateManyWithWhereWithoutMyCardInput = {
    where: MarketItemScalarWhereInput
    data: XOR<MarketItemUpdateManyMutationInput, MarketItemUncheckedUpdateManyWithoutMyCardInput>
  }

  export type ExchangeProposalUpsertWithWhereUniqueWithoutOfferedCardInput = {
    where: ExchangeProposalWhereUniqueInput
    update: XOR<ExchangeProposalUpdateWithoutOfferedCardInput, ExchangeProposalUncheckedUpdateWithoutOfferedCardInput>
    create: XOR<ExchangeProposalCreateWithoutOfferedCardInput, ExchangeProposalUncheckedCreateWithoutOfferedCardInput>
  }

  export type ExchangeProposalUpdateWithWhereUniqueWithoutOfferedCardInput = {
    where: ExchangeProposalWhereUniqueInput
    data: XOR<ExchangeProposalUpdateWithoutOfferedCardInput, ExchangeProposalUncheckedUpdateWithoutOfferedCardInput>
  }

  export type ExchangeProposalUpdateManyWithWhereWithoutOfferedCardInput = {
    where: ExchangeProposalScalarWhereInput
    data: XOR<ExchangeProposalUpdateManyMutationInput, ExchangeProposalUncheckedUpdateManyWithoutOfferedCardInput>
  }

  export type UserCreateWithoutMarketItemsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutMarketItemsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutMarketItemsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutMarketItemsInput, UserUncheckedCreateWithoutMarketItemsInput>
  }

  export type MyCardCreateWithoutMarketItemsInput = {
    quantity?: number
    acquiredAt?: Date | string
    owner: UserCreateNestedOneWithoutMyCardsInput
    photoCard: PhotoCardCreateNestedOneWithoutMyCardsInput
    offeredExchanges?: ExchangeProposalCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardUncheckedCreateWithoutMarketItemsInput = {
    id?: number
    ownerId: string
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
    offeredExchanges?: ExchangeProposalUncheckedCreateNestedManyWithoutOfferedCardInput
  }

  export type MyCardCreateOrConnectWithoutMarketItemsInput = {
    where: MyCardWhereUniqueInput
    create: XOR<MyCardCreateWithoutMarketItemsInput, MyCardUncheckedCreateWithoutMarketItemsInput>
  }

  export type ExchangeProposalCreateWithoutMarketItemInput = {
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
    proposer: UserCreateNestedOneWithoutExchangeProposalsInput
    offeredCard: MyCardCreateNestedOneWithoutOfferedExchangesInput
  }

  export type ExchangeProposalUncheckedCreateWithoutMarketItemInput = {
    id?: number
    proposerId: string
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalCreateOrConnectWithoutMarketItemInput = {
    where: ExchangeProposalWhereUniqueInput
    create: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput>
  }

  export type ExchangeProposalCreateManyMarketItemInputEnvelope = {
    data: ExchangeProposalCreateManyMarketItemInput | ExchangeProposalCreateManyMarketItemInput[]
    skipDuplicates?: boolean
  }

  export type OrderCreateWithoutMarketItemInput = {
    quantity: number
    totalPrice: number
    createdAt?: Date | string
    buyer: UserCreateNestedOneWithoutOrdersInput
  }

  export type OrderUncheckedCreateWithoutMarketItemInput = {
    id?: number
    buyerId: string
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type OrderCreateOrConnectWithoutMarketItemInput = {
    where: OrderWhereUniqueInput
    create: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput>
  }

  export type OrderCreateManyMarketItemInputEnvelope = {
    data: OrderCreateManyMarketItemInput | OrderCreateManyMarketItemInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutMarketItemsInput = {
    update: XOR<UserUpdateWithoutMarketItemsInput, UserUncheckedUpdateWithoutMarketItemsInput>
    create: XOR<UserCreateWithoutMarketItemsInput, UserUncheckedCreateWithoutMarketItemsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutMarketItemsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutMarketItemsInput, UserUncheckedUpdateWithoutMarketItemsInput>
  }

  export type UserUpdateWithoutMarketItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutMarketItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type MyCardUpsertWithoutMarketItemsInput = {
    update: XOR<MyCardUpdateWithoutMarketItemsInput, MyCardUncheckedUpdateWithoutMarketItemsInput>
    create: XOR<MyCardCreateWithoutMarketItemsInput, MyCardUncheckedCreateWithoutMarketItemsInput>
    where?: MyCardWhereInput
  }

  export type MyCardUpdateToOneWithWhereWithoutMarketItemsInput = {
    where?: MyCardWhereInput
    data: XOR<MyCardUpdateWithoutMarketItemsInput, MyCardUncheckedUpdateWithoutMarketItemsInput>
  }

  export type MyCardUpdateWithoutMarketItemsInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    owner?: UserUpdateOneRequiredWithoutMyCardsNestedInput
    photoCard?: PhotoCardUpdateOneRequiredWithoutMyCardsNestedInput
    offeredExchanges?: ExchangeProposalUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateWithoutMarketItemsInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    offeredExchanges?: ExchangeProposalUncheckedUpdateManyWithoutOfferedCardNestedInput
  }

  export type ExchangeProposalUpsertWithWhereUniqueWithoutMarketItemInput = {
    where: ExchangeProposalWhereUniqueInput
    update: XOR<ExchangeProposalUpdateWithoutMarketItemInput, ExchangeProposalUncheckedUpdateWithoutMarketItemInput>
    create: XOR<ExchangeProposalCreateWithoutMarketItemInput, ExchangeProposalUncheckedCreateWithoutMarketItemInput>
  }

  export type ExchangeProposalUpdateWithWhereUniqueWithoutMarketItemInput = {
    where: ExchangeProposalWhereUniqueInput
    data: XOR<ExchangeProposalUpdateWithoutMarketItemInput, ExchangeProposalUncheckedUpdateWithoutMarketItemInput>
  }

  export type ExchangeProposalUpdateManyWithWhereWithoutMarketItemInput = {
    where: ExchangeProposalScalarWhereInput
    data: XOR<ExchangeProposalUpdateManyMutationInput, ExchangeProposalUncheckedUpdateManyWithoutMarketItemInput>
  }

  export type OrderUpsertWithWhereUniqueWithoutMarketItemInput = {
    where: OrderWhereUniqueInput
    update: XOR<OrderUpdateWithoutMarketItemInput, OrderUncheckedUpdateWithoutMarketItemInput>
    create: XOR<OrderCreateWithoutMarketItemInput, OrderUncheckedCreateWithoutMarketItemInput>
  }

  export type OrderUpdateWithWhereUniqueWithoutMarketItemInput = {
    where: OrderWhereUniqueInput
    data: XOR<OrderUpdateWithoutMarketItemInput, OrderUncheckedUpdateWithoutMarketItemInput>
  }

  export type OrderUpdateManyWithWhereWithoutMarketItemInput = {
    where: OrderScalarWhereInput
    data: XOR<OrderUpdateManyMutationInput, OrderUncheckedUpdateManyWithoutMarketItemInput>
  }

  export type MarketItemCreateWithoutExchangeProposalsInput = {
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    seller: UserCreateNestedOneWithoutMarketItemsInput
    myCard: MyCardCreateNestedOneWithoutMarketItemsInput
    orders?: OrderCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUncheckedCreateWithoutExchangeProposalsInput = {
    id?: number
    sellerId: string
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    orders?: OrderUncheckedCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemCreateOrConnectWithoutExchangeProposalsInput = {
    where: MarketItemWhereUniqueInput
    create: XOR<MarketItemCreateWithoutExchangeProposalsInput, MarketItemUncheckedCreateWithoutExchangeProposalsInput>
  }

  export type UserCreateWithoutExchangeProposalsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutExchangeProposalsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutExchangeProposalsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutExchangeProposalsInput, UserUncheckedCreateWithoutExchangeProposalsInput>
  }

  export type MyCardCreateWithoutOfferedExchangesInput = {
    quantity?: number
    acquiredAt?: Date | string
    owner: UserCreateNestedOneWithoutMyCardsInput
    photoCard: PhotoCardCreateNestedOneWithoutMyCardsInput
    marketItems?: MarketItemCreateNestedManyWithoutMyCardInput
  }

  export type MyCardUncheckedCreateWithoutOfferedExchangesInput = {
    id?: number
    ownerId: string
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutMyCardInput
  }

  export type MyCardCreateOrConnectWithoutOfferedExchangesInput = {
    where: MyCardWhereUniqueInput
    create: XOR<MyCardCreateWithoutOfferedExchangesInput, MyCardUncheckedCreateWithoutOfferedExchangesInput>
  }

  export type MarketItemUpsertWithoutExchangeProposalsInput = {
    update: XOR<MarketItemUpdateWithoutExchangeProposalsInput, MarketItemUncheckedUpdateWithoutExchangeProposalsInput>
    create: XOR<MarketItemCreateWithoutExchangeProposalsInput, MarketItemUncheckedCreateWithoutExchangeProposalsInput>
    where?: MarketItemWhereInput
  }

  export type MarketItemUpdateToOneWithWhereWithoutExchangeProposalsInput = {
    where?: MarketItemWhereInput
    data: XOR<MarketItemUpdateWithoutExchangeProposalsInput, MarketItemUncheckedUpdateWithoutExchangeProposalsInput>
  }

  export type MarketItemUpdateWithoutExchangeProposalsInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    seller?: UserUpdateOneRequiredWithoutMarketItemsNestedInput
    myCard?: MyCardUpdateOneRequiredWithoutMarketItemsNestedInput
    orders?: OrderUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateWithoutExchangeProposalsInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    orders?: OrderUncheckedUpdateManyWithoutMarketItemNestedInput
  }

  export type UserUpsertWithoutExchangeProposalsInput = {
    update: XOR<UserUpdateWithoutExchangeProposalsInput, UserUncheckedUpdateWithoutExchangeProposalsInput>
    create: XOR<UserCreateWithoutExchangeProposalsInput, UserUncheckedCreateWithoutExchangeProposalsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutExchangeProposalsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutExchangeProposalsInput, UserUncheckedUpdateWithoutExchangeProposalsInput>
  }

  export type UserUpdateWithoutExchangeProposalsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutExchangeProposalsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type MyCardUpsertWithoutOfferedExchangesInput = {
    update: XOR<MyCardUpdateWithoutOfferedExchangesInput, MyCardUncheckedUpdateWithoutOfferedExchangesInput>
    create: XOR<MyCardCreateWithoutOfferedExchangesInput, MyCardUncheckedCreateWithoutOfferedExchangesInput>
    where?: MyCardWhereInput
  }

  export type MyCardUpdateToOneWithWhereWithoutOfferedExchangesInput = {
    where?: MyCardWhereInput
    data: XOR<MyCardUpdateWithoutOfferedExchangesInput, MyCardUncheckedUpdateWithoutOfferedExchangesInput>
  }

  export type MyCardUpdateWithoutOfferedExchangesInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    owner?: UserUpdateOneRequiredWithoutMyCardsNestedInput
    photoCard?: PhotoCardUpdateOneRequiredWithoutMyCardsNestedInput
    marketItems?: MarketItemUpdateManyWithoutMyCardNestedInput
  }

  export type MyCardUncheckedUpdateWithoutOfferedExchangesInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItems?: MarketItemUncheckedUpdateManyWithoutMyCardNestedInput
  }

  export type UserCreateWithoutOrdersInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutOrdersInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutOrdersInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutOrdersInput, UserUncheckedCreateWithoutOrdersInput>
  }

  export type MarketItemCreateWithoutOrdersInput = {
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    seller: UserCreateNestedOneWithoutMarketItemsInput
    myCard: MyCardCreateNestedOneWithoutMarketItemsInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemUncheckedCreateWithoutOrdersInput = {
    id?: number
    sellerId: string
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutMarketItemInput
  }

  export type MarketItemCreateOrConnectWithoutOrdersInput = {
    where: MarketItemWhereUniqueInput
    create: XOR<MarketItemCreateWithoutOrdersInput, MarketItemUncheckedCreateWithoutOrdersInput>
  }

  export type UserUpsertWithoutOrdersInput = {
    update: XOR<UserUpdateWithoutOrdersInput, UserUncheckedUpdateWithoutOrdersInput>
    create: XOR<UserCreateWithoutOrdersInput, UserUncheckedCreateWithoutOrdersInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutOrdersInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutOrdersInput, UserUncheckedUpdateWithoutOrdersInput>
  }

  export type UserUpdateWithoutOrdersInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutOrdersInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type MarketItemUpsertWithoutOrdersInput = {
    update: XOR<MarketItemUpdateWithoutOrdersInput, MarketItemUncheckedUpdateWithoutOrdersInput>
    create: XOR<MarketItemCreateWithoutOrdersInput, MarketItemUncheckedCreateWithoutOrdersInput>
    where?: MarketItemWhereInput
  }

  export type MarketItemUpdateToOneWithWhereWithoutOrdersInput = {
    where?: MarketItemWhereInput
    data: XOR<MarketItemUpdateWithoutOrdersInput, MarketItemUncheckedUpdateWithoutOrdersInput>
  }

  export type MarketItemUpdateWithoutOrdersInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    seller?: UserUpdateOneRequiredWithoutMarketItemsNestedInput
    myCard?: MyCardUpdateOneRequiredWithoutMarketItemsNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateWithoutOrdersInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutMarketItemNestedInput
  }

  export type UserCreateWithoutPointLogsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutPointLogsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutPointLogsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPointLogsInput, UserUncheckedCreateWithoutPointLogsInput>
  }

  export type UserUpsertWithoutPointLogsInput = {
    update: XOR<UserUpdateWithoutPointLogsInput, UserUncheckedUpdateWithoutPointLogsInput>
    create: XOR<UserCreateWithoutPointLogsInput, UserUncheckedCreateWithoutPointLogsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPointLogsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPointLogsInput, UserUncheckedUpdateWithoutPointLogsInput>
  }

  export type UserUpdateWithoutPointLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutPointLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutNotificationsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutNotificationsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutNotificationsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutNotificationsInput, UserUncheckedCreateWithoutNotificationsInput>
  }

  export type UserUpsertWithoutNotificationsInput = {
    update: XOR<UserUpdateWithoutNotificationsInput, UserUncheckedUpdateWithoutNotificationsInput>
    create: XOR<UserCreateWithoutNotificationsInput, UserUncheckedCreateWithoutNotificationsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutNotificationsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutNotificationsInput, UserUncheckedUpdateWithoutNotificationsInput>
  }

  export type UserUpdateWithoutNotificationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutNotificationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutCreationLogsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutCreationLogsInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutCreationLogsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCreationLogsInput, UserUncheckedCreateWithoutCreationLogsInput>
  }

  export type UserUpsertWithoutCreationLogsInput = {
    update: XOR<UserUpdateWithoutCreationLogsInput, UserUncheckedUpdateWithoutCreationLogsInput>
    create: XOR<UserCreateWithoutCreationLogsInput, UserUncheckedCreateWithoutCreationLogsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCreationLogsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCreationLogsInput, UserUncheckedUpdateWithoutCreationLogsInput>
  }

  export type UserUpdateWithoutCreationLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutCreationLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutRefreshTokensInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    histories?: HistoryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutRefreshTokensInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    histories?: HistoryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutRefreshTokensInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutRefreshTokensInput, UserUncheckedCreateWithoutRefreshTokensInput>
  }

  export type UserUpsertWithoutRefreshTokensInput = {
    update: XOR<UserUpdateWithoutRefreshTokensInput, UserUncheckedUpdateWithoutRefreshTokensInput>
    create: XOR<UserCreateWithoutRefreshTokensInput, UserUncheckedCreateWithoutRefreshTokensInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutRefreshTokensInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutRefreshTokensInput, UserUncheckedUpdateWithoutRefreshTokensInput>
  }

  export type UserUpdateWithoutRefreshTokensInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    histories?: HistoryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutRefreshTokensInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    histories?: HistoryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutHistoriesInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardCreateNestedManyWithoutCreatorInput
    myCards?: MyCardCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalCreateNestedManyWithoutProposerInput
    orders?: OrderCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogCreateNestedManyWithoutUserInput
    notifications?: NotificationCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutHistoriesInput = {
    id?: string
    email: string
    password?: string | null
    nickname: string
    provider: $Enums.Provider
    providerId?: string | null
    createdAt?: Date | string
    userPoint?: UserPointUncheckedCreateNestedOneWithoutUserInput
    photoCards?: PhotoCardUncheckedCreateNestedManyWithoutCreatorInput
    myCards?: MyCardUncheckedCreateNestedManyWithoutOwnerInput
    marketItems?: MarketItemUncheckedCreateNestedManyWithoutSellerInput
    exchangeProposals?: ExchangeProposalUncheckedCreateNestedManyWithoutProposerInput
    orders?: OrderUncheckedCreateNestedManyWithoutBuyerInput
    pointLogs?: PointLogUncheckedCreateNestedManyWithoutUserInput
    notifications?: NotificationUncheckedCreateNestedManyWithoutUserInput
    creationLogs?: CardCreationLogUncheckedCreateNestedManyWithoutUserInput
    refreshTokens?: RefreshTokenUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutHistoriesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutHistoriesInput, UserUncheckedCreateWithoutHistoriesInput>
  }

  export type UserUpsertWithoutHistoriesInput = {
    update: XOR<UserUpdateWithoutHistoriesInput, UserUncheckedUpdateWithoutHistoriesInput>
    create: XOR<UserCreateWithoutHistoriesInput, UserUncheckedCreateWithoutHistoriesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutHistoriesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutHistoriesInput, UserUncheckedUpdateWithoutHistoriesInput>
  }

  export type UserUpdateWithoutHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutProposerNestedInput
    orders?: OrderUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUpdateManyWithoutUserNestedInput
    notifications?: NotificationUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    nickname?: StringFieldUpdateOperationsInput | string
    provider?: EnumProviderFieldUpdateOperationsInput | $Enums.Provider
    providerId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userPoint?: UserPointUncheckedUpdateOneWithoutUserNestedInput
    photoCards?: PhotoCardUncheckedUpdateManyWithoutCreatorNestedInput
    myCards?: MyCardUncheckedUpdateManyWithoutOwnerNestedInput
    marketItems?: MarketItemUncheckedUpdateManyWithoutSellerNestedInput
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutProposerNestedInput
    orders?: OrderUncheckedUpdateManyWithoutBuyerNestedInput
    pointLogs?: PointLogUncheckedUpdateManyWithoutUserNestedInput
    notifications?: NotificationUncheckedUpdateManyWithoutUserNestedInput
    creationLogs?: CardCreationLogUncheckedUpdateManyWithoutUserNestedInput
    refreshTokens?: RefreshTokenUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PhotoCardCreateManyCreatorInput = {
    id?: number
    name: string
    description?: string | null
    genre: $Enums.Genre
    grade: $Enums.CardGrade
    price: number
    totalQuantity: number
    imageUrl: string
    createdAt?: Date | string
  }

  export type MyCardCreateManyOwnerInput = {
    id?: number
    photoCardId: number
    quantity?: number
    acquiredAt?: Date | string
  }

  export type MarketItemCreateManySellerInput = {
    id?: number
    myCardId: number
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalCreateManyProposerInput = {
    id?: number
    marketItemId: number
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type OrderCreateManyBuyerInput = {
    id?: number
    marketItemId: number
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type PointLogCreateManyUserInput = {
    id?: number
    type: $Enums.PointLogType
    amount: number
    createdAt?: Date | string
  }

  export type NotificationCreateManyUserInput = {
    id?: number
    type: $Enums.NotificationType
    routeType: $Enums.RouteType
    targetId?: number | null
    message: string
    isRead?: boolean
    createdAt?: Date | string
  }

  export type CardCreationLogCreateManyUserInput = {
    id?: number
    year: number
    month: number
    count?: number
  }

  export type RefreshTokenCreateManyUserInput = {
    id?: number
    token: string
    expiresAt: Date | string
    createdAt?: Date | string
  }

  export type HistoryCreateManyUserInput = {
    id?: bigint | number
    recordId: bigint | number
    tableName: string
    operationType: $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
  }

  export type PhotoCardUpdateWithoutCreatorInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    myCards?: MyCardUpdateManyWithoutPhotoCardNestedInput
  }

  export type PhotoCardUncheckedUpdateWithoutCreatorInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    myCards?: MyCardUncheckedUpdateManyWithoutPhotoCardNestedInput
  }

  export type PhotoCardUncheckedUpdateManyWithoutCreatorInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    price?: IntFieldUpdateOperationsInput | number
    totalQuantity?: IntFieldUpdateOperationsInput | number
    imageUrl?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MyCardUpdateWithoutOwnerInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photoCard?: PhotoCardUpdateOneRequiredWithoutMyCardsNestedInput
    marketItems?: MarketItemUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateWithoutOwnerInput = {
    id?: IntFieldUpdateOperationsInput | number
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItems?: MarketItemUncheckedUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUncheckedUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateManyWithoutOwnerInput = {
    id?: IntFieldUpdateOperationsInput | number
    photoCardId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MarketItemUpdateWithoutSellerInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    myCard?: MyCardUpdateOneRequiredWithoutMarketItemsNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateWithoutSellerInput = {
    id?: IntFieldUpdateOperationsInput | number
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUncheckedUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateManyWithoutSellerInput = {
    id?: IntFieldUpdateOperationsInput | number
    myCardId?: IntFieldUpdateOperationsInput | number
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUpdateWithoutProposerInput = {
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItem?: MarketItemUpdateOneRequiredWithoutExchangeProposalsNestedInput
    offeredCard?: MyCardUpdateOneRequiredWithoutOfferedExchangesNestedInput
  }

  export type ExchangeProposalUncheckedUpdateWithoutProposerInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutProposerInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderUpdateWithoutBuyerInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItem?: MarketItemUpdateOneRequiredWithoutOrdersNestedInput
  }

  export type OrderUncheckedUpdateWithoutBuyerInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderUncheckedUpdateManyWithoutBuyerInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogUpdateWithoutUserInput = {
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PointLogUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    type?: EnumPointLogTypeFieldUpdateOperationsInput | $Enums.PointLogType
    amount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationUpdateWithoutUserInput = {
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NotificationUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    type?: EnumNotificationTypeFieldUpdateOperationsInput | $Enums.NotificationType
    routeType?: EnumRouteTypeFieldUpdateOperationsInput | $Enums.RouteType
    targetId?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    isRead?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CardCreationLogUpdateWithoutUserInput = {
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type CardCreationLogUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type CardCreationLogUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    month?: IntFieldUpdateOperationsInput | number
    count?: IntFieldUpdateOperationsInput | number
  }

  export type RefreshTokenUpdateWithoutUserInput = {
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RefreshTokenUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RefreshTokenUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    token?: StringFieldUpdateOperationsInput | string
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryUpdateWithoutUserInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryUncheckedUpdateWithoutUserInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryUncheckedUpdateManyWithoutUserInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    recordId?: BigIntFieldUpdateOperationsInput | bigint | number
    tableName?: StringFieldUpdateOperationsInput | string
    operationType?: EnumOperationTypeFieldUpdateOperationsInput | $Enums.OperationType
    oldData?: NullableJsonNullValueInput | InputJsonValue
    newData?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MyCardCreateManyPhotoCardInput = {
    id?: number
    ownerId: string
    quantity?: number
    acquiredAt?: Date | string
  }

  export type MyCardUpdateWithoutPhotoCardInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    owner?: UserUpdateOneRequiredWithoutMyCardsNestedInput
    marketItems?: MarketItemUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateWithoutPhotoCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItems?: MarketItemUncheckedUpdateManyWithoutMyCardNestedInput
    offeredExchanges?: ExchangeProposalUncheckedUpdateManyWithoutOfferedCardNestedInput
  }

  export type MyCardUncheckedUpdateManyWithoutPhotoCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    ownerId?: StringFieldUpdateOperationsInput | string
    quantity?: IntFieldUpdateOperationsInput | number
    acquiredAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MarketItemCreateManyMyCardInput = {
    id?: number
    sellerId: string
    grade: $Enums.CardGrade
    genre: $Enums.Genre
    quantity: number
    soldQuantity?: number
    pricePerCard: number
    wantedGrade?: $Enums.CardGrade | null
    wantedGenre?: $Enums.Genre | null
    wantedDescription?: string | null
    status?: $Enums.MarketStatus
    createdAt?: Date | string
  }

  export type ExchangeProposalCreateManyOfferedCardInput = {
    id?: number
    marketItemId: number
    proposerId: string
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type MarketItemUpdateWithoutMyCardInput = {
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    seller?: UserUpdateOneRequiredWithoutMarketItemsNestedInput
    exchangeProposals?: ExchangeProposalUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateWithoutMyCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exchangeProposals?: ExchangeProposalUncheckedUpdateManyWithoutMarketItemNestedInput
    orders?: OrderUncheckedUpdateManyWithoutMarketItemNestedInput
  }

  export type MarketItemUncheckedUpdateManyWithoutMyCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    sellerId?: StringFieldUpdateOperationsInput | string
    grade?: EnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade
    genre?: EnumGenreFieldUpdateOperationsInput | $Enums.Genre
    quantity?: IntFieldUpdateOperationsInput | number
    soldQuantity?: IntFieldUpdateOperationsInput | number
    pricePerCard?: IntFieldUpdateOperationsInput | number
    wantedGrade?: NullableEnumCardGradeFieldUpdateOperationsInput | $Enums.CardGrade | null
    wantedGenre?: NullableEnumGenreFieldUpdateOperationsInput | $Enums.Genre | null
    wantedDescription?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumMarketStatusFieldUpdateOperationsInput | $Enums.MarketStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUpdateWithoutOfferedCardInput = {
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    marketItem?: MarketItemUpdateOneRequiredWithoutExchangeProposalsNestedInput
    proposer?: UserUpdateOneRequiredWithoutExchangeProposalsNestedInput
  }

  export type ExchangeProposalUncheckedUpdateWithoutOfferedCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutOfferedCardInput = {
    id?: IntFieldUpdateOperationsInput | number
    marketItemId?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalCreateManyMarketItemInput = {
    id?: number
    proposerId: string
    offeredCardId: number
    status?: $Enums.ExchangeStatus
    createdAt?: Date | string
  }

  export type OrderCreateManyMarketItemInput = {
    id?: number
    buyerId: string
    quantity: number
    totalPrice: number
    createdAt?: Date | string
  }

  export type ExchangeProposalUpdateWithoutMarketItemInput = {
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    proposer?: UserUpdateOneRequiredWithoutExchangeProposalsNestedInput
    offeredCard?: MyCardUpdateOneRequiredWithoutOfferedExchangesNestedInput
  }

  export type ExchangeProposalUncheckedUpdateWithoutMarketItemInput = {
    id?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExchangeProposalUncheckedUpdateManyWithoutMarketItemInput = {
    id?: IntFieldUpdateOperationsInput | number
    proposerId?: StringFieldUpdateOperationsInput | string
    offeredCardId?: IntFieldUpdateOperationsInput | number
    status?: EnumExchangeStatusFieldUpdateOperationsInput | $Enums.ExchangeStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderUpdateWithoutMarketItemInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    buyer?: UserUpdateOneRequiredWithoutOrdersNestedInput
  }

  export type OrderUncheckedUpdateWithoutMarketItemInput = {
    id?: IntFieldUpdateOperationsInput | number
    buyerId?: StringFieldUpdateOperationsInput | string
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrderUncheckedUpdateManyWithoutMarketItemInput = {
    id?: IntFieldUpdateOperationsInput | number
    buyerId?: StringFieldUpdateOperationsInput | string
    quantity?: IntFieldUpdateOperationsInput | number
    totalPrice?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}