// BE에서 사용하는 에러 코드 문자열을 한곳에 모아 관리
export const ERROR_CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR', // 입력값 형식이나 필수값 검증 실패
  UNAUTHORIZED: 'UNAUTHORIZED', // 로그인 or 유효한 인증 토큰 필요
  FORBIDDEN: 'FORBIDDEN', // 권한이 없음 (403 - 작성자 권한 없음, 접근 권한 없음 등)

  INVALID_TOKEN: 'INVALID_TOKEN', // 토큰이 위조되었거나 형식이 올바르지 않음
  EXPIRED_TOKEN: 'EXPIRED_TOKEN', // 토큰의 유효 기간이 만료됨
  DUPLICATE_EMAIL: 'DUPLICATE_EMAIL', // 이메일 중복 검증
  DUPLICATE_NICKNAME: 'DUPLICATE_NICKNAME', // 닉네임 중복 검증

  OAUTH_ERROR: 'OAUTH_ERROR', // OAuth 인증 처리 중 발생한 에러
  OAUTH_CONFLICT: 'OAUTH_CONFLICT', // OAuth 이메일이 기존 LOCAL 계정과 충돌

  INTERNAL_ERROR: 'INTERNAL_ERROR', // 예상하지 못한 서버 내부 오류
  NOT_FOUND: 'NOT_FOUND', // 요청한 API 경로를 찾을 수 없음

  // 포인트 관련 에러 코드
  POINTS_NOT_FOUND: 'POINTS_NOT_FOUND', // 사용자 포인트 정보가 존재하지 않음
  POINT_BOX_COOLDOWN: 'POINT_BOX_COOLDOWN', // 포인트 박스 오픈 쿨다운 중

  PHOTO_CARD_NOT_FOUND: 'PHOTO_CARD_NOT_FOUND', // 포토카드를 찾을 수 없을 때 (404)

  MARKET_LISTING_NOT_FOUND: 'MARKET_LISTING_NOT_FOUND', // 카드를 찾을 수 없을 때 (404)
  PHOTO_CARD_ALREADY_LISTED: 'PHOTO_CARD_ALREADY_LISTED', // 이미 등록된 카드일 때 (409)
  CANNOT_BUY_OWN_PHOTO_CARD: 'CANNOT_BUY_OWN_PHOTO_CARD', // 본인 카드 구매 시도 시 (409)

  // 주문 관련 에러 코드
  INSUFFICIENT_POINTS: 'INSUFFICIENT_POINTS', // 구매 시 사용자의 포인트가 부족할 때 (409)
  INSUFFICIENT_STOCK: 'INSUFFICIENT_STOCK', // 구매 시 재고가 부족할 때 (409)
  MARKET_ITEM_NOT_SELLING: 'MARKET_ITEM_NOT_SELLING', // 구매 시 해당 상품이 판매 중이 아닐 때 (409)

  // 포토 카드 생성 관련 에러 코드
  PHOTO_CARD_ALREADY_LIMIT: 'PHOTO_CARD_ALREADY_LIMIT', // 포토 카드 생성 제한 상한  시 (409)
  INVALID_IMAGE_FILE: 'INVALID_IMAGE_FILE', // 이미지를 찾을 수 없을 때 (404)
  INVALID_IMAGE_MIME_TYPE: 'INVALID_IMAGE_MIME_TYPE', // 이미지 파일 형식이 다를 때 (409)
  CANNOT_FOUND_IMAGE_URL: 'CANNOT_FOUND_IMAGE_URL', // 이미지 URL 을 불러오지 못했을 때 (500)

  // 교환 관련 에러 코드
  EXCHANGE_NOT_FOUND: 'EXCHANGE_NOT_FOUND', // 교환이 존재하지 않을 때 (404)
  EXCHANGE_NOT_WAITING: 'EXCHANGE_NOT_WAITING', // 교환이 대기 상태가 아닐 때 (409)
  CANNOT_EXCHANGE_OWN_CARD: 'CANNOT_EXCHANGE_OWN_CARD', // 본인 카드 교환 시도 시 (409)
  CANNOT_EXCHANGE_SAME_CARD: 'CANNOT_EXCHANGE_SAME_CARD', // 같은 카드끼리 교환 시도 시 (409)
  INSUFFICIENT_EXCHANGE_CARD: 'INSUFFICIENT_EXCHANGE_CARD', // 교환 시 필요한 카드가 부족할 때 (409)
  DUPLICATE_EXCHANGE: 'DUPLICATE_EXCHANGE', // 이미 존재하는 교환이 있을 때 (409)
};
